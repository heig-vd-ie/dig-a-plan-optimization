import polars as pl
from polars import col as c

from twindigrid_changes.schema import ChangesSchema
from twindigrid_sql.entries.equipment_class import BRANCH

from general_function import pl_to_dict, generate_log

from pandapower_exporter.pandapower_pipeline_model import PandaPowerPipelineModel

log = generate_log(name=__name__)


def resource_parser(pandapower_pipeline_model: PandaPowerPipelineModel) -> PandaPowerPipelineModel:
    
    change_schema: ChangesSchema = pandapower_pipeline_model.change_schema
    
    parent_mapping: dict[str, str] = pl_to_dict(
        change_schema.container.drop_nulls("parent_fk")[["uuid", "parent_fk"]]
    )
    geo: pl.DataFrame = change_schema.geo_event.select(
        "res_fk", c("geo").alias("geo")
    ).as_polars()

    container_geo_mapping: dict[str, str] = pl_to_dict(
        change_schema.connectivity.as_polars()
        .filter(c("eq_class") != BRANCH)
        .with_columns(c("container_fk").replace(parent_mapping))
        .drop_nulls("container_fk")
        .unique("eq_fk")
        .join(geo, left_on="container_fk", right_on="res_fk", how="left")[
            ["eq_fk", "geo"]
        ]
    )

    resource: pl.DataFrame = (
        change_schema.resource.as_polars()
        .join(geo, left_on="uuid", right_on="res_fk", how="left")
        .with_columns(
            c("geo").fill_null(
                c("uuid").replace_strict(container_geo_mapping, default=None)
            )
        )[["uuid", "dso_code", "name", "geo"]]
    )
    pandapower_pipeline_model.resource = resource
    return pandapower_pipeline_model
