import polars as pl
import numpy as np
from polars import col as c

from pandapower_exporter.models import PandaPowerSchema
from twindigrid_changes.schema import ChangesSchema
from twindigrid_sql.schema.enum import TerminalSide, SwitchType

from general_function import generate_log

from pandapower_exporter.pandapower_pipeline_model import PandaPowerPipelineModel

log = generate_log(name=__name__)

SWITCH_TYPE_MAPPING = {
    SwitchType.FUSE.value: "LS",
    SwitchType.SECTIONALISER.value: "DS",
    SwitchType.BREAKER.value: "CB",
    SwitchType.DISCONNECTING_CIRCUIT_BREAKER.value: "CB",
    SwitchType.LOAD_BREAK_SWITCH.value: "LBS",
    SwitchType.FUSE_EQUIPED_LOAD_BREAK_SWITCH.value: "LBS",
}

SWITCH_COL_MAPPING: dict[str, str] = {
    "uuid": "eq_fk",
    TerminalSide.T1.value: "bus",
    TerminalSide.T2.value: "element",
}


def switch_parser(pandapower_pipeline_model: PandaPowerPipelineModel, use_switch_event: bool) -> PandaPowerPipelineModel:
    
    change_schema: ChangesSchema = pandapower_pipeline_model.change_schema

    switch: pl.DataFrame = change_schema.switch.as_polars()

    if switch.is_empty():
        log.warning("No switch found")
        return pandapower_pipeline_model

    switch_event: pl.DataFrame = (
        change_schema.switch_event.as_polars()
        .sort("timestamp")
        .filter(c("eq_fk").is_first_distinct())[["eq_fk", "open"]]
    )

    connectivity = pandapower_pipeline_model.connectivity.pivot(on="side", index="eq_fk", values="bus_id")

    switch = (
        switch.join(pandapower_pipeline_model.resource, on="uuid", how="left")
        .join(connectivity, left_on="uuid", right_on="eq_fk", how="inner")
        .join(switch_event, left_on="uuid", right_on="eq_fk", how="left")
        .drop_nulls(subset=[TerminalSide.T1.value, TerminalSide.T2.value])
    )
    switch_status_columns = "open" if use_switch_event else "normal_open"
    switch = (
        switch.rename(SWITCH_COL_MAPPING)
        .with_columns(
            (~c(switch_status_columns)).alias("closed"),
            c("type").replace_strict(SWITCH_TYPE_MAPPING, default=None).alias("type"),
        )
        .with_row_index(name="id")
    )
    pandapower_pipeline_model.panda_power_schema = pandapower_pipeline_model.panda_power_schema.add_table(switch=switch)
    return pandapower_pipeline_model
