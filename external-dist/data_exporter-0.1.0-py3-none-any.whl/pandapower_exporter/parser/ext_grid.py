import polars as pl

from pandapower_exporter.models import PandaPowerSchema
from twindigrid_changes.schema import ChangesSchema
from general_function import generate_log


from pandapower_exporter.pandapower_pipeline_model import PandaPowerPipelineModel

EXT_GRID_COL_MAPPING: dict[str, str] = {"uuid": "eq_fk", "bus_id": "bus"}
log = generate_log(name=__name__)


def ext_grid_parser(pandapower_pipeline_model: PandaPowerPipelineModel) -> PandaPowerPipelineModel:
    
    change_schema: ChangesSchema = pandapower_pipeline_model.change_schema

    ext_grid: pl.DataFrame = change_schema.external_network.as_polars()

    if ext_grid.is_empty():
        log.warning("No ext_grid found")
        return pandapower_pipeline_model

    connectivity = pandapower_pipeline_model.connectivity[["eq_fk", "bus_id"]]
    if ext_grid.is_empty():
        log.warning("No external grid found")
        return pandapower_pipeline_model

    ext_grid = (
        ext_grid.join(pandapower_pipeline_model.resource, on="uuid", how="left")
        .join(connectivity, left_on="uuid", right_on="eq_fk", how="inner")
        .drop_nulls(subset="bus_id")
    )

    ext_grid = ext_grid.rename(EXT_GRID_COL_MAPPING).with_row_index(name="id")
    pandapower_pipeline_model.panda_power_schema = pandapower_pipeline_model.panda_power_schema.add_table(ext_grid=ext_grid)
    return pandapower_pipeline_model
