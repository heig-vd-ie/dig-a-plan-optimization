import polars as pl
from polars import col as c

from pandapower_exporter.models import PandaPowerSchema
from twindigrid_changes.schema import ChangesSchema
from twindigrid_sql.schema.enum import GeneratingUnitType

from general_function import generate_log

from pandapower_exporter.pandapower_pipeline_model import PandaPowerPipelineModel


log = generate_log(name=__name__)


SGEN_TYPE_MAPPING: dict[str, str] = {
    GeneratingUnitType.PV.value: "PV",
    GeneratingUnitType.HYDRO.value: "WP",
    GeneratingUnitType.CHP.value: "CHP",
}

SGEN_COL_MAPPING: dict[str, str] = {"bus_id": "bus"}


def sgen_parser(pandapower_pipeline_model: PandaPowerPipelineModel) -> PandaPowerPipelineModel:
    

    sgen: pl.DataFrame = pandapower_pipeline_model.change_schema.generating_unit.as_polars()

    if sgen.is_empty():
        return pandapower_pipeline_model

    connectivity = pandapower_pipeline_model.connectivity[["eq_fk", "bus_id", "container_fk"]]

    sgen = (
        sgen.with_columns(
            pl.struct("rated_s", "pv_slope", "pv_orientation", c("uuid").alias("eq_fk"))
            .struct.json_encode()
            .alias("metadata")
        )
        .join(connectivity, left_on="uuid", right_on="eq_fk", how="left")
        .drop_nulls(subset="bus_id")
    )

    sgen = (
        sgen.group_by("container_fk", "bus_id", "type")
        .agg((c("rated_s").sum() / 1e3).alias("sn_mva"), "metadata")  # From kVA to MVA
        .with_columns(
            c("type").replace_strict(SGEN_TYPE_MAPPING).alias("type"),
            ("[" + c("metadata").list.join(", ") + "]").alias("metadata"),
        )
    )

    sgen = sgen.join(pandapower_pipeline_model.resource, left_on="container_fk", right_on="uuid", how="inner")

    sgen = sgen.rename(SGEN_COL_MAPPING).with_row_index(name="id")
    pandapower_pipeline_model.panda_power_schema = pandapower_pipeline_model.panda_power_schema.add_table(sgen=sgen)
    
    return pandapower_pipeline_model
