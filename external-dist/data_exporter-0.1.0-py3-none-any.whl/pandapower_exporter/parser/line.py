import polars as pl
from polars import col as c

from pandapower_exporter.models import PandaPowerSchema
from twindigrid_changes.schema import ChangesSchema
from twindigrid_sql.schema.enum import TerminalSide
import numpy as np

from general_function import generate_log

from pandapower_exporter.pandapower_pipeline_model import PandaPowerPipelineModel

log = generate_log(name=__name__)

LINE_COL_MAPPING: dict[str, str] = {
    TerminalSide.T1.value: "from_bus",
    TerminalSide.T2.value: "to_bus",
    "length": "length_km",
    "r": "r_ohm_per_km",
    "x": "x_ohm_per_km",
    "b": "c_nf_per_km",
    "r0": "r0_ohm_per_km",
    "x0": "x0_ohm_per_km",
    "b0": "c0_nf_per_km",
    "current_limit": "max_i_ka",
    "is_underground": "type",
    "uuid": "eq_fk",
}
LINE_TYPE_MAPPING: dict = {True: "cs", False: "ol"}


def line_parser(pandapower_pipeline_model: PandaPowerPipelineModel) -> PandaPowerPipelineModel:
    
    change_schema: ChangesSchema = pandapower_pipeline_model.change_schema

    line: pl.DataFrame = change_schema.branch.as_polars().drop("diff")

    if line.is_empty():
        log.warning("No line found")
        return pandapower_pipeline_model

    branch_parameter_event: pl.DataFrame = (
        change_schema.branch_parameter_event.as_polars()
        .sort("timestamp", descending=True)
        .filter(c("eq_fk").is_first_distinct())
        .drop(["diff", "uuid", "timestamp", "heartbeat"])
    )

    connectivity = pandapower_pipeline_model.connectivity.pivot(on="side", index="eq_fk", values="bus_id")

    line = (
        line.join(pandapower_pipeline_model.resource, on="uuid", how="left")
        .join(connectivity, left_on="uuid", right_on="eq_fk", how="inner")
        .join(branch_parameter_event, left_on="uuid", right_on="eq_fk", how="left")
        .drop_nulls(subset=[TerminalSide.T1.value, TerminalSide.T2.value])
    )

    line = (
        line.rename(LINE_COL_MAPPING)
        .with_row_index(name="id")
        .with_columns(
            c(["c_nf_per_km"]) / (2 * np.pi * 50) * 1e9,  # convert Simens to nF
            c("max_i_ka") / 1e3,  # convert A to kA
            c("type").replace_strict(LINE_TYPE_MAPPING, default=None),
        )
    )
    pandapower_pipeline_model.panda_power_schema = pandapower_pipeline_model.panda_power_schema.add_table(line=line)
    return pandapower_pipeline_model
