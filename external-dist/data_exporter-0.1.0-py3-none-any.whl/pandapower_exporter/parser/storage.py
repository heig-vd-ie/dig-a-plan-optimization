import polars as pl
from polars import col as c

from pandapower_exporter.models import PandaPowerSchema
from twindigrid_changes.schema import ChangesSchema

from general_function import generate_log

from pandapower_exporter.pandapower_pipeline_model import PandaPowerPipelineModel


log = generate_log(name=__name__)

STORAGE_COL_MAPPING = {
    "uuid": "eq_fk",
    "rated_s": "sn_mva",
    "rated_e": "max_e_mwh",
    "min_charging_p": "min_p_mw",
    "max_charging_p": "max_p_mw",
    "bus_id": "bus",
}


def storage_parser(pandapower_pipeline_model: PandaPowerPipelineModel) -> PandaPowerPipelineModel:
    
    storage: pl.DataFrame = pandapower_pipeline_model.change_schema.bess.as_polars()
    connectivity = pandapower_pipeline_model.connectivity[["eq_fk", "bus_id"]]

    if storage.is_empty():
        return pandapower_pipeline_model

    storage = (
        storage.join(pandapower_pipeline_model.resource, on="uuid", how="left")
        .join(connectivity, left_on="uuid", right_on="eq_fk", how="inner")
        .drop_nulls(subset="bus_id")
    )

    storage = (
        storage.rename(STORAGE_COL_MAPPING)
        .with_columns(
            c(["sn_mva", "max_e_mwh", "min_p_mw", "max_p_mw"]) / 1e3  # form k to M
        )
        .with_row_index(name="id")
    )
    pandapower_pipeline_model.panda_power_schema = pandapower_pipeline_model.panda_power_schema.add_table(storage=storage)
    return pandapower_pipeline_model    
