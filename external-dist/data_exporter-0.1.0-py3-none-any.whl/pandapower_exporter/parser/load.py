import polars as pl
from polars import col as c
from datetime import datetime

from pandapower_exporter.models import PandaPowerSchema
from twindigrid_changes.schema import ChangesSchema
from general_function import generate_log


from twindigrid_sql.entries.source import CONVENTIONAL_METER, SMART_METER

from pandapower_exporter.pandapower_pipeline_model import PandaPowerPipelineModel


log = generate_log(name=__name__)

LOAD_COL_MAPPING: dict[str, str] = {"bus_id": "bus"}


def load_parser(pandapower_pipeline_model: PandaPowerPipelineModel) -> PandaPowerPipelineModel:
    
    change_schema: ChangesSchema = pandapower_pipeline_model.change_schema

    energy_consumer: pl.DataFrame = change_schema.energy_consumer.as_polars()

    if energy_consumer.is_empty():
        log.warning("No energy_consumer found")
        return pandapower_pipeline_model

    connectivity = pandapower_pipeline_model.connectivity[["eq_fk", "bus_id", "container_fk"]]
    energy_consumer = energy_consumer.join(
        connectivity, left_on="uuid", right_on="eq_fk", how="inner"
    ).with_columns(
        (c("rated_s") / 1e3).replace({0.0: None}).alias("sn_mva"), # From kVA to MVA and should be always strictly positive
        pl.struct("rated_s", "profile_type", "egid", c("uuid").alias("eq_fk"))
        .struct.json_encode()
        .alias("metadata"),
    )

    yearly_measurement = (
        change_schema.measurement.as_polars()
        .filter(c("source_fk") == CONVENTIONAL_METER)
        .join(
            change_schema.measurement_span.as_polars(),
            left_on="uuid",
            right_on="measurement_fk",
            how="left",
        )
        .sort("start")
        .filter(c("uuid").is_first_distinct())
        .select(
            "resource_fk",
            (c("double_value") * pl.lit(10).pow(c("unit_multiplier")) / 1e6).alias(
                "yearly_consumption"
            ),
        )
        .group_by("resource_fk")
        .agg(c("yearly_consumption").sum())
    )

    load: pl.DataFrame = (
        energy_consumer.join(
            pandapower_pipeline_model.resource, left_on="container_fk", right_on="uuid", how="left"
        )
        .join(
            yearly_measurement,
            left_on="container_fk",
            right_on="resource_fk",
            how="left",
        )
        .drop_nulls(subset="bus_id")
    )

    load = load.rename(LOAD_COL_MAPPING).with_row_index(name="id")
    
    pandapower_pipeline_model.panda_power_schema = pandapower_pipeline_model.panda_power_schema.add_table(load=load)

    return pandapower_pipeline_model
