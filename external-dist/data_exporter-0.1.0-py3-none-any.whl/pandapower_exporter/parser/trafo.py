import polars as pl
import numpy as np
from polars import col as c

from pandapower_exporter.models import PandaPowerSchema
from twindigrid_changes.schema import ChangesSchema
from twindigrid_sql.schema.enum import TerminalSide

from pandapower_exporter.models._literal_entries import VECTOR_GROUP

from general_function import generate_log

from pandapower_exporter.pandapower_pipeline_model import PandaPowerPipelineModel

log = generate_log(name=__name__)

TRASFO_COL_MAPPING: dict[str, str] = {
    "uuid": "eq_fk",
    "rated_s": "sn_mva",
    "nominal_voltage_t1": "vn_hv_kv",
    "nominal_voltage_t2": "vn_lv_kv",
    "phase_angle_t2": "shift_degree",
    "tap_pos_t2": "tap_pos",
    "tap_pos_t1": "tap2_pos",
    "tap_neutral_t2": "tap_neutral",
    "tap_neutral_t1": "tap2_neutral",
    "tap_min_t2": "tap_min",
    "tap_min_t1": "tap2_min",
    "tap_max_t2": "tap_max",
    "tap_max_t1": "tap2_max",
    "tap_step_percent_t2": "tap_step_percent",
    "tap_step_percent_t1": "tap2_step_percent",
    TerminalSide.T1.value: "hv_bus",
    TerminalSide.T2.value: "lv_bus",
}
TAP_SIDE_MAPPING: dict[str, str] = {
    TerminalSide.T1.value: "hv",
    TerminalSide.T2.value: "lv",
}


PIVOT_LIST: list[str] = [
    "ck",
    "phase_angle",
    "nominal_voltage",
    "tap_pos",
    "tap_neutral",
    "tap_min",
    "tap_max",
    "tap_step_percent",
]


def get_tap_values(data: dict) -> dict:
    if data["tap_list"] is None:
        return dict(
            zip(
                ["tap_pos", "tap_neutral", "tap_min", "tap_max", "tap_step_percent"],
                5 * [None],
            )
        )
    results: dict = {}
    results["tap_min"] = 0
    results["tap_max"] = len(data["tap_list"]) - 1

    if data["tap_list"][-1] < data["tap_value"]:
        results["tap_pos"] = results["tap_max"]
    else:
        results["tap_pos"] = np.argwhere(
            np.array(data["tap_list"]) >= data["tap_value"]
        )[0][0]

    if data["tap_list"][-1] < data["nominal_voltage"]:
        results["tap_neutral"] = results["tap_max"]
    else:
        results["tap_neutral"] = np.argwhere(
            np.array(data["tap_list"]) >= data["nominal_voltage"]
        )[0][0]
    results["tap_step_percent"] = round(
        100
        * (data["tap_list"][1] - data["tap_list"][0])
        / (1e3 * data["nominal_voltage"]),
        4,
    )
    return results


def get_complex_modulus(real: pl.Expr, imag: pl.Expr) -> pl.Expr:
    return (real**2 + imag**2).sqrt()


def get_voltage_ratio(
    impedance: pl.Expr, rated_s: pl.Expr, nominal_voltage: pl.Expr
) -> pl.Expr:
    return 100 * impedance * rated_s / (nominal_voltage**2)


def get_oc_current_ratio(
    admittance: pl.Expr, rated_s: pl.Expr, nominal_voltage: pl.Expr
) -> pl.Expr:
    return 100 * admittance * (nominal_voltage**2) / rated_s


def get_iron_losses(conductance: pl.Expr, nominal_voltage: pl.Expr) -> pl.Expr:
    return conductance * (nominal_voltage**2) / 1e3  # iron losses in kW


def get_vector_group(ck_t1: pl.Expr, ck_t2: pl.Expr) -> pl.Expr:
    vector_group: pl.Expr = pl.concat_str(
        ck_t1.str.to_uppercase(), ck_t2.str.to_lowercase()
    )
    return (
        pl.when(vector_group.is_in(list(VECTOR_GROUP.__args__)))
        .then(vector_group)
        .otherwise(pl.lit(None))
    )


def trafo_parser(pandapower_pipeline_model: PandaPowerPipelineModel) -> PandaPowerPipelineModel:
    
    change_schema: ChangesSchema = pandapower_pipeline_model.change_schema

    trafo: pl.DataFrame = change_schema.transformer.as_polars().drop("diff")

    if trafo.is_empty():
        log.warning("No transformer found")
        return pandapower_pipeline_model

    connectivity = pandapower_pipeline_model.connectivity.pivot(on="side", index="eq_fk", values="bus_id")

    transformer_end = (
        change_schema.transformer_end.as_polars()
        .filter(c("eq_fk").count().over("eq_fk") == 2)
        .with_columns(pl.concat_str(c("eq_fk"), c("side")).alias("eq_fk_side"))
    )

    tap = (
        change_schema.tap.as_polars()
        .group_by("eq_fk", "side")
        .agg(c("value").alias("tap_list"))
        .filter(c("tap_list").list.len() > 1)
        .select(
            pl.concat_str(c("eq_fk"), c("side")).alias("eq_fk_side"),
            c("tap_list").list.sort().alias("tap_list"),
        )
    )

    tap_event: pl.DataFrame = (
        change_schema.tap_event.as_polars()
        .sort("timestamp", descending=True)
        .filter(pl.struct("eq_fk", "side").is_first_distinct())
        .select(
            pl.concat_str(c("eq_fk"), c("side")).alias("eq_fk_side"),
            c("value").alias("tap_value"),
        )
    )

    return_dtype = pl.Struct(
        [
            pl.Field("tap_pos", pl.Int64),
            pl.Field("tap_neutral", pl.Int64),
            pl.Field("tap_min", pl.Int64),
            pl.Field("tap_max", pl.Int64),
            pl.Field("tap_step_percent", pl.Float64),
        ]
    )

    transformer_end = (
        transformer_end.join(tap, on="eq_fk_side", how="left")
        .join(tap_event, on="eq_fk_side", how="left")
        .with_columns(
            c("side").replace_strict(TAP_SIDE_MAPPING, default=None).alias("tap_side"),
            c("nominal_voltage") / 1e3,  # convert to kV
            pl.struct(["nominal_voltage", "tap_list", "tap_value"])
            .map_elements(get_tap_values, return_dtype=return_dtype)
            .alias("tap_data"),
        )
        .unnest("tap_data")
        .pivot(on="side", index="eq_fk", values=PIVOT_LIST)
    )

    transformer_parameter_event: pl.DataFrame = (
        change_schema.transformer_parameter_event.as_polars()
        .sort("timestamp", descending=True)
        .filter(c("side") == TerminalSide.T2.value)
        .filter(c("eq_fk").is_first_distinct())
        .drop(["diff", "uuid", "side", "timestamp", "heartbeat"])
    )

    trafo = (
        trafo.filter(c("uuid").is_in(transformer_end["eq_fk"].to_list()))
        .join(pandapower_pipeline_model.resource, on="uuid", how="left")
        .join(connectivity, left_on="uuid", right_on="eq_fk", how="inner")
        .join(transformer_end, left_on="uuid", right_on="eq_fk", how="left")
        .join(transformer_parameter_event, left_on="uuid", right_on="eq_fk", how="left")
        .drop_nulls(subset=[TerminalSide.T1.value, TerminalSide.T2.value])
    )

    trafo = (
        trafo.rename(TRASFO_COL_MAPPING)
        .with_columns(
            get_vector_group(c("ck_t1"), c("ck_t2")).alias("vector_group"),
            c("shift_degree") * 30,  # convert to degrees
            c("sn_mva") / 1e3,  # convert from kVA to MVA
            get_complex_modulus(c("r"), c("x")).alias("z"),
            get_complex_modulus(c("g"), c("b")).alias("y"),
            get_complex_modulus(c("r0"), c("x0")).alias("z0"),
            get_complex_modulus(c("g0"), c("b0")).alias("y0"),
        )
        .with_columns(
            get_voltage_ratio(c("r"), 1e6 * c("sn_mva"), 1e3 * c("vn_lv_kv")).alias(
                "vkr_percent"
            ),  # convert MVA to VA and kV to V
            get_voltage_ratio(c("z"), 1e6 * c("sn_mva"), 1e3 * c("vn_lv_kv")).alias(
                "vk_percent"
            ),
            get_oc_current_ratio(c("y"), 1e6 * c("sn_mva"), 1e3 * c("vn_lv_kv")).alias(
                "i0_percent"
            ),
            get_iron_losses(c("g"), 1e3 * c("vn_lv_kv")).alias("pfe_kw"),
            # get_voltage_ratio(c("r0"), 1e6*c("sn_mva"), 1e3*c("vn_lv_kv")).alias("vkr0_percent"),
            # get_voltage_ratio(c("z0"), 1e6*c("sn_mva"), 1e3*c("vn_lv_kv")).alias("vk0_percent"),
        )
        .with_row_index(name="id")
    )
    pandapower_pipeline_model.panda_power_schema = pandapower_pipeline_model.panda_power_schema.add_table(trafo=trafo)
    return pandapower_pipeline_model
