from typing import Optional
from typing_extensions import Literal
import polars as pl
from polars import col as c

from pandapower_exporter.models import PandaPowerSchema
from twindigrid_changes.schema import ChangesSchema
from twindigrid_sql.entries.equipment_class import BUSBAR_SECTION

from general_function import pl_to_dict, generate_log

from pandapower_exporter.pandapower_pipeline_model import PandaPowerPipelineModel

log = generate_log(name=__name__)

BUS_MAPPING = {"base_voltage_fk": "vn_kv"}


def bus_parser(
    pandapower_pipeline_model: PandaPowerPipelineModel, 
    filtered_uuid_list: Optional[list[str]] = None, 
    filtered_uuid_type: Literal["cn_fk", "eq_fk"] = "cn_fk"
) -> PandaPowerPipelineModel:
    
    change_schema: ChangesSchema = pandapower_pipeline_model.change_schema
    resource: pl.DataFrame = pandapower_pipeline_model.resource


    filter_mask: pl.Expr = (
        pl.lit(True) if filtered_uuid_list is None else c(filtered_uuid_type).is_in(filtered_uuid_list)
    )

    connectivity: pl.DataFrame = (
        change_schema.connectivity.as_polars()
        .filter(~c("indirect"))
        .filter(filter_mask)
    )

    if connectivity.is_empty():
        log.warning("No bus found")
        return pandapower_pipeline_model

    resource = resource.filter(~c("geo").str.contains("LINESTRING"))

    bus: pl.DataFrame = connectivity.join(
        change_schema.connectivity_node.as_polars()["uuid", "base_voltage_fk"],
        left_on="cn_fk",
        right_on="uuid",
    ).unique(
        "cn_fk"
    )  # .with_columns(
    #     pl.coalesce(c("geo_1"), c("geo_2")).alias("geo")
    # ).sort("geo").unique("cn_fk")

    bus = (
        bus.rename(BUS_MAPPING).with_row_index(name="id").with_columns(c("vn_kv") / 1e3)
    )  # Convert to kV

    bus_id_mapping = pl_to_dict(bus.select(["cn_fk", "id"]))
    connectivity = connectivity.with_columns(
        c("cn_fk").replace_strict(bus_id_mapping, default=None).alias("bus_id")
    )
    bus = bus.with_columns(
        c("cn_fk").alias("name"),
    )
    pandapower_pipeline_model.panda_power_schema = pandapower_pipeline_model.panda_power_schema.add_table(bus=bus)
    pandapower_pipeline_model.connectivity = connectivity
    return  pandapower_pipeline_model
