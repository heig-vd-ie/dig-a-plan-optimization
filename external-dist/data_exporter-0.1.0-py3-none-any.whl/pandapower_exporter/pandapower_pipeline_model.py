from dataclasses import dataclass, field
from typing_extensions import Literal, Optional

import polars as pl
from twindigrid_changes.schema import ChangesSchema

from pandapower_exporter.models import PandaPowerSchema

from config import settings


@dataclass
class PandaPowerPipelineModel:
    """
    Model for pandapower exporter pipeline.
    This model is used to define the structure of the pipeline and its components.
    """
    change_schema: ChangesSchema
    panda_power_schema: PandaPowerSchema = PandaPowerSchema()
    connectivity: pl.DataFrame = field(default_factory=pl.DataFrame)
    resource: pl.DataFrame = field(default_factory=pl.DataFrame)

    