from typing import Optional
from typing_extensions import Literal
import pandapower as pp
import tqdm

from pandapower_exporter import pandapower_pipeline_model
from pandapower_exporter.models import PandaPowerSchema
from twindigrid_changes.schema import ChangesSchema

from pandapower_exporter.pandapower_pipeline_model import PandaPowerPipelineModel
from pandapower_exporter.parser.resource import resource_parser
from pandapower_exporter.parser.bus import bus_parser
from pandapower_exporter.parser.line import line_parser
from pandapower_exporter.parser.trafo import trafo_parser
from pandapower_exporter.parser.switch import switch_parser
from pandapower_exporter.parser.load import load_parser
from pandapower_exporter.parser.sgen import sgen_parser
from pandapower_exporter.parser.ext_grid import ext_grid_parser
from pandapower_exporter.parser.storage import storage_parser


def pandapower_parser(
    change_schema: ChangesSchema,
    filtered_uuid_list: Optional[list[str]] = None,
    filtered_uuid_type: Literal["cn_fk", "eq_fk"] = "cn_fk",
    use_switch_event: bool = True,
    drop_unsupplied_equipment: bool = False,
) -> pp.pandapowerNet:

    pandapower_pipeline_model = PandaPowerPipelineModel(
        change_schema=change_schema)
    
    with tqdm.tqdm(total=9, desc="Parsing schema to pandapower") as pbar:
        pandapower_pipeline_model = resource_parser(pandapower_pipeline_model=pandapower_pipeline_model)
        pbar.update()
        pandapower_pipeline_model = bus_parser(
            pandapower_pipeline_model=pandapower_pipeline_model,
            filtered_uuid_list=filtered_uuid_list, filtered_uuid_type=filtered_uuid_type)
        pbar.update()
        pandapower_pipeline_model = line_parser(pandapower_pipeline_model=pandapower_pipeline_model)
        pbar.update()
        pandapower_pipeline_model = trafo_parser(pandapower_pipeline_model=pandapower_pipeline_model)
        pbar.update()
        pandapower_pipeline_model = switch_parser(
            pandapower_pipeline_model=pandapower_pipeline_model,
            use_switch_event=use_switch_event)
        pbar.update()
        pandapower_pipeline_model = load_parser(pandapower_pipeline_model=pandapower_pipeline_model)
        pbar.update()
        pandapower_pipeline_model = sgen_parser(pandapower_pipeline_model=pandapower_pipeline_model)
        pbar.update()
        pandapower_pipeline_model = storage_parser(pandapower_pipeline_model=pandapower_pipeline_model)
        pandapower_pipeline_model = ext_grid_parser(pandapower_pipeline_model=pandapower_pipeline_model)
        pp_net: pp.pandapowerNet = pandapower_pipeline_model.panda_power_schema.schema_to_pandapower()
        pbar.update()

        if drop_unsupplied_equipment:
            pp.set_isolated_areas_out_of_service(pp_net, respect_switches=True)
            pp.drop_out_of_service_elements(pp_net)
            _ = pp.create_continuous_bus_index(pp_net)
        pbar.update()

    return pp_net
