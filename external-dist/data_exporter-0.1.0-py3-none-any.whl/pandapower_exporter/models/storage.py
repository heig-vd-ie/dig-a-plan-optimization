import patito as pt
import polars as pl

from typing_extensions import Optional

from pandapower_exporter.models._literal_entries import optional_unique


class Storage(pt.Model):
    """
    Model representing a static generator (sgen) in pandapower.
    """

    name: Optional[str] = pt.Field(
        dtype=pl.Utf8, description="Name of the storage system"
    )
    bus: int = pt.Field(
        dtype=pl.UInt32, ge=0, description="Unique id used as index by pandapower"
    )
    p_mw: float = pt.Field(
        dtype=pl.Float64, default=0.0, description="Active power in MW"
    )
    q_mvar: Optional[float] = pt.Field(
        dtype=pl.Float64, default=0.0, description="Reactive power in MVAr"
    )
    sn_mva: Optional[float] = pt.Field(
        dtype=pl.Float64, ge=0, description="Nominal power in MVA"
    )
    scaling: float = pt.Field(
        dtype=pl.Float64,
        default=1.0,
        ge=0,
        description="Scaling factor for the storage system",
    )
    type: Optional[str] = pt.Field(
        dtype=pl.Utf8, description="Type of the storage system"
    )
    in_service: bool = pt.Field(
        dtype=pl.Boolean,
        default=True,
        description="Indicates if the static generator is in service",
    )
    max_e_mwh: Optional[float] = pt.Field(
        dtype=pl.Float64,
        default=0.0,
        description="Maximum energy content of the storage (maximum charge level)",
    )
    min_e_mwh: Optional[float] = pt.Field(
        dtype=pl.Float64,
        default=0.0,
        description="Minimum energy content of the storage (maximum charge level)",
    )
    soc_percent: Optional[float] = pt.Field(
        dtype=pl.Float64, ge=0, le=100, description="The state of charge of the storage"
    )
    max_p_mw: Optional[float] = pt.Field(
        dtype=pl.Float64, description="Maximum active power in MW"
    )
    min_p_mw: Optional[float] = pt.Field(
        dtype=pl.Float64, description="Minimum active power in MW"
    )
    max_q_mvar: Optional[float] = pt.Field(
        dtype=pl.Float64, description="Maximum reactive power in MVAr"
    )
    min_q_mvar: Optional[float] = pt.Field(
        dtype=pl.Float64, description="Minimum reactive power in MVAr"
    )
    controllable: bool = pt.Field(
        dtype=pl.Boolean,
        default=False,
        description="Indicates if the storage is controllable",
    )
    eq_fk: Optional[str] = pt.Field(
        dtype=pl.Utf8,
        constraints=optional_unique(pt.field),
        description="Container uuid from DataSchema",
    )
    geo: Optional[str] = pt.Field(dtype=pl.Utf8, description="Geographical location")
    id: int = pt.Field(
        unique=True,
        dtype=pl.UInt32,
        ge=0,
        description="Unique id used as index by pandapower",
    )
