import patito as pt
import polars as pl
from typing_extensions import Optional

from pandapower_exporter.models._literal_entries import (
    VECTOR_GROUP,
    TAP_SIDE,
    literal_constraint,
    optional_unique,
)


class Trafo(pt.Model):
    """
    Pandapower Transformer Model
    """

    name: Optional[str] = pt.Field(dtype=pl.Utf8, description="Name of the transformer")
    std_type: Optional[str] = pt.Field(
        dtype=pl.Utf8, default=None, description="Transformer standard type name"
    )

    hv_bus: int = pt.Field(dtype=pl.UInt32, ge=0, description="High voltage bus ID")
    lv_bus: int = pt.Field(dtype=pl.UInt32, ge=0, description="Low voltage bus ID")
    sn_mva: float = pt.Field(
        dtype=pl.Float64, gt=0, description="Rated power of the transformer in MVA"
    )
    vn_hv_kv: float = pt.Field(
        dtype=pl.Float64, gt=0, description="Rated voltage on high voltage side in kV"
    )
    vn_lv_kv: float = pt.Field(
        dtype=pl.Float64, gt=0, description="Rated voltage on low voltage side in kV"
    )

    vk_percent: float = pt.Field(
        dtype=pl.Float64, gt=0, description="Short-circuit voltage in percent"
    )
    vkr_percent: float = pt.Field(
        dtype=pl.Float64, gt=0, description="Short-circuit losses in percent"
    )
    pfe_kw: float = pt.Field(dtype=pl.Float64, ge=0, description="Iron losses in kW")
    i0_percent: float = pt.Field(
        dtype=pl.Float64, ge=0, description="Open-circuit current in percent"
    )

    vk0_percent: Optional[float] = pt.Field(
        dtype=pl.Float64,
        gt=0,
        description="Zero sequence relative sort-circuit voltage in percent",
    )
    vkr0_percent: Optional[float] = pt.Field(
        dtype=pl.Float64,
        gt=0,
        description="Real part of zero sequence relative short-circuit voltage",
    )
    mag0_percent: Optional[float] = pt.Field(
        dtype=pl.Float64, gt=0, description="Short-circuit voltage in percent"
    )
    mag0_rx: Optional[float] = pt.Field(
        dtype=pl.Float64, gt=0, description="Zero sequence magnetizing impedance/ vk0"
    )
    si0_hv_partial: Optional[float] = pt.Field(
        dtype=pl.Float64,
        description="Distribution of zero sequence leakage impedances for HV side",
    )

    df: float = pt.Field(
        dtype=pl.Float64, default=1.0, ge=0, le=1.0, description="Derating factor"
    )
    parallel: int = pt.Field(
        dtype=pl.UInt32, default=1, ge=1, description="Number of parallel Trafo systems"
    )
    in_service: bool = pt.Field(
        dtype=pl.Boolean,
        default=True,
        description="Indicates if the equipment is in service",
    )

    vector_group: Optional[VECTOR_GROUP] = pt.Field(
        dtype=pl.Utf8,
        constraints=literal_constraint(pt.field, VECTOR_GROUP),
        description="Vector Groups ( required for zero sequence model of transformer )",
    )
    shift_degree: float = pt.Field(
        dtype=pl.Float64, default=0.0, ge=0, description="Phase shift angle in degrees"
    )

    oltc: bool = pt.Field(
        dtype=pl.Boolean,
        default=False,
        description="Indicates if the equipment is in service",
    )
    power_station_unit: bool = pt.Field(
        dtype=pl.Boolean,
        default=False,
        description="Indicates if the equipment is in service",
    )

    tap_side: Optional[TAP_SIDE] = pt.Field(
        dtype=pl.Utf8,
        constraints=literal_constraint(pt.field, TAP_SIDE),
        description="Tap changer side (hv/lv)",
    )
    tap_pos: Optional[int] = pt.Field(dtype=pl.Int64, description="Actual tap position")
    tap_neutral: Optional[int] = pt.Field(
        dtype=pl.Int64, description="Neutral tap position"
    )
    tap_min: Optional[int] = pt.Field(
        dtype=pl.Int64, description="Minimum tap position"
    )
    tap_max: Optional[int] = pt.Field(
        dtype=pl.Int64, description="Maximum tap position"
    )
    tap_step_percent: Optional[float] = pt.Field(
        dtype=pl.Float64, gt=0, description="Tap step size in percent"
    )
    tap_step_degree: Optional[float] = pt.Field(
        dtype=pl.Float64, ge=0, default=0, description="Tap step size in degrees"
    )
    tap_phase_shifter: Optional[bool] = pt.Field(
        dtype=pl.Boolean,
        default=False,
        description="Indicates if the transformer is a phase shifter",
    )

    tap2_side: Optional[TAP_SIDE] = pt.Field(
        dtype=pl.Utf8,
        constraints=literal_constraint(pt.field, TAP_SIDE),
        description="Tap 2 changer side (hv/lv)",
    )
    tap2_pos: Optional[int] = pt.Field(
        dtype=pl.Int64, description="Actual tap 2 position"
    )
    tap2_neutral: Optional[int] = pt.Field(
        dtype=pl.Int64, description="Neutral tap 2 position"
    )
    tap2_min: Optional[int] = pt.Field(
        dtype=pl.Int64, description="Minimum tap 2 position"
    )
    tap2_max: Optional[int] = pt.Field(
        dtype=pl.Int64, description="Maximum tap 2 position"
    )
    tap2_step_percent: Optional[float] = pt.Field(
        dtype=pl.Float64, ge=0, description="Tap step 2 size in percent"
    )
    tap2_step_degree: Optional[float] = pt.Field(
        dtype=pl.Float64, ge=0, default=0, description="Tap step 2 size in degrees"
    )
    tap2_phase_shifter: Optional[bool] = pt.Field(
        dtype=pl.Boolean,
        default=False,
        description="Indicates if the transformer is a phase shifter",
    )
    eq_fk: Optional[str] = pt.Field(
        dtype=pl.Utf8,
        constraints=optional_unique(pt.field),
        description="Unique uuid from DataSchema",
    )
    dso_code: Optional[str] = pt.Field(
        dtype=pl.Utf8, description="DSO code of the line"
    )
    geo: Optional[str] = pt.Field(dtype=pl.Utf8, description="Geographical location")
    id: int = pt.Field(
        unique=True,
        dtype=pl.UInt32,
        ge=0,
        description="Unique id used as index by pandapower",
    )
