import patito as pt
import polars as pl
from typing_extensions import Optional
from pandapower_exporter.models._literal_entries import (
    TAP_SIDE_3W,
    VECTOR_GROUP,
    literal_constraint,
    optional_unique,
)


class Trafo3w(pt.Model):
    """
    A model representing a three-winding transformer in pandapower.
    """

    name: Optional[str] = pt.Field(dtype=pl.Utf8, description="Name of the transformer")
    std_type: Optional[str] = pt.Field(
        dtype=pl.Utf8, default=None, description="Transformer standard type name"
    )
    hv_bus: int = pt.Field(dtype=pl.Int64, ge=0, description="High voltage bus ID")
    mv_bus: int = pt.Field(dtype=pl.Int64, ge=0, description="Medium voltage bus ID")
    lv_bus: int = pt.Field(dtype=pl.Int64, ge=0, description="Low voltage bus ID")

    sn_hv_mva: float = pt.Field(
        dtype=pl.Float64,
        gt=0,
        description="high voltage rated power of the transformer in MVA",
    )
    sn_mv_mva: float = pt.Field(
        dtype=pl.Float64,
        gt=0,
        description="Medium voltage rated power of the transformer in MVA",
    )
    sn_lv_mva: float = pt.Field(
        dtype=pl.Float64,
        gt=0,
        description="Low voltage rated power of the transformer in MVA",
    )

    vn_hv_kv: float = pt.Field(
        dtype=pl.Float64, gt=0, description="Rated voltage on high voltage side in kV"
    )
    vn_mv_kv: float = pt.Field(
        dtype=pl.Float64, gt=0, description="Rated voltage on medium voltage side in kV"
    )
    vn_lv_kv: float = pt.Field(
        dtype=pl.Float64, gt=0, description="Rated voltage on low voltage side in kV"
    )

    vk_hv_percent: float = pt.Field(
        dtype=pl.Float64,
        gt=0,
        description="Short-circuit voltage of the high voltage side in percent",
    )
    vk_mv_percent: float = pt.Field(
        dtype=pl.Float64,
        gt=0,
        description="Short-circuit voltage of the medium voltage side in percent",
    )
    vk_lv_percent: float = pt.Field(
        dtype=pl.Float64,
        gt=0,
        description="Short-circuit voltage of the low voltage side in percent",
    )
    vkr_hv_percent: float = pt.Field(
        dtype=pl.Float64,
        gt=0,
        description="Short-circuit resistance of the high voltage side in percent",
    )
    vkr_mv_percent: float = pt.Field(
        dtype=pl.Float64,
        gt=0,
        description="Short-circuit resistance of the medium voltage side in percent",
    )
    vkr_lv_percent: float = pt.Field(
        dtype=pl.Float64,
        gt=0,
        description="Short-circuit resistance of the low voltage side in percent",
    )
    pfe_kw: float = pt.Field(dtype=pl.Float64, ge=0, description="Iron losses in kW")
    i0_percent: float = pt.Field(
        dtype=pl.Float64, ge=0, description="Open-circuit current in percent"
    )

    in_service: bool = pt.Field(
        dtype=pl.Boolean,
        default=True,
        description="Indicates if the equipment is in service",
    )
    parallel: int = pt.Field(
        dtype=pl.Int64, default=1, ge=1, description="Number of parallel Trafo systems"
    )
    df: float = pt.Field(
        dtype=pl.Float64, default=1.0, ge=0, le=1.0, description="Derating factor"
    )

    shift_mv_degree: float = pt.Field(
        dtype=pl.Float64,
        default=0.0,
        ge=0,
        description="Phase shift angle of the medium voltage side in degrees",
    )
    shift_lv_degree: float = pt.Field(
        dtype=pl.Float64,
        default=0.0,
        ge=0,
        description="Phase shift angle of the low voltage side in degrees",
    )

    tap_side: Optional[TAP_SIDE_3W] = pt.Field(
        dtype=pl.Utf8,
        constraints=literal_constraint(pt.field, TAP_SIDE_3W),
        description="Tap changer side (hv/mv/lv)",
    )
    tap_pos: Optional[int] = pt.Field(dtype=pl.Int64, description="Actual tap position")
    tap_neutral: Optional[int] = pt.Field(
        dtype=pl.Int64, description="Neutral tap position"
    )
    tap_min: Optional[int] = pt.Field(
        dtype=pl.Int64, description="Minimum tap position"
    )
    tap_max: Optional[int] = pt.Field(
        dtype=pl.Int64, description="Maximum tap position"
    )
    tap_step_percent: Optional[float] = pt.Field(
        dtype=pl.Float64, gt=0, description="Tap step size in percent"
    )
    tap_step_degree: Optional[float] = pt.Field(
        dtype=pl.Float64, ge=0, description="Tap step size in degrees"
    )
    tap_phase_shifter: bool = pt.Field(
        dtype=pl.Boolean,
        default=False,
        description="Indicates if the transformer is a phase shifter",
    )
    tap_at_star_point: bool = pt.Field(
        dtype=pl.Boolean,
        default=False,
        description="Indicates if the transformer is a phase shifter",
    )

    vk0_hv_percent: Optional[float] = pt.Field(
        dtype=pl.Float64,
        gt=0,
        description="Short-circuit voltage of the high voltage side in percent",
    )
    vk0_mv_percent: Optional[float] = pt.Field(
        dtype=pl.Float64,
        gt=0,
        description="Short-circuit voltage of the medium voltage side in percent",
    )
    vk0_lv_percent: Optional[float] = pt.Field(
        dtype=pl.Float64,
        gt=0,
        description="Short-circuit voltage of the low voltage side in percent",
    )
    vkr0_hv_percent: Optional[float] = pt.Field(
        dtype=pl.Float64,
        gt=0,
        description="Short-circuit resistance of the high voltage side in percent",
    )
    vkr0_mv_percent: Optional[float] = pt.Field(
        dtype=pl.Float64,
        gt=0,
        description="Short-circuit resistance of the medium voltage side in percent",
    )
    vkr0_lv_percent: Optional[float] = pt.Field(
        dtype=pl.Float64,
        gt=0,
        description="Short-circuit resistance of the low voltage side in percent",
    )

    vector_group: Optional[VECTOR_GROUP] = pt.Field(
        dtype=pl.Utf8,
        constraints=literal_constraint(pt.field, VECTOR_GROUP),
        description="Vector Groups ( required for zero sequence model of transformer )",
    )

    eq_fk: Optional[str] = pt.Field(
        dtype=pl.Utf8,
        constraints=optional_unique(pt.field),
        description="Unique uuid from DataSchema",
    )
    dso_code: Optional[str] = pt.Field(
        dtype=pl.Utf8, description="DSO code of the line"
    )
    geo: Optional[str] = pt.Field(dtype=pl.Utf8, description="Geographical location")
    id: int = pt.Field(
        unique=True,
        dtype=pl.Int64,
        ge=0,
        description="Unique id used as index by pandapower",
    )
