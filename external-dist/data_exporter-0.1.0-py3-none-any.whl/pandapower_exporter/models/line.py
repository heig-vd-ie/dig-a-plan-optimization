import patito as pt
import polars as pl

from typing_extensions import Optional
from pandapower_exporter.models._literal_entries import (
    LINE_TYPE,
    literal_constraint,
    optional_unique,
)


class Line(pt.Model):
    name: Optional[str] = pt.Field(dtype=pl.Utf8, description="Name of the line")
    std_type: Optional[str] = pt.Field(
        dtype=pl.Utf8, default=None, description="Transformer standard type name"
    )
    from_bus: int = pt.Field(
        dtype=pl.UInt32, ge=0, description="ID of the bus at which the line starts"
    )
    to_bus: int = pt.Field(
        dtype=pl.UInt32, ge=0, description="ID of the bus at which the line ends"
    )
    length_km: float = pt.Field(
        dtype=pl.Float64, gt=0, description="Length of the line in km"
    )

    r_ohm_per_km: float = pt.Field(
        dtype=pl.Float64, ge=0, description="Resistance per km"
    )
    x_ohm_per_km: float = pt.Field(
        dtype=pl.Float64, ge=0, description="Reactance per km"
    )
    c_nf_per_km: float = pt.Field(
        dtype=pl.Float64, ge=0, description="Capacitance per km"
    )
    g_us_per_km: float = pt.Field(
        dtype=pl.Float64,
        ge=0,
        default=0,
        description="Dielectric conductance in micro Siemens per km",
    )
    r0_ohm_per_km: Optional[float] = pt.Field(
        dtype=pl.Float64, ge=0, description="Resistance per km"
    )
    x0_ohm_per_km: Optional[float] = pt.Field(
        dtype=pl.Float64, ge=0, description="Reactance per km"
    )
    c0_nf_per_km: Optional[float] = pt.Field(
        dtype=pl.Float64, ge=0, description="Capacitance per km"
    )
    max_i_ka: float = pt.Field(
        dtype=pl.Float64, gt=0, description="Maximum current in kA"
    )
    max_loading_percent: float = pt.Field(
        dtype=pl.Float64, default=100.0, gt=0, description="Maximum current in kA"
    )
    section: Optional[float] = pt.Field(
        dtype=pl.Float64, ge=0, description="Section of the line"
    )
    df: float = pt.Field(
        dtype=pl.Float64, default=1.0, ge=0, le=1.0, description="Derating factor"
    )
    parallel: int = pt.Field(
        dtype=pl.UInt32, default=1, ge=1, description="Number of parallel line systems"
    )
    in_service: bool = pt.Field(
        dtype=pl.Boolean,
        default=True,
        description="Indicates if the line is in service",
    )
    type: LINE_TYPE = pt.Field(
        dtype=pl.Utf8,
        default="ol",
        constraints=literal_constraint(pt.field, LINE_TYPE),
        description="Type of line",
    )
    eq_fk: Optional[str] = pt.Field(
        dtype=pl.Utf8,
        constraints=optional_unique(pt.field),
        description="Unique uuid from DataSchema",
    )
    dso_code: Optional[str] = pt.Field(
        dtype=pl.Utf8, description="DSO code of the line"
    )
    geo: Optional[str] = pt.Field(dtype=pl.Utf8, description="Geographical location")
    id: int = pt.Field(
        unique=True,
        dtype=pl.UInt32,
        ge=0,
        description="Unique id used as index by pandapower",
    )
