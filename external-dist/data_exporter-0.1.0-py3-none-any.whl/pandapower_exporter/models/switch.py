import patito as pt
import polars as pl
from typing_extensions import Optional

from pandapower_exporter.models._literal_entries import (
    SWITCH_CONN_TYPE,
    SWITCH_TYPE,
    literal_constraint,
    optional_unique,
)


class Switch(pt.Model):
    """
    Pandapower Switch Object
    """

    name: Optional[str] = pt.Field(
        dtype=pl.Utf8, description="The name of the switch", default=None
    )
    bus: int = pt.Field(
        dtype=pl.UInt32,
        description="The bus to which the switch is connected",
        default=0,
    )
    element: int = pt.Field(
        dtype=pl.UInt32,
        description="The element to which the switch is connected",
        default=0,
    )
    et: SWITCH_CONN_TYPE = pt.Field(
        dtype=pl.Utf8,
        default="b",
        constraints=literal_constraint(pt.field, SWITCH_CONN_TYPE),
        description="The type of element (bus or line)",
    )
    closed: bool = pt.Field(
        dtype=pl.Boolean,
        description="The status of the switch (open or closed)",
        default=True,
    )
    type: Optional[SWITCH_TYPE] = pt.Field(
        dtype=pl.Utf8,
        constraints=literal_constraint(pt.field, SWITCH_TYPE),
        description="The type of switch",
        default=None,
    )
    in_ka: Optional[float] = pt.Field(
        dtype=pl.Float64, description="The type of switch", default=None
    )
    z_ohm: float = pt.Field(
        dtype=pl.Float64,
        ge=0,
        default=0,
        description="Conducting impedance of the switch",
    )
    eq_fk: Optional[str] = pt.Field(
        dtype=pl.Utf8,
        constraints=optional_unique(pt.field),
        description="Unique uuid from DataSchema",
    )
    dso_code: Optional[str] = pt.Field(
        dtype=pl.Utf8, description="DSO code of the line"
    )
    geo: Optional[str] = pt.Field(dtype=pl.Utf8, description="Geographical location")
    id: int = pt.Field(
        unique=True,
        dtype=pl.UInt32,
        ge=0,
        description="Unique id used as index by pandapower",
    )
