import patito as pt
import polars as pl
from typing_extensions import Optional


class ExtGrid(pt.Model):
    """
    Patito model for pandapower external grid object.
    """

    name: Optional[str] = pt.Field(
        dtype=pl.Utf8, description="Name of the external grid"
    )
    bus: int = pt.Field(
        dtype=pl.UInt32, ge=0, description="Unique id used as index by pandapower"
    )
    vm_pu: Optional[float] = pt.Field(
        dtype=pl.Float64, default=1.0, gt=0, description="Voltage magnitude in per unit"
    )
    va_degree: Optional[float] = pt.Field(
        dtype=pl.Float64, default=0.0, description="Voltage angle in degrees"
    )
    in_service: bool = pt.Field(
        dtype=pl.Boolean,
        default=True,
        description="Indicates if the equipment is in service",
    )
    slack_weight: float = pt.Field(
        dtype=pl.Float64, description="Slack weight", default=1.0
    )

    s_sc_max_mva: Optional[float] = pt.Field(
        dtype=pl.Float64, description="Maximum short-circuit power in MVA"
    )
    s_sc_min_mva: Optional[float] = pt.Field(
        dtype=pl.Float64, description="Minimum short-circuit power in MVA"
    )
    max_p_mw: Optional[float] = pt.Field(
        dtype=pl.Float64, ge=0, description="Maximum active power in MW"
    )
    min_p_mw: Optional[float] = pt.Field(
        dtype=pl.Float64, ge=0, description="Minimum active power in MW"
    )
    max_q_mvar: Optional[float] = pt.Field(
        dtype=pl.Float64, description="Maximum reactive power in MVar"
    )
    min_q_mvar: Optional[float] = pt.Field(
        dtype=pl.Float64, description="Minimum reactive power in MVar"
    )
    rx_max: Optional[float] = pt.Field(
        dtype=pl.Float64, description="Maximum R/X ratio"
    )
    rx_min: Optional[float] = pt.Field(
        dtype=pl.Float64, description="Minimum R/X ratio"
    )
    r0x0_max: Optional[float] = pt.Field(
        dtype=pl.Float64, description="Maximum R0/X0 ratio"
    )
    x0x_max: Optional[float] = pt.Field(
        dtype=pl.Float64, description="Maximum X0/X ratio"
    )
    controllable: Optional[bool] = pt.Field(
        dtype=pl.Boolean, description="Indicates if the external grid is controllable"
    )

    eq_fk: Optional[str] = pt.Field(
        unique=True, dtype=pl.Utf8, description="Unique uuid from DataSchema"
    )
    geo: Optional[str] = pt.Field(dtype=pl.Utf8, description="Geographical location")
    dso_code: Optional[str] = pt.Field(
        dtype=pl.Utf8, description="DSO code of the line"
    )
    id: int = pt.Field(
        unique=True,
        dtype=pl.UInt32,
        ge=0,
        description="Unique id used as index by pandapower",
    )

    # Generate a dictionary of data from ExtGrid template
