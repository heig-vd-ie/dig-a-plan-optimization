import patito as pt
import polars as pl

from typing_extensions import Optional

from pandapower_exporter.models._literal_entries import (
    SGEN_TYPE,
    literal_constraint,
    optional_unique,
)


class Sgen(pt.Model):
    """
    Model representing a static generator (sgen) in pandapower.
    """

    name: Optional[str] = pt.Field(
        dtype=pl.Utf8, description="Name of the static generator"
    )
    bus: int = pt.Field(
        dtype=pl.UInt32, ge=0, description="Unique id used as index by pandapower"
    )
    p_mw: float = pt.Field(
        dtype=pl.Float64, default=0.0, description="Active power in MW"
    )
    q_mvar: Optional[float] = pt.Field(
        dtype=pl.Float64, default=0.0, description="Reactive power in MVAr"
    )
    sn_mva: Optional[float] = pt.Field(
        dtype=pl.Float64, ge=0, description="Nominal power in MVA"
    )
    scaling: float = pt.Field(
        dtype=pl.Float64,
        default=1.0,
        ge=0,
        description="Scaling factor for the static generator",
    )
    type: Optional[SGEN_TYPE] = pt.Field(
        dtype=pl.Utf8,
        constraints=literal_constraint(pt.field, SGEN_TYPE),
        description="Type of the static generator",
    )
    metadata: Optional[str] = pt.Field(dtype=pl.Utf8, description="Sgen type metadata")
    in_service: bool = pt.Field(
        dtype=pl.Boolean,
        default=True,
        description="Indicates if the static generator is in service",
    )
    max_p_mw: Optional[float] = pt.Field(
        dtype=pl.Float64, description="Maximum active power in MW"
    )
    min_p_mw: Optional[float] = pt.Field(
        dtype=pl.Float64, description="Minimum active power in MW"
    )
    max_q_mvar: Optional[float] = pt.Field(
        dtype=pl.Float64, description="Maximum reactive power in MVAr"
    )
    min_q_mvar: Optional[float] = pt.Field(
        dtype=pl.Float64, description="Minimum reactive power in MVAr"
    )
    current_source: bool = pt.Field(
        dtype=pl.Boolean,
        default=False,
        description="Indicates if the static generator is controllable",
    )
    controllable: bool = pt.Field(
        dtype=pl.Boolean,
        default=False,
        description="Indicates if the static generator is controllable",
    )
    container_fk: Optional[str] = pt.Field(
        dtype=pl.Utf8, description="Container uuid from DataSchema"
    )
    geo: Optional[str] = pt.Field(dtype=pl.Utf8, description="Geographical location")
    id: int = pt.Field(
        unique=True,
        dtype=pl.UInt32,
        ge=0,
        description="Unique id used as index by pandapower",
    )
