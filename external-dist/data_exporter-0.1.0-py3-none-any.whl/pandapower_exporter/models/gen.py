import patito as pt
import polars as pl

from typing_extensions import Optional

from pandapower_exporter.models._literal_entries import (
    SGEN_TYPE,
    literal_constraint,
    optional_unique,
)


class Gen(pt.Model):
    """
    Model representing a static generator (sgen) in pandapower.
    """

    name: Optional[str] = pt.Field(
        dtype=pl.Utf8, description="Name of the static generator"
    )
    bus: int = pt.Field(
        dtype=pl.UInt32, ge=0, description="Unique id used as index by pandapower"
    )
    p_mw: float = pt.Field(dtype=pl.Float64, description="Active power in MW")
    vm_pu: float = pt.Field(
        dtype=pl.Float64,
        ge=0,
        default=0.0,
        description="The voltage set point of the generator",
    )
    sn_mva: Optional[float] = pt.Field(
        dtype=pl.Float64, ge=0, description="Nominal power in MVA"
    )
    scaling: float = pt.Field(
        dtype=pl.Float64,
        default=1.0,
        ge=0,
        description="Scaling factor for the static generator",
    )
    slack: bool = pt.Field(dtype=pl.Boolean, default=False, description="Is slack node")
    slack_weight: float = pt.Field(
        dtype=pl.Float64,
        default=0.0,
        ge=0,
        description="Contribution factor for distributed slack power flow",
    )
    type: Optional[SGEN_TYPE] = pt.Field(
        dtype=pl.Utf8,
        constraints=literal_constraint(pt.field, SGEN_TYPE),
        description="Type of the static generator",
    )
    metadata: Optional[str] = pt.Field(dtype=pl.Utf8, description="Sgen type metadata")
    in_service: bool = pt.Field(
        dtype=pl.Boolean,
        default=True,
        description="Indicates if the static generator is in service",
    )
    max_p_mw: Optional[float] = pt.Field(
        dtype=pl.Float64, description="Maximum active power in MW"
    )
    min_p_mw: Optional[float] = pt.Field(
        dtype=pl.Float64, description="Minimum active power in MW"
    )
    max_q_mvar: Optional[float] = pt.Field(
        dtype=pl.Float64, description="Maximum reactive power in MVAr"
    )
    min_q_mvar: Optional[float] = pt.Field(
        dtype=pl.Float64, description="Minimum reactive power in MVAr"
    )
    controllable: bool = pt.Field(
        dtype=pl.Boolean,
        default=False,
        description="Indicates if the static generator is controllable",
    )
    eq_fk: Optional[str] = pt.Field(
        dtype=pl.Utf8,
        constraints=optional_unique(pt.field),
        description="Unique uuid from DataSchema",
    )
    dso_code: Optional[str] = pt.Field(
        dtype=pl.Utf8, description="DSO code of the line"
    )
    geo: Optional[str] = pt.Field(dtype=pl.Utf8, description="Geographical location")
    id: int = pt.Field(
        unique=True,
        dtype=pl.UInt32,
        ge=0,
        description="Unique id used as index by pandapower",
    )
