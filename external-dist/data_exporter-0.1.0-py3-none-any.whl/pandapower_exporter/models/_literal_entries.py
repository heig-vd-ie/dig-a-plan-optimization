from typing import Literal
import polars as pl

BUS_TYPE = Literal["b", "n", "m"]
LINE_TYPE = Literal["ol", "cs"]
LOAD_TYPE = Literal["wye", "delta"]
SGEN_TYPE = Literal["PV", "WP", "CHP", "", "wye", "delta", "SGEN"]
SWITCH_TYPE = Literal["CB", "LS", "LBS", "DS"]
SWITCH_CONN_TYPE = Literal["b", "l", "t", "t3"]
VECTOR_GROUP = Literal["Dyn", "Yyn", "Yzn", "YNyn", "YNyn"]
TAP_SIDE = Literal["hv", "lv"]
TAP_SIDE_3W = Literal["hv", "mv", "lv"]


def literal_constraint(field: pl.Expr, values) -> pl.Expr:
    return field.is_in(list(values.__args__)).alias("literal_constraint")


def optional_unique(field: pl.Expr) -> pl.Expr:
    return field.drop_nulls().is_duplicated().sum() == 0
