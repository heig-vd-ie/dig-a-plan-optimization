import patito as pt
import polars as pl
from typing_extensions import Optional
from pandapower_exporter.models._literal_entries import (
    LOAD_TYPE,
    literal_constraint,
    optional_unique,
)


class Load(pt.Model):
    """
    Represents a load object in pandapower with default values and constraints.
    """

    name: Optional[str] = pt.Field(dtype=pl.Utf8, description="Name of the load")
    bus: int = pt.Field(
        dtype=pl.UInt32, ge=0, description="Bus number to which the load is connected"
    )
    p_mw: Optional[float] = pt.Field(
        dtype=pl.Float64, default=0.0, description="Active power in MW"
    )
    q_mvar: Optional[float] = pt.Field(
        dtype=pl.Float64, default=0.0, description="Reactive power in MVAr"
    )
    sn_mva: Optional[float] = pt.Field(
        dtype=pl.Float64, ge=0.0, description="Reactive power in MVAr"
    )
    yearly_consumption: Optional[float] = pt.Field(
        dtype=pl.Float64, ge=0.0, description="Reactive power in MVAr"
    )
    metadata: Optional[str] = pt.Field(
        dtype=pl.Utf8, description="Consumer type metadata"
    )
    const_z_percent: float = pt.Field(
        dtype=pl.Float64,
        default=0.0,
        ge=0.0,
        le=100.0,
        description="percentage of p_mw and q_mvar that is associated to constant impedance load at rated voltage [%]",
    )
    const_i_percent: float = pt.Field(
        dtype=pl.Float64,
        default=0.0,
        ge=0.0,
        le=100.0,
        description="percentage of p_mw and q_mvar that is associated to constant current  load at rated voltage [%]",
    )

    scaling: float = pt.Field(
        dtype=pl.Float64, default=1.0, ge=0.0, description="Scaling factor for the load"
    )
    in_service: bool = pt.Field(
        dtype=pl.Boolean,
        default=True,
        description="Indicates if the load is in service",
    )
    type: Optional[LOAD_TYPE] = pt.Field(
        dtype=pl.Utf8,
        constraints=literal_constraint(pt.field, LOAD_TYPE),
        description="Type of the load",
    )
    controllable: bool = pt.Field(
        dtype=pl.Boolean,
        default=False,
        description="Indicates if the load is controllable",
    )
    container_fk: Optional[str] = pt.Field(
        dtype=pl.Utf8, description="Unique container from DataSchema"
    )
    dso_code: Optional[str] = pt.Field(
        dtype=pl.Utf8, description="DSO code of the line"
    )
    geo: Optional[str] = pt.Field(dtype=pl.Utf8, description="Geographical location")
    id: int = pt.Field(
        unique=True,
        dtype=pl.UInt32,
        ge=0,
        description="Unique id used as index by pandapower",
    )
