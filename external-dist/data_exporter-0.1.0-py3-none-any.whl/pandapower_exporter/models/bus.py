import patito as pt
import polars as pl
from typing_extensions import Optional
from pandapower_exporter.models._literal_entries import (
    BUS_TYPE,
    literal_constraint,
    optional_unique,
)


class Bus(pt.Model):
    name: Optional[str] = pt.Field(dtype=pl.Utf8, description="Name of the bus")
    vn_kv: float = pt.Field(dtype=pl.Float64, gt=0, description="Nominal voltage in kV")
    type: BUS_TYPE = pt.Field(
        dtype=pl.Utf8,
        default="n",
        constraints=literal_constraint(pt.field, BUS_TYPE),
        description="Type of bus",
    )
    zone: Optional[str] = pt.Field(dtype=pl.Utf8, description="Zone of the bus")
    in_service: bool = pt.Field(
        dtype=pl.Boolean, default=True, description="Bus in service status"
    )
    max_vm_pu: Optional[float] = pt.Field(
        dtype=pl.Float64,
        default=1.1,
        gt=0,
        description="Maximum voltage magnitude in per unit",
    )
    min_vm_pu: Optional[float] = pt.Field(
        dtype=pl.Float64,
        default=0.9,
        gt=0,
        description="Minimum voltage magnitude in per unit",
    )
    cn_fk: Optional[str] = pt.Field(
        dtype=pl.Utf8,
        constraints=optional_unique(pt.field),
        description="Unique uuid from DataSchema",
    )
    geo: Optional[str] = pt.Field(dtype=pl.Utf8, description="Geographical location")
    dso_code: Optional[str] = pt.Field(
        dtype=pl.Utf8, description="DSO code of the line"
    )
    id: int = pt.Field(
        unique=True,
        dtype=pl.UInt32,
        ge=0,
        description="Unique id used as index by pandapower",
    )
