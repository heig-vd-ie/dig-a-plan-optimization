from twindigrid_changes.schema import ChangesSchema
from twindigrid_changes import models as changes_models
from general_function import snake_to_camel, duckdb_to_dict
import patito as pt


def duckdb_to_changes_schema(file_path: str) -> ChangesSchema:
    data = duckdb_to_dict(file_path=file_path)
    schema_dict = {}
    for table_name, table in data.items():
        pt_model: pt.Model = getattr(changes_models, snake_to_camel(table_name))
        schema_dict[table_name] = pt.Model.DataFrame(table).set_model(pt_model).cast()

    return ChangesSchema().replace(**schema_dict)
