import importlib
import importlib.resources
import twindigrid_sql.entries.abstraction as abstractionEntries
import twindigrid_sql.entries.measurementSource as measurementSourceEntries
from twindigrid_schema.schema import Abstraction, Base, MeasurementSource
import os
import sys
from pathlib import Path
import multiprocessing as mp

import sqlalchemy as sa
from sqlalchemy.orm import sessionmaker


def create_engine(sqlite_file: str):
    engine = sa.create_engine(f"sqlite+pysqlite:///{sqlite_file}", echo=False, future=True)
    return engine


def create_database(sqlite_file: str, drop_existing=False):
    if drop_existing:
        try:
            os.remove(sqlite_file)
        except FileNotFoundError:
            pass

    engine = create_engine(sqlite_file)

    Base.metadata.create_all(engine)

    fill_default_entries(engine)

    return engine


def fill_default_entries(engine):
    # Create default entries
    Session = sessionmaker(bind=engine)
    with Session() as session:
        objs = [
            MeasurementSource(uuid=measurementSourceEntries.SCADA_UUID, name="scada"),
            MeasurementSource(uuid=measurementSourceEntries.SMART_METER_UUID, name="smartMeter"),
            MeasurementSource(uuid=measurementSourceEntries.CONVENTIONAL_METER_UUID, name="conventionalMeter"),
            MeasurementSource(uuid=measurementSourceEntries.AGGREGATED_METER_UUID, name="aggregatedMeter"),
            MeasurementSource(uuid=measurementSourceEntries.GRIDEYE_UUID, name="gridEye"),
            Abstraction(uuid=abstractionEntries.PHYSICAL_UUID, name="physical"),
            Abstraction(uuid=abstractionEntries.ABSTRACT_UUID, name="abstract")
        ]
        session.add_all(objs)
        session.commit()


if __name__ == "__main__":
    db = "db/database.sqlite"
    create_database(db)
