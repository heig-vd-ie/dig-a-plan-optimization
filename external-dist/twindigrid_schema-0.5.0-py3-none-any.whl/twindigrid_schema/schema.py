### Import packages
from __future__ import annotations
import enum
import datetime
from typing import Dict, Generic, Optional, TypeVar, Type, Union
from typing_extensions import Self
from sqlalchemy import Column, ForeignKey, String, UniqueConstraint, event, null, select
from sqlalchemy.orm import relationship, declarative_mixin, aliased
from sqlalchemy.ext.declarative import declarative_base, declared_attr
from sqlalchemy.sql.expression import or_
from sqlalchemy.sql.schema import Sequence
import sqlalchemy.types as types
from sqlalchemy.sql.sqltypes import Boolean, DateTime, Float, Enum
from sqlalchemy_utils import UUIDType
from shapely.geometry import Point, LineString, shape, mapping
import uuid
import functools
import warnings

import twindigrid_sql.entries.abstraction as abstractionEntries

### Global variables
warnings.filterwarnings("ignore")
UUIDType.cache_ok = True
Base = declarative_base()

class AssetType(enum.Enum):
    """Used to specify the concrete type of the specialized class linked to the different asset tables"""
    Equipment = 0
    Bess = 1
    Branch = 2
    BusbarSection = 3
    EnergyConsumer = 4
    ExternalNetwork = 5
    Pv = 6
    Switch = 7
    Transformer = 8
    SynchronousGenerationUnit = 9
    MeasurementDevice = 10


class GeoType(types.TypeDecorator):
    impl = types.JSON
    cache_ok = True

    def process_bind_param(self, value, dialect):
        if value is None:
            return null()
        return mapping(value)

    def process_result_value(self, value, dialect):
        if value is None:
            return None
        return shape(value)


# # # # # # # # # # # # # #
# MIXIN
#
# Used to prevent copying the same column for each real class

### Classes
@declarative_mixin
class Installable(object):
    installDate: datetime.datetime = Column(DateTime, nullable=False)
    uninstallDate: datetime.datetime = Column(DateTime, index=True)


@declarative_mixin
class HasUuid(object):
    uuid = Column(UUIDType, primary_key=True, default=uuid.uuid4)


@declarative_mixin
class Record(HasUuid):
    timestamp: datetime.datetime = Column(DateTime, nullable=False)
    valid = Column(Boolean)


# # # # # # # # # # # # # #
# CONNECTIVITY
#
# Used to connect equipment together

EQT = TypeVar('EQT', bound='EquipmentWithTerminal')


class Abstraction(Base, HasUuid):
    __tablename__ = 'Abstraction'
    name = Column(String)

    terminalAbstractions: list[TerminalAbstraction] = relationship('TerminalAbstraction', back_populates='abstraction')
    groupMappings: list[GroupMapping] = relationship('GroupMapping', back_populates='abstraction')
    eqs: list[Equipment] = relationship('Equipment', back_populates='abstraction')

    def maps(self, source: list[Equipment], sink: list[Equipment]):
        """
        Map the source group of equipment to the sink group of equipment.

        Modify the sink equipment to be created for the current abstraction.
        """
        gm = GroupMapping(abstraction=self)
        for eq in source:
            egm = EquipmentGroupMapping(eq=eq, groupMapping=gm, isSink=False)
        for eq in sink:
            egm = EquipmentGroupMapping(eq=eq, groupMapping=gm, isSink=True)
            eq.abstraction = self
        return gm

    def connect(self, *terminals: Terminal):
        """
        On the current abstraction, connect the given terminals together (via TerminalAbstraction and a ConnectivityNode)
        """
        cn = ConnectivityNode()
        for terminal in terminals:
            ta = TerminalAbstraction(abstraction=self, terminal=terminal, connectivityNode=cn)
        return cn


class TopologicalNodeMapping(Base):
    __tablename__ = 'TopologicalNodeMapping'
    terminalAbstractionFK: uuid.UUID = Column(UUIDType, ForeignKey('TerminalAbstraction.uuid'), primary_key=True)
    topologicalNodeFK: uuid.UUID = Column(UUIDType, ForeignKey('TopologicalNode.uuid'), primary_key=True)


class TerminalAbstraction(Base, HasUuid):
    __tablename__ = 'TerminalAbstraction'
    terminalFK: uuid.UUID = Column(UUIDType, ForeignKey('Terminal.uuid'), nullable=False)
    abstractionFK: uuid.UUID = Column(UUIDType, ForeignKey('Abstraction.uuid'), nullable=False)
    connectivityNodeFK: uuid.UUID = Column(UUIDType, ForeignKey('ConnectivityNode.uuid', ondelete='CASCADE'))

    UniqueConstraint(abstractionFK, terminalFK)

    terminal: Terminal = relationship("Terminal", back_populates="terminalAbstractions")
    abstraction: Abstraction = relationship("Abstraction", back_populates="terminalAbstractions")
    connectivityNode: ConnectivityNode = relationship("ConnectivityNode", back_populates="terminals")
    topologicalNodes: list[TopologicalNode] = relationship("TopologicalNode", secondary='TopologicalNodeMapping', back_populates="terminals")


class Terminal(Base, HasUuid, Generic[EQT]):
    """
    This class is never directly instanciated. For each equipment with terminal a specialized terminal class is automatically created.
    """

    class Phases(enum.Enum):
        ABC = 1
        ABCn = 2
        An = 3
        Bn = 4
        Cn = 5
        AB = 6
        BC = 7
        AC = 8

    __tablename__ = 'Terminal'
    phases = Column(Enum(Phases), nullable=False, default=Phases.ABCn)
    concreteType = Column(Enum(AssetType))
    otherSideFK: uuid.UUID = Column(UUIDType, ForeignKey('Terminal.uuid'))
    eqFK: uuid.UUID = Column(UUIDType, ForeignKey('Equipment.uuid'))

    @declared_attr
    def otherSide(cls) -> Terminal[EQT]:
        # self referential one-to-one relationship
        # is not automatically back populated
        return relationship('Terminal', uselist=False, post_update=True)

    terminalAbstractions: list[TerminalAbstraction] = relationship('TerminalAbstraction', back_populates='terminal')
    measurementTerminals: list[MeasurementTerminal] = relationship('MeasurementTerminal', back_populates='terminal')

    eq: EQT

    __mapper_args__ = {
        'polymorphic_identity': 'Terminal',
        'polymorphic_on': concreteType
    }

    def __repr__(self) -> str:
        id = f'{self.eq.name}.{self.eq.terminalName(self)}' if self.eq is not None else '?'
        return f"Terminal({self.concreteType.name} {id})"

    def terminalAbstraction(self, abstraction: Abstraction) -> Optional[TerminalAbstraction]:
        """Return the the TerminalAbstraction for the given Abstraction if it exists"""
        return next((ta for ta in self.terminalAbstractions if ta.abstractionFK == abstraction.uuid), None)

    @staticmethod
    def _generateSpecialisationClass(equipmentCls) -> Type[Terminal[EQT]]:
        name = f"{equipmentCls.__name__}Terminal"

        def _one_terminal_relationship(target: Type['EquipmentWithOneTerminal']):
            return relationship(target, back_populates="terminal", lazy='joined', uselist=False, foreign_keys=f"{equipmentCls.__name__}.terminalFK")

        def _two_terminals_relationship(target: Type['EquipmentWithTwoTerminals']):
            return relationship(target,
                                primaryjoin=or_(Terminal.uuid == target.terminal1FK, Terminal.uuid == target.terminal2FK),
                                viewonly=True, overlaps="terminal1,terminal2", uselist=False)

        if issubclass(equipmentCls, EquipmentWithOneTerminal):
            eqrel = _one_terminal_relationship(equipmentCls)
        elif issubclass(equipmentCls, EquipmentWithTwoTerminals):
            eqrel = _two_terminals_relationship(equipmentCls)
        else:
            raise Exception(
                f"Can't create Terminal specialisation: Equipment '{equipmentCls.__name__}' does not inherit from either 'EquipmentWithOneTerminal' or 'EquipmentWithTwoTerminal'")

        class terminalSpecialization(Terminal):
            eq: EQT = eqrel

            __mapper_args__ = {
                'polymorphic_identity': equipmentCls.__mapper_args__['polymorphic_identity'],
            }

        terminalSpecialization.__name__ = name
        return terminalSpecialization


class ConnectivityNode(Base, HasUuid):
    __tablename__ = 'ConnectivityNode'

    terminals: list[TerminalAbstraction] = relationship("TerminalAbstraction", back_populates="connectivityNode", lazy='joined',
                                                        cascade='all, delete', passive_deletes=True)

    def connect_more(self, *terminals: Terminal, abstraction: Abstraction = None) -> Self:
        """ Connect additional terminals to the current connectivity node.
        At least one terminal must have already be connected.
        """
        # Find abstraction if not given
        if abstraction is None:
            abstraction = self.terminals[0].abstraction  # every terminalAbstraction of a connectivityNode MUST have the same abstraction
        elif all(abstraction.uuid == ta.abstractionFK for ta in self.terminals):
            raise ValueError("Given abstraction must match abstraction of connected TerminalAbstraction")

        for terminal in terminals:
            ta = TerminalAbstraction(abstraction=abstraction, terminal=terminal, connectivityNode=self)
        return self


class TopologicalNode(Base, HasUuid, Installable):
    __tablename__ = 'TopologicalNode'

    terminals: list[TerminalAbstraction] = relationship("TerminalAbstraction", secondary='TopologicalNodeMapping', back_populates="topologicalNodes")

    @classmethod
    def connect(cls, installDate: DateTime, *connectivityNodes: ConnectivityNode):
        ts = [ta for cn in connectivityNodes for ta in cn.terminals]
        tn = cls(installDate = installDate)
        tn.terminals = ts
        return tn

    @staticmethod
    def at(timestamp: DateTime):
        stmt = select(TopologicalNode)\
            .filter(TopologicalNode.installDate <= timestamp)\
            .filter(or_(TopologicalNode.uninstallDate.is_(None), TopologicalNode.uninstallDate > timestamp))
        subq = stmt.subquery()
        return aliased(TopologicalNode, subq)

    @staticmethod
    def ofTerminalAbstraction(timestamp: DateTime, ta: TerminalAbstraction):
        stmt = select(TopologicalNode.at(timestamp))\
            .join(TopologicalNodeMapping)\
            .filter(ta.uuid == TopologicalNodeMapping.terminalAbstractionFK)
        return stmt


# # # # # # # # # # # # # #
# ASSET EVENTS
#
# Events fired for installed assets

PEQ = TypeVar('PEQ', bound='EquipmentWithParameterEvent')


class SwitchEvent(Base, Record):
    class Source(enum.Enum):
        scada = 1
        estimated = 2

    __tablename__ = 'SwitchEvent'
    open = Column(Boolean)
    valueSource: Source = Column(Enum(Source, name="SwitchSource"), nullable=False, default=Source.scada)
    switchFK: uuid.UUID = Column(UUIDType, ForeignKey('Switch.uuid'), nullable=False)

    switch: Switch = relationship('Switch', back_populates='switchEvents')


class Tap(Base, HasUuid):
    __tablename__ = 'Tap'
    transformerFK: uuid.UUID = Column(UUIDType, ForeignKey('Transformer.uuid'), nullable=False)
    value = Column(Float, nullable=False)
    isTapHv = Column(Boolean, nullable=False)

    transformer: Transformer = relationship('Transformer', back_populates='taps')
    tapEvents: list[TapEvent] = relationship('TapEvent', back_populates='tap')

    def generateEvent(self, **kwargs) -> TapEvent:
        tapEvent = TapEvent(tap=self, **kwargs)
        return tapEvent


class TapEvent(Base, Record):
    class Source(enum.Enum):
        scada = 1
        estimated = 2

    __tablename__ = 'TapEvent'
    tapFK: uuid.UUID = Column(UUIDType, ForeignKey('Tap.uuid'), nullable=False)
    valueSource: Source = Column(Enum(Source, name="TapSource"), nullable=False)

    tap: Tap = relationship('Tap', back_populates='tapEvents')

class ParameterEvent(Record, Generic[PEQ]):
    class Source(enum.Enum):
        nominal = 1
        estimated = 2

    __tablename__ = 'ParameterEvent'
    b = Column(Float, default=0.0)
    b0 = Column(Float, default=0.0)
    g = Column(Float, default=0.0)
    g0 = Column(Float, default=0.0)
    r = Column(Float, default=0.0)
    r0 = Column(Float, default=0.0)
    x = Column(Float, default=0.0)
    x0 = Column(Float, default=0.0)
    valueSource: Source = Column(Enum(Source, name="ParameterSource"))

    eqFK: uuid.UUID
    eq: PEQ

    __mapper_args__ = {
        'polymorphic_identity': 'ParameterEvent',
        'polymorphic_on': type
    }

    @staticmethod
    def _generateSpecialisationClass(equipmentCls) -> Type[ParameterEvent[PEQ]]:
        name = f"{equipmentCls.__name__}ParameterEvent"

        class parameterEventSpecialization(Base, ParameterEvent):
            __tablename__ = name
            eqFK: uuid.UUID = Column(UUIDType, ForeignKey(equipmentCls.uuid), nullable=False)
            eq: PEQ = relationship(equipmentCls, back_populates="parameterEvents", uselist=False)

            __mapper_args__ = {
                'polymorphic_identity': name,
            }

        parameterEventSpecialization.__name__ = name
        return parameterEventSpecialization

    def to_dict(self):
        return {"b": self.b, "b0": self.b0, "g": self.g,
                "g0": self.g0, "r": self.r, "r0": self.r0,
                "x": self.x, "x0": self.x0}


# # # # # # # # # # # # # #
# ASSETS
#
# Installed assets

EQ = TypeVar('EQ', bound='Equipment')


class Asset(Base, HasUuid, Generic[EQ]):
    """Used to regroup instances of equipment that are the same asset."""
    __tablename__ = 'Asset'
    concreteType = Column(Enum(AssetType))

    eqs: list[EQ]

    __mapper_args__ = {
        'polymorphic_identity': 'Asset',
        'polymorphic_on': concreteType
    }

    @staticmethod
    def _generateSpecialisationClass(equipmentCls) -> Type[Asset[EQ]]:
        name = f"{equipmentCls.__name__}Asset"

        class assetSpecialization(Asset):
            eqs: list[EQ] = relationship(equipmentCls, back_populates="asset", lazy='joined')

            __mapper_args__ = {
                'polymorphic_identity': equipmentCls.__mapper_args__['polymorphic_identity'],
            }

        assetSpecialization.__name__ = name
        return assetSpecialization


class EquipmentGroupMapping(Base, HasUuid, Generic[EQ]):
    __tablename__ = 'EquipmentGroupMapping'
    equipmentFK: uuid.UUID = Column(UUIDType, ForeignKey('Equipment.uuid'), nullable=False)
    groupMappingFK: uuid.UUID = Column(UUIDType, ForeignKey('GroupMapping.uuid'), nullable=False)
    isSink = Column(Boolean, nullable=False)

    groupMapping: GroupMapping = relationship('GroupMapping', back_populates='eqGroupMappings')
    eq: Equipment = relationship('Equipment', back_populates='eqGroupMapping')



class GroupMapping(Base, HasUuid):
    __tablename__ = 'GroupMapping'
    abstractionFK: uuid.UUID = Column(UUIDType, ForeignKey('Abstraction.uuid'), nullable=False)

    abstraction: Abstraction = relationship('Abstraction', back_populates='groupMappings')
    eqGroupMappings: list[EquipmentGroupMapping] = relationship('EquipmentGroupMapping', back_populates='groupMapping')



class Equipment(Base, HasUuid, Installable):
    __tablename__ = 'Equipment'
    concreteType = Column(Enum(AssetType))
    abstractionFK: uuid.UUID = Column(UUIDType, ForeignKey('Abstraction.uuid'), nullable=False, default=abstractionEntries.PHYSICAL_UUID)

    eqGroupMapping: list[EquipmentGroupMapping] = relationship('EquipmentGroupMapping', back_populates='eq')
    abstraction: Abstraction = relationship('Abstraction', back_populates='eqs')
    terminals: list[Terminal] = relationship('Terminal', post_update=True)

    __mapper_args__ = {
        'polymorphic_identity': AssetType.Equipment,
        'polymorphic_on': concreteType
    }


@declarative_mixin
class EquipmentMixin():

    _linkedAssetsCls: Dict[str, Type[Asset]] = {}

    @declared_attr
    def geo(self):
        n = not self._geoRequired if hasattr(self, '_geoRequired') else True
        return Column('geo', GeoType, nullable=n)

    @declared_attr
    def assetFK(self):
        return Column('assetFK', ForeignKey(self._AssetCls.uuid), index=True, nullable=False)

    @declared_attr
    def asset(cls):
        assetCls = cls._AssetCls
        return relationship(assetCls, order_by=lambda: cls.installDate)

    assetFK: uuid.UUID
    asset: Asset[Self]

    def withAsset(self, asset: object = None) -> object:
        if asset is None:
            self.asset = self._AssetCls()
        else:
            self.asset = asset
        return self

    @classmethod
    @property
    @functools.cache
    def _AssetCls(cls: Type[EQ]) -> Type[Asset[EQ]]:
        return Asset._generateSpecialisationClass(cls)


@declarative_mixin
class EquipmentWithTerminal(EquipmentMixin):
    _linkedTerminalsCls: Dict[str, Type[Terminal]] = {}
    name = Column(String)

    @classmethod
    @property
    @functools.cache
    def _TerminalCls(cls: Type[EQT]) -> Type[Terminal[EQT]]:
        return Terminal._generateSpecialisationClass(cls)

    def __repr__(self) -> str:
        return f"{self.__tablename__}({self.name})"


@declarative_mixin
class EquipmentWithOneTerminal(EquipmentWithTerminal):
    @declared_attr
    def terminalFK(cls):
        return Column('terminalFK', UUIDType, ForeignKey(cls._TerminalCls.uuid), unique=True, nullable=False)

    @declared_attr
    def terminal(cls) -> Terminal[EQT]:
        return relationship(cls._TerminalCls, back_populates="eq", lazy='joined')

    terminalFK: uuid.UUID
    terminal: Terminal[Self]

    @staticmethod
    def _withTerminal(target: EquipmentWithTerminal, args, kwargs):
        t = target._TerminalCls()
        kwargs['terminal'] = t
        kwargs['terminals'] = [t]

    def terminalName(self, terminal):
        if self.terminal is not None and terminal == self.terminal:
            return 't'
        else:
            raise Exception(f"{self} does not have provided terminal ('{terminal.uuid}')")


@declarative_mixin
class EquipmentWithTwoTerminals(EquipmentWithTerminal):

    @declared_attr
    def terminal1FK(cls):
        return Column('terminal1FK', UUIDType, ForeignKey('Terminal.uuid'), unique=True, nullable=False)

    @declared_attr
    def terminal2FK(cls):
        return Column('terminal2FK', UUIDType, ForeignKey('Terminal.uuid'), unique=True, nullable=False)

    @declared_attr
    def terminal1(cls) -> Terminal[EQT]:
        return relationship(cls._TerminalCls, foreign_keys=[cls.terminal1FK], lazy='joined')

    @declared_attr
    def terminal2(cls) -> Terminal[EQT]:
        return relationship(cls._TerminalCls, foreign_keys=[cls.terminal2FK], lazy='joined')

    terminal1FK: uuid.UUID
    terminal2FK: uuid.UUID
    terminal1: Terminal[Self]
    terminal2: Terminal[Self]

    @staticmethod
    def _withTerminals(target: EquipmentWithTerminal, args, kwargs):
        t1 = target._TerminalCls()
        t2 = target._TerminalCls()
        t1.otherSide = t2
        t2.otherSide = t1
        kwargs['terminal1'] = t1
        kwargs['terminal2'] = t2
        kwargs['terminals'] = [t1, t2]

    @classmethod
    def __declare_last__(cls):
        # Used to set Terminal.eq before the commit
        # Can't use `back_populate='eq'` because otherside needs `viewonly=True` to prevent overwrite
        # of terminal1 and terminal2 by the same terminal.
        def _back_populate_terminal(target, value, oldvalue, initializer):
            value.eq = target
            return value

        event.listen(cls.terminal1, 'set', _back_populate_terminal, retval=True)
        event.listen(cls.terminal2, 'set', _back_populate_terminal, retval=True)

    def terminalName(self, terminal):
        if self.terminal1 is not None and terminal == self.terminal1:
            return 't1'
        elif self.terminal2 is not None and terminal == self.terminal2:
            return 't2'
        else:
            raise Exception(f"{self} does not have provided terminal ('{terminal.uuid}')")


@declarative_mixin
class EquipmentWithParameterEvent(object):
    _linkedParameterEventsCls: Dict[str, Type[ParameterEvent]] = {}

    @declared_attr
    def parameterEvents(cls):
        return relationship(cls._ParameterEventCls, back_populates='eq')

    parameterEvents: list[ParameterEvent[Self]]

    def withParameter(self: Union[Self, EquipmentWithTerminal], b: float = 0, b0: float = 0, g: float = 0,
                      g0: float = 0, r: float = 0, r0: float = 0, x: float = 0, x0: float = 0):
        if len(self.parameterEvents) == 0:
            self.generateParameterEvent(timestamp=self.installDate, b=b, b0=b0, g=g, g0=g0, r=r, r0=r0, x=x, x0=x0,
                                        valueSource=ParameterEvent.Source.nominal)
        else:
            raise Exception(
                "Method withParameter should only be used to set the initial parameterEvent of the equipment.")
        return self

    def generateParameterEvent(self, **kwargs) -> ParameterEvent[Self]:
        parameterEvent = self._ParameterEventCls(**kwargs)
        self.parameterEvents.append(parameterEvent)
        return parameterEvent

    @classmethod
    @property
    @functools.cache
    def _ParameterEventCls(cls: Type[PEQ]) -> Type[ParameterEvent[PEQ]]:
        return ParameterEvent._generateSpecialisationClass(cls)


# # # # # # # # # # # # # #
# EQUIPMENT WITH TERMINALS
#
# Concrete equipment with terminals


class Bess(Equipment, EquipmentWithOneTerminal):
    __tablename__ = 'Bess'
    uuid = Column(UUIDType, ForeignKey('Equipment.uuid'), primary_key=True)
    chargingEff = Column(Float)
    dischargingEff = Column(Float)
    maxCharginP = Column(Float)
    maxDischargingP = Column(Float)
    minChargingP = Column(Float)
    minDischargingP = Column(Float)
    ratedE = Column(Float)
    ratedS = Column(Float)

    geo: Point

    __mapper_args__ = {
        'polymorphic_identity': AssetType.Bess,
    }


class Branch(Equipment, EquipmentWithTwoTerminals, EquipmentWithParameterEvent):
    __tablename__ = 'Branch'
    uuid = Column(UUIDType, ForeignKey('Equipment.uuid'), primary_key=True)
    currentLimit = Column(Float)
    length = Column(Float)

    geo: LineString

    __mapper_args__ = {
        'polymorphic_identity': AssetType.Branch,
    }


class BusbarSection(Equipment, EquipmentWithOneTerminal):
    _geoRequired = True
    __tablename__ = 'BusbarSection'
    uuid = Column(UUIDType, ForeignKey('Equipment.uuid'), primary_key=True)
    voltageLevel = Column(Float)
    voltageMin = Column(Float)
    voltageMax = Column(Float)

    geo: Point

    __mapper_args__ = {
        'polymorphic_identity': AssetType.BusbarSection,
    }


class EnergyConsumer(Equipment, EquipmentWithOneTerminal):
    class ProfileType(enum.Enum):
        residential = 1
        commercial = 2
        industrial = 3

    __tablename__ = 'EnergyConsumer'
    uuid = Column(UUIDType, ForeignKey('Equipment.uuid'), primary_key=True)
    ratedS = Column(Float)
    profileType: ProfileType = Column(Enum(ProfileType))

    geo: Point

    __mapper_args__ = {
        'polymorphic_identity': AssetType.EnergyConsumer,
    }


class ExternalNetwork(Equipment, EquipmentWithOneTerminal):
    __tablename__ = 'ExternalNetwork'
    uuid = Column(UUIDType, ForeignKey('Equipment.uuid'), primary_key=True)
    rEq = Column(Float)
    xEq = Column(Float)

    geo: Point

    __mapper_args__ = {
        'polymorphic_identity': AssetType.ExternalNetwork,
    }


class Pv(Equipment, EquipmentWithOneTerminal):
    __tablename__ = 'Pv'
    uuid = Column(UUIDType, ForeignKey('Equipment.uuid'), primary_key=True)
    cosPhiLimit = Column(Float)
    ratedS = Column(Float)

    geo: Point

    __mapper_args__ = {
        'polymorphic_identity': AssetType.Pv,
    }


class SynchronousGenerationUnit(Equipment, EquipmentWithOneTerminal):
    __tablename__ = 'SynchronousGenerationUnit'
    uuid = Column(UUIDType, ForeignKey('Equipment.uuid'), primary_key=True)
    maxOperatingP = Column(Float)
    minOperatingP = Column(Float)
    ratedS = Column(Float)

    geo: Point

    __mapper_args__ = {
        'polymorphic_identity': AssetType.SynchronousGenerationUnit,
    }


class Switch(Equipment, EquipmentWithTwoTerminals):
    class Controllable(enum.Enum):
        manualOffLoad = 1
        manualOnLoad = 2
        autoOffLoad = 3
        autoOnLoad = 4
        no = 5

    __tablename__ = 'Switch'
    uuid = Column(UUIDType, ForeignKey('Equipment.uuid'), primary_key=True)
    normalOpen = Column(Boolean, nullable=False, default=False)
    controllable: Controllable = Column(Enum(Controllable))

    switchEvents: list[SwitchEvent] = relationship('SwitchEvent', back_populates='switch')

    geo: Point

    __mapper_args__ = {
        'polymorphic_identity': AssetType.Switch,
    }


class Transformer(Equipment, EquipmentWithTwoTerminals, EquipmentWithParameterEvent):
    class Group(enum.Enum):
        Dy1 = 0
        Dy5 = 1
        Dy11 = 2
        Yy0 = 3
        Yz1 = 4
        Yz5 = 5
        Yz11 = 6

    __tablename__ = 'Transformer'
    uuid = Column(UUIDType, ForeignKey('Equipment.uuid'), primary_key=True)
    vectorGroup: vectorGroup = Column(Enum(Group, name="VectorGroup"))
    ratedS = Column(Float, default=0.0)

    taps: list[Tap] = relationship('Tap', back_populates='transformer')

    geo: Point

    __mapper_args__ = {
        'polymorphic_identity': AssetType.Transformer,
    }

    def setTapRange(self, lv_values: list[float] = [], hv_values: list[float] = []):
        lv_taps = [Tap(value=v, isTapHv=False) for v in lv_values]
        hv_taps = [Tap(value=v, isTapHv=True) for v in hv_values]
        self.taps = lv_taps + hv_taps
        return lv_taps, hv_taps



equipmentClsWithOneTerminal = [Bess, BusbarSection, EnergyConsumer, ExternalNetwork, Pv, SynchronousGenerationUnit]
equipmentClsWithTwoTerminals = [Branch, Switch, Transformer]

# Add automated Terminal instanciation when an EquipmentWithTerminal is instanciated.
for eqCls in equipmentClsWithOneTerminal:
    event.listen(eqCls, 'init', EquipmentWithOneTerminal._withTerminal, propagate=True)
for eqCls in equipmentClsWithTwoTerminals:
    event.listen(eqCls, 'init', EquipmentWithTwoTerminals._withTerminals, propagate=True)


# # # # # # # # # # # # # #
# MEASURMENTS
#
# Measurement assets and events

class MeasurementSource(Base, HasUuid):
    __tablename__ = 'MeasurementSource'
    name = Column(String)

    measurementDevices: list['MeasurementDevice'] = relationship('MeasurementDevice',
                                                                     back_populates='valueSource')


class MeasurementDevice(Equipment, EquipmentMixin):
    __tablename__ = 'MeasurementDevice'
    uuid = Column(UUIDType, ForeignKey('Equipment.uuid'), primary_key=True)
    accuracyActivePower = Column(Float, default=0.0)
    accuracyCurrent = Column(Float, default=0.0)
    accuracyReactivePower = Column(Float, default=0.0)
    accuracyVoltage = Column(Float, default=0.0)
    aggregationPeriod = Column(Float)
    valueSourceFK: uuid.UUID = Column(UUIDType, ForeignKey(MeasurementSource.uuid), nullable=False)

    valueSource: MeasurementSource = relationship('MeasurementSource',
                                                                     back_populates='measurementDevices')
    measurementTerminals: list['MeasurementTerminal'] = relationship('MeasurementTerminal',
                                                                     back_populates='measurementDevice')

    geo: Point

    __mapper_args__ = {
        'polymorphic_identity': AssetType.MeasurementDevice,
    }

    def measures(self, terminal: Terminal[EQT]):
        mt = MeasurementTerminal()
        mt.measurementDevice = self
        mt.terminal = terminal
        return mt


class MeasurementTerminal(Base, HasUuid):
    __tablename__ = 'MeasurementTerminal'
    measurementDeviceFK: uuid.UUID = Column(UUIDType, ForeignKey(MeasurementDevice.uuid))
    terminalFK: uuid.UUID = Column(UUIDType, ForeignKey(Terminal.uuid), nullable=False)

    measurementDevice: MeasurementDevice = relationship(MeasurementDevice, back_populates='measurementTerminals')
    terminal: Terminal = relationship(Terminal, back_populates='measurementTerminals')
    measurementEvents: list[MeasurementEvent] = relationship('MeasurementEvent', back_populates='measurementTerminal')
    measurementValues: list[MeasurementValue] = relationship('MeasurementValue', back_populates='measurementTerminal')


class MeasurementEvent(Base, Record):
    class Type(enum.Enum):
        noVoltage = 1
        underVoltage = 2
        overVoltage = 3
        overCurrent = 4

    __tablename__ = 'MeasurementEvent'
    endDate: datetime.datetime = Column(DateTime)
    value = Column(Float)
    type: Type = Column(Enum(Type, name="EventType"))
    measurementTerminalFK: uuid.UUID = Column(UUIDType, ForeignKey(MeasurementTerminal.uuid), nullable=False)

    measurementTerminal: MeasurementTerminal = relationship(MeasurementTerminal, back_populates='measurementEvents')


class MeasurementValue(Base, Record):
    __tablename__ = 'MeasurementValue'
    avgActivePowerA = Column(Float)
    avgActivePowerB = Column(Float)
    avgActivePowerC = Column(Float)

    stdActivePowerA = Column(Float)
    stdActivePowerB = Column(Float)
    stdActivePowerC = Column(Float)

    medActivePowerA = Column(Float)
    medActivePowerB = Column(Float)
    medActivePowerC = Column(Float)

    lqActivePowerA = Column(Float)
    lqActivePowerB = Column(Float)
    lqActivePowerC = Column(Float)

    uqActivePowerA = Column(Float)
    uqActivePowerB = Column(Float)
    uqActivePowerC = Column(Float)

    minActivePowerA = Column(Float)
    minActivePowerB = Column(Float)
    minActivePowerC = Column(Float)

    maxActivePowerA = Column(Float)
    maxActivePowerB = Column(Float)
    maxActivePowerC = Column(Float)

    avgCurrentA = Column(Float)
    avgCurrentB = Column(Float)
    avgCurrentC = Column(Float)

    stdCurrentA = Column(Float)
    stdCurrentB = Column(Float)
    stdCurrentC = Column(Float)

    medCurrentA = Column(Float)
    medCurrentB = Column(Float)
    medCurrentC = Column(Float)

    lqCurrentA = Column(Float)
    lqCurrentB = Column(Float)
    lqCurrentC = Column(Float)

    uqCurrentA = Column(Float)
    uqCurrentB = Column(Float)
    uqCurrentC = Column(Float)

    minCurrentA = Column(Float)
    minCurrentB = Column(Float)
    minCurrentC = Column(Float)

    maxCurrentA = Column(Float)
    maxCurrentB = Column(Float)
    maxCurrentC = Column(Float)

    avgReactivePowerA = Column(Float)
    avgReactivePowerB = Column(Float)
    avgReactivePowerC = Column(Float)

    stdReactivePowerA = Column(Float)
    stdReactivePowerB = Column(Float)
    stdReactivePowerC = Column(Float)

    medReactivePowerA = Column(Float)
    medReactivePowerB = Column(Float)
    medReactivePowerC = Column(Float)

    lqReactivePowerA = Column(Float)
    lqReactivePowerB = Column(Float)
    lqReactivePowerC = Column(Float)

    uqReactivePowerA = Column(Float)
    uqReactivePowerB = Column(Float)
    uqReactivePowerC = Column(Float)

    minReactivePowerA = Column(Float)
    minReactivePowerB = Column(Float)
    minReactivePowerC = Column(Float)

    maxReactivePowerA = Column(Float)
    maxReactivePowerB = Column(Float)
    maxReactivePowerC = Column(Float)

    avgVoltageA = Column(Float)
    avgVoltageB = Column(Float)
    avgVoltageC = Column(Float)

    stdVoltageA = Column(Float)
    stdVoltageB = Column(Float)
    stdVoltageC = Column(Float)

    medVoltageA = Column(Float)
    medVoltageB = Column(Float)
    medVoltageC = Column(Float)

    lqVoltageA = Column(Float)
    lqVoltageB = Column(Float)
    lqVoltageC = Column(Float)

    uqVoltageA = Column(Float)
    uqVoltageB = Column(Float)
    uqVoltageC = Column(Float)

    minVoltageA = Column(Float)
    minVoltageB = Column(Float)
    minVoltageC = Column(Float)

    maxVoltageA = Column(Float)
    maxVoltageB = Column(Float)
    maxVoltageC = Column(Float)

    measurementTerminalFK: uuid.UUID = Column(UUIDType, ForeignKey(MeasurementTerminal.uuid), nullable=False)

    measurementTerminal: MeasurementTerminal = relationship(MeasurementTerminal, back_populates='measurementValues')
