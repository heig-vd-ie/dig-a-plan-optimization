import polars as pl

def oneof(field: pl.Expr, values: list[str]) -> pl.Expr:
    return field.is_in(values).alias('one_of_constraint')

def unique_null_distinct(field: pl.Expr) -> pl.Expr:
    return field.drop_nulls().is_duplicated().sum().eq(0).alias('unique_null_distinct_constraint')