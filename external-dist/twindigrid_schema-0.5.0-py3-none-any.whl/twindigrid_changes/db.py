from datetime import datetime
from functools import cached_property
import os
from pathlib import Path
from typing import Optional, Self
from psycopg import sql
import duckdb

from twindigrid_changes.models import *
from twindigrid_changes.sql import as_string


def get_connection_string_from_env() -> str:
    host = os.environ.get('DB_HOSTNAME', 'localhost')
    port = os.environ.get('DB_PORT', '5432')
    dbname = os.environ.get('DB_NAME', 'TwinDiGrid_v0_5')
    user = os.environ.get('DB_USER', 'postgres')
    password = os.environ.get('DB_PASSWORD', 'password')

    return f"{host=} {port=} {dbname=} {user=} {password=}"


def attach(con: duckdb.DuckDBPyConnection, connection_string: str):
    q = as_string(
        sql.SQL("""ATTACH {con_str} AS remote (TYPE postgres);""").format(con_str=connection_string)
    )
    con.execute(q)


# def remote_string(composable: sql.Composable) -> sql.Composable:
#     if isinstance(composable, sql.Composed):
#         return sql.SQL(' || ').join([remote_string(x) for x in composable])
#     elif isinstance(composable, sql.SQL):
#         return sql.Literal(composable.as_string(None))
#     elif isinstance(composable, sql.Identifier):
#         return sql.Literal(composable._obj[0])
#     elif isinstance(composable, sql.Placeholder):
#         return sql.SQL('COALESCE(?::STRING, \'null\')')
#     else:
#         return composable

def remote_string(composable: sql.Composable) -> sql.Composable:
    if isinstance(composable, sql.Composed):
        return ''.join([remote_string(x) for x in composable])
    elif isinstance(composable, sql.Identifier):
        return '.'.join(['"' + i.replace('"', '""') + '"' for i in composable._obj])
    else:
        return composable.as_string(None)


def remote_execute(con: duckdb.DuckDBPyConnection, q: sql.Composable, params: list[any] = []):
    q = as_string(
        sql.SQL("""CALL postgres_execute({remote}, {q});""").format(
            remote=sql.Literal('remote'),
            q=remote_string(q),
        )
    )
    con.execute(q, params)


def load_remote_tables(con: duckdb.DuckDBPyConnection, remote_schema: str, t_start: Optional[datetime] = None, t_end: Optional[datetime] = None):
    q = sql.SQL("""CALL {schema}.load({s}, {e})""").format(
        schema=sql.Identifier(remote_schema),
        # s=sql.Placeholder(),
        # e=sql.Placeholder(),
        s=sql.Literal(t_start),
        e=sql.Literal(t_end),
    )
    remote_execute(con, q, 
                #    [t_start, t_end]
                   )


def persist_remote_tables(con: duckdb.DuckDBPyConnection, remote_schema: str):
    q = sql.SQL("""CALL {schema}.persist()""").format(
        schema=sql.Identifier(remote_schema),
    )
    remote_execute(con, q)


def clear_remote_tables(con: duckdb.DuckDBPyConnection, remote_schema: str):
    q = sql.SQL("""CALL {schema}.clear()""").format(
        schema=sql.Identifier(remote_schema),
    )
    remote_execute(con, q)


def download_tables(con: duckdb.DuckDBPyConnection):
    for table in all_models.keys():
        download_table(con, 'changes', table)


def upload_tables(con: duckdb.DuckDBPyConnection):
    remote_schema = "changes"
    for table in all_models.keys():
        upload_table(con, remote_schema, table)


def download_table(con: duckdb.DuckDBPyConnection, remote_schema: str, table: str):
    q = as_string(
        sql.SQL("""CREATE TABLE {table} AS FROM remote.{schema}.{table};""").format(schema=sql.Identifier(remote_schema), table=sql.Identifier(table))
    )
    con.execute(q)


def upload_table(con: duckdb.DuckDBPyConnection, remote_schema: str, table: str):
    q = as_string(
        sql.SQL("""INSERT INTO remote.{schema}.{table} SELECT * FROM {table};""").format(schema=sql.Identifier(remote_schema), table=sql.Identifier(table))
    )
    con.execute(q)


def create_db(*, persist: Optional[Path] = None) -> duckdb.DuckDBPyConnection:
    database = ":memory:" if persist is None else str(persist)

    con = duckdb.connect(database=database)

    # Required because patito need datetime to be at specific timezone
    con.execute("SET TimeZone='UTC'")

    for ext in ['json', 'postgres']:
        con.install_extension(ext)
        con.load_extension(ext)

    return con


class ChangesDb():
    con: duckdb.DuckDBPyConnection
    persist_path: Path | None

    def __init__(self, persist: Path | None = None) -> None:
        self.persist_path = persist

    @cached_property
    def con(self) -> duckdb.DuckDBPyConnection:
        dcon = create_db(persist=self.persist_path)
        return dcon

    def persist(self):
        con = self.con
        # TODO: put into a transaction
        # tr = con.begin()
        tr = con
        clear_remote_tables(tr, 'changes')
        upload_tables(tr)
        persist_remote_tables(tr, 'changes')
        clear_remote_tables(tr, 'changes')
        # tr.commit()

    def attach(self, from_connection_string: Optional[str] = None) -> Self:
        if from_connection_string is None:
            from_connection_string = get_connection_string_from_env()
        con = self.con
        attach(con, from_connection_string)

        return self

    @classmethod
    def load(cls, start: Optional[datetime] = None, end: Optional[datetime] = None, from_connection_string: Optional[str] = None) -> Self:
        db = ChangesDb()
        con = db.con
        db.attach(from_connection_string)

        # TODO: put into a transaction
        # tr = con.begin()
        tr = con
        clear_remote_tables(tr, 'changes')
        load_remote_tables(tr, 'changes', start, end)
        download_tables(tr)
        clear_remote_tables(tr, 'changes')
        # tr.commit()

        return db
