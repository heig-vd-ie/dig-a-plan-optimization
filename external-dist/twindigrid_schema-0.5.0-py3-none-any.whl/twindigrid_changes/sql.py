import datetime
import psycopg
from psycopg import sql

def as_string(composable: sql.Composable) -> str:
    if isinstance(composable, sql.Composed):
        return ''.join([as_string(x) for x in composable])
    elif isinstance(composable, sql.Identifier):
        return '.'.join(['"' + i.replace('"', '""') + '"' for i in composable._obj])
    else:
        return composable.as_string(None)


if __name__ == "__main__":
    query = sql.SQL("INSERT INTO {} VALUES ({})").format(
        sql.Identifier('myTab"le'),
        sql.SQL(', ').join([
            "any 'text' in 日本語 and even €",
            1.2e-1,
            datetime.date.today(),
            sql.Placeholder(),
            sql.Placeholder("hello"),
        ])
    )

    print(as_string(query))
    print(as_string(sql.Literal("1")))
    print(as_string(sql.Literal(1e-2)))
    print(as_string(sql.Literal(datetime.datetime.now())))
    print(as_string(sql.Literal("ภาษาใดก็ได้")))
    print(as_string(sql.Literal("Greek encoding: οποιαδήποτε γλώσσα")))
