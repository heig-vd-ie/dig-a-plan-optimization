from dataclasses import dataclass
from functools import cached_property
from typing import Dict, Literal, Optional
from sqlalchemy import ClauseElement, ExecutableDDLElement, SelectBase, TableClause, schema, table
from sqlalchemy.sql import sqltypes
from sqlalchemy.sql.compiler import DDLCompiler
from sqlalchemy.ext.compiler import compiles
from sqlalchemy.sql.ddl import _CreateDropBase

from twindigrid_sql.ddl.utils import clean_str

@dataclass(kw_only=True)
class View():
    name: str
    schema: str
    query: SelectBase
    temporary: Optional[bool] = None
    recursive: Optional[bool] = None
    columns: Optional[list[str]] = None
    options: Optional[Dict[str, str]] = None
    check_option: Optional[Literal['CASCADED', 'LOCAL']] = None
    comment: Optional[str] = None

    @cached_property
    def table(self) -> TableClause:
        t = table(self.name, schema=self.schema)

        columns = self.query.selected_columns

        t._columns._populate_separate_keys(
            col._make_proxy(t) for col in columns
        )

        return t

class CreateView(_CreateDropBase):
    """Represent a CREATE VIEW statement with possibly the associated comment.
    """
    element: View
    or_replace: bool

    __visit_name__ = "create_view_with_comment"

    def __init__(self, element: View, or_replace=False) -> None:
        super().__init__(element)
        self.or_replace = or_replace

@compiles(CreateView)
def visit_create_view_with_comment(create: CreateView, compiler: DDLCompiler, **kw):
    e = create.element

    definition = "%s.%s" % (
        compiler.preparer.format_schema(e.schema),
        compiler.preparer.quote(e.name),
    )

    columns = "( %s )" % (
        ",".join(e.columns),
    ) if e.columns else ""

    options = " WITH (  )" if e.options else ""

    check_option = " WITH %s CHECK OPTION" % (
        e.check_option,
    ) if e.check_option else ""
    
    return "CREATE%s%s%s VIEW %s%s%s AS %s%s;\n" % (
        " OR REPLACE" if create.or_replace else "",
        " TEMPORARY" if e.temporary else "",
        " RECURSIVE" if e.recursive else "",
        definition,
        columns,
        options,
        compiler.sql_compiler.process(e.query, literal_binds=True),
        check_option,
    ) + ("COMMENT ON VIEW %s IS %s;\n" % (
        definition,
        compiler.sql_compiler.render_literal_value(
            clean_str(e.comment), sqltypes.String()
        ),
    ) if e.comment else "")