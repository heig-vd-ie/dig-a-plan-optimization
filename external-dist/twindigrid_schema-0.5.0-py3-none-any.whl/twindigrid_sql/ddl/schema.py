from sqlalchemy import ExecutableDDLElement, schema
from sqlalchemy.sql import sqltypes
from sqlalchemy.sql.compiler import DDLCompiler
from sqlalchemy.ext.compiler import compiles

from twindigrid_sql.ddl.utils import clean_str

class CreateSchema(ExecutableDDLElement):
    """Represent a CREATE SCHEMA statement with possibly the associated comment.
    """

    __visit_name__ = "create_schema_with_comment"

    def __init__(
        self,
        name,
        if_not_exists=False,
        comment=None,
    ):
        self.name = name
        self.if_not_exists = if_not_exists
        self.comment = comment

@compiles(CreateSchema)
def visit_create_schema_with_comment(create: CreateSchema, compiler: DDLCompiler, **kw):
    schema_name = compiler.preparer.format_schema(create.name)
    text = "CREATE SCHEMA %s %s;\n" % (
        "IF NOT EXISTS" if create.if_not_exists else "",
        schema_name,
    )
    if create.comment:
        text += "COMMENT ON SCHEMA %s IS %s" % (
            schema_name,
            compiler.sql_compiler.render_literal_value(
                clean_str(create.comment), sqltypes.String()
            ),
        )

    return text