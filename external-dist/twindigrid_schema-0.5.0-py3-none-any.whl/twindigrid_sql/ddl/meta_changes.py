from __future__ import annotations
from collections import OrderedDict
from dataclasses import dataclass
import sys
from types import ModuleType
from typing import Any, Callable, NamedTuple, Optional, Self, TypedDict, Unpack

from sqlalchemy import CheckConstraint, Column, ColumnClause, ExecutableDDLElement, ForeignKey, ForeignKeyConstraint, MetaData, Select, Table, delete, insert, literal_column, select, event, update
from sqlalchemy.sql.schema import SchemaItem, SchemaEventTarget
from sqlalchemy.dialects.postgresql import ExcludeConstraint
from sqlalchemy.sql.expression import and_

from twindigrid_sql.custom_types import TIMESTAMPTZ
from twindigrid_sql.ddl.callable import CreateCallable, Procedure, CallableArg, ReturnTable, SqlBody, SqlTextBody, TableFunction, TextBody
from twindigrid_sql.ddl.meta import GeneratedTableDDL, SchemaElementMeta, TableMeta, TableParams
from twindigrid_sql.ddl.utils import NamedTupleMeta, clean_str


@dataclass
class MainMapper:
    read: ColumnClause
    write: ColumnClause

    @classmethod
    def create_from_column(cls, main_column: Column, changes_column: Column) -> Self:
        return MainMapper(main_column, changes_column)
    
    @classmethod
    def of_column(cls, column: Column) -> Optional[Self]:
        return column.info.get('main_mapper')
    
    @staticmethod
    def of_table(table: Table) -> list[MainMapper]:
        return [
            m 
            for c in table.columns
            if (m := MainMapper.of_column(c))
        ]


def filter_col(c: Column) -> bool:
    return c.computed is None

def with_table(t: ChangesTableMeta, migrate_fk: bool = False) -> TableParams:
    g = t.main_ddl
    def copy_arg(i: SchemaItem) -> SchemaItem:
        match i:
            case Column():       
                if not filter_col(i):
                    return None
                k = g.table.columns[i.key]
                j = i.copy()
                if migrate_fk:
                    for fk in i.foreign_keys:
                        fk: ForeignKey
                        j.foreign_keys.add(fk.copy(schema=t.schema))
                m = MainMapper.create_from_column(k, j)
                j.info = dict(main_mapper=m)
                return j
            case ForeignKeyConstraint():
                if migrate_fk:
                    j = i.copy(schema=t.schema)
                    return j
                else:
                    return None
    return TableParams.of(
        *[n for a in g.params.args if (n := copy_arg(a)) is not None],
        **{k: v.copy() for k, v in g.params.kwargs.items()},
    )


@dataclass(frozen=True)
class ChangesTableMeta[F, C, I, MF, MC, MI](TableMeta[F, C, I]):
    main_ddl: GeneratedTableDDL[MF, MC, MI]

    @classmethod
    def inherits(cls, parent: TableMeta):
        def inner[F2, C2, I2, MF2, MC2, MI2](
            main_ddl: GeneratedTableDDL[MF2, MC2, MI2],
            fields_nt: Optional[type[F2]] = None,
            constraints_nt: Optional[type[C2]] = None,
            indices_nt: Optional[type[I2]] = None,
        ) -> ChangesTableMeta[F2, C2, I2, MF2, MC2, MI2]:
            return ChangesTableMeta(parent.name, parent.schema, parent.comment, parent.type, parent.metadata_object,
                                    NamedTupleMeta.from_namedtuple(fields_nt), 
                                    NamedTupleMeta.from_namedtuple(constraints_nt), 
                                    NamedTupleMeta.from_namedtuple(indices_nt),
                                    main_ddl)
        return inner

    def PersistProcedure(self, changes_table: Table) -> Procedure:
        column_mapping=OrderedDict(
            (m.write, changes_table.columns[c.key])
            for c in changes_table.columns.values()
            if (m := MainMapper.of_column(c))
        )
        # column_mapping=OrderedDict((c, changes_table.columns.get(c.name)) for c in self.main_ddl.table.columns if filter_col(c))
        new_elements = insert(self.main_ddl.table).from_select(
            column_mapping.keys(), 
            select(*column_mapping.values())
            .where(changes_table.c.diff == '+')
        )
        pk_where = list(
            main_pk == change_pk 
            for main_pk, change_pk in zip(self.main_ddl.table.primary_key, changes_table.primary_key) 
            if main_pk.primary_key
        )
        updated_elements = (update(self.main_ddl.table)
            .where(and_(changes_table.c.diff == '!', *pk_where))
            .values(**{m.name: c for m, c in column_mapping.items()})
        )
        removed_elements = (delete(self.main_ddl.table)
            .where(and_(changes_table.c.diff == '-', *pk_where))
        )
        return Procedure(
            name=f"persist_{self.name}", 
            schema=self.schema,
            # args=[CallableArg(TIMESTAMPTZ, name='t')], 
            body=SqlBody([
                new_elements,
                updated_elements,
                removed_elements,
            ]), 
        )

    def LoadProcedure(self, changes_table: Table, table_function: TableFunction) -> Procedure:
        arg_start = CallableArg(TIMESTAMPTZ, name='t_start')
        arg_end = CallableArg(TIMESTAMPTZ, name='t_end')
        new_elements = insert(changes_table).from_select(
            table_function.columns,
            select(table_function.func(arg_start.col, arg_end.col))
        )
        return Procedure(
            name=f"load_{self.name}", 
            schema=self.schema,
            args=[
                arg_start,
                arg_end,
            ], 
            body=SqlBody([
                new_elements,
            ]),
        )

    def generate_ddl(self, params: TableParams, query: QueryCallable) -> GeneratedChangesTableDDL:
        table = self.Table(params, depends_on=[self.main_ddl.table])

        # Persist from changes schema to main schema
        persist = self.PersistProcedure(table)
        event.listen(table, 'after_create', CreateCallable(persist, True))

        # Read subset from main schema
        read = TableFunction(
            name=f"{self.name}",
            schema=self.schema,
            args=[
                arg_start := CallableArg(TIMESTAMPTZ, name='t_start'),
                arg_end := CallableArg(TIMESTAMPTZ, name='t_end'),
            ],
            body=SqlBody([
                query(self, table, arg_start, arg_end),
            ] if query else [select(table)]),
            rettype=table,
            volatility='STABLE',
        )

        # Load from main schema to changes schema
        load = self.LoadProcedure(table, read)
        event.listen(table, 'after_create', CreateCallable(read, True))
        event.listen(table, 'after_create', CreateCallable(load, True))
        return GeneratedChangesTableDDL(
            meta=self,
            params=params,
            table=table,
            persist=persist,
            load=load,
            read=read,
        )
    
# Allow creation of a query to read from main between both CallableArg time
QueryCallable = Callable[[ChangesTableMeta, Table, CallableArg, CallableArg], Select]


@dataclass(frozen=True)
class GeneratedChangesTableDDL[F, C, I, MF, MC, MI](GeneratedTableDDL):
    meta: ChangesTableMeta[F, C, I, MF, MC, MI]
    persist: Procedure
    load: Procedure
    read: TableFunction