from functools import reduce
from sqlalchemy import CheckConstraint, Column, ColumnElement, Integer
from sqlalchemy.sql import expression as expr


def CheckNotNullIf(column: str, bool_expression: ColumnElement[bool]) -> ColumnElement[bool]:
    return expr.or_(
            Column(column) != expr.null(), 
            expr.not_(bool_expression)
        )

def CheckNotNullOnlyIf(column: str, bool_expression: ColumnElement[bool]) -> ColumnElement[bool]:
    return expr.or_(
            (Column(column) != expr.null()) == bool_expression,
        )

def CheckNotNullIfEquals[T](not_null_column: str, equal_column: str, *values: T) -> ColumnElement[bool]:
    return CheckNotNullIf(not_null_column, Column(equal_column).in_(values))

def CheckNotNullOnlyIfEquals[T](not_null_column: str, equal_column: str, *values: T) -> ColumnElement[bool]:
    return CheckNotNullOnlyIf(not_null_column, Column(equal_column).in_(values))

def CheckOnlyOneNotNull(*columns: str) -> ColumnElement[bool]:
    return reduce(lambda a, b: a + b, [
        (Column(c) != expr.null()).cast(Integer)
        for c in columns
    ]) == 1