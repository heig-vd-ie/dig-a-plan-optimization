from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import sys
import textwrap
from types import ModuleType
from typing import Any, Callable, Literal, NamedTuple, Optional, Self, TypeVar, TypedDict, Unpack, get_type_hints
from sqlalchemy import Column, ExecutableDDLElement, ForeignKey, ForeignKeyConstraint, MetaData, Table, CheckConstraint, event
from sqlalchemy.dialects.postgresql import ExcludeConstraint
from sqlalchemy.sql.schema import SchemaItem, SchemaEventTarget

F = TypeVar('F', bound=NamedTuple)
C = TypeVar('C', bound=NamedTuple)
I = TypeVar('I', bound=NamedTuple)

def nametuple_self_fill[T](nt: type[T]) -> Optional[T]:
    if nt is None:
        return None
    attrs = get_type_hints(nt)
    vals = {k: k for k, doc in attrs.items()}
    return nt(**vals)

def nametuple_comments(nt: NamedTuple) -> dict[str, str]:
    return nt._field_defaults if nt is not None else {}

def nametuple_doc(nt: NamedTuple, field: str) -> str:
    return nt._field_defaults[field]

@dataclass(frozen=True)
class NamedTupleMeta[T]:
    comments: dict[str, str]
    type: type[T]
    # The value of each attribute of the tuple is the name of the attribute
    named: T

    @classmethod
    def from_namedtuple(cls, nt: Optional[type[T]]) -> Self:
        if nt is None:
            return None
        return NamedTupleMeta(
            comments=map_dict(nametuple_comments(nt), clean_str),
            type=nt,
            named=nametuple_self_fill(nt),
        )

def map_dict[K, V, W](d: dict[K, V], f: Callable[[K], W]) -> dict[K, W]:
    return {k: f(v) for k, v in d.items()}

def clean_str(s: str) -> str:
    return textwrap.dedent(s).strip()
