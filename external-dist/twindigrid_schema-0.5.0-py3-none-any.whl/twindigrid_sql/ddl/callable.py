from dataclasses import dataclass, field
from typing import Literal, Optional, Union
from sqlalchemy import DDL, ClauseElement, ColumnClause, ColumnElement, Executable, ExecutableDDLElement, Table, TableValuedAlias, func
from sqlalchemy.sql import sqltypes
from sqlalchemy.sql.base import DialectKWArgs
from sqlalchemy.sql.schema import HasSchemaAttr
from sqlalchemy.sql.ddl import _CreateDropBase
from sqlalchemy.sql.type_api import TypeEngine
from sqlalchemy.sql.compiler import DDLCompiler
from sqlalchemy.sql.functions import GenericFunction
from sqlalchemy.dialects.postgresql import NUMRANGE
from sqlalchemy.ext.compiler import compiles

from twindigrid_sql.ddl.utils import clean_str
from twindigrid_sql.ddl.view import View


@dataclass
class CallableBody(DialectKWArgs):
    pass


@dataclass
class SqlBody(CallableBody):
    statements: list[ClauseElement]

    __visit_name__ = "callable_body_sql"


@compiles(SqlBody)
def visit_callable_body_sql(body: SqlBody, compiler: DDLCompiler, **kw):
    return "BEGIN ATOMIC\n%s;\nEND" % (
        ";\n".join(
            compiler.sql_compiler.process(s, literal_binds=True) 
            for s in body.statements
        ),
    )


@dataclass
class SqlTextBody(CallableBody):
    statements: list[ClauseElement]

    __visit_name__ = "callable_body_sqltext"


@compiles(SqlTextBody)
def visit_callable_body_sqltext(body: SqlTextBody, compiler: DDLCompiler, **kw):
    return "LANGUAGE SQL AS $callablebody$\n%s\n$callablebody$" % (
        ";\n".join(
            compiler.sql_compiler.process(s, literal_binds=True) 
            for s in body.statements
        ),
    )


@dataclass
class TextBody(CallableBody):
    language: str
    text: str

    __visit_name__ = "callable_body_text"


@compiles(TextBody)
def visit_callable_body_sqltext(body: TextBody, compiler: DDLCompiler, **kw):
    return "%sAS $callablebody$\n%s\n$callablebody$" % (
        f"LANGUAGE {body.language} " if body.language else "",
        clean_str(body.text),
    )


@dataclass
class ExpressionBody(CallableBody):
    expr: ColumnClause

    __visit_name__ = "callable_body_expression"


@compiles(ExpressionBody)
def visit_callable_body_expression(body: ExpressionBody, compiler: DDLCompiler, **kw):
    return "RETURN %s" % (
        compiler.sql_compiler.process(body.expr, literal_binds=True),
    )


@dataclass
class CallableArg:
    type: TypeEngine
    name: Optional[str] = None
    mode: Optional[Literal['IN', 'OUT', 'INOUT', 'VARIADIC']] = None
    default: Optional[ColumnClause] = None

    @property
    def col(self) -> ColumnClause:
        return ColumnClause(self.name, self.type)

    __visit_name__ = "callable_arg"


@compiles(CallableArg)
def visit_callable_arg(arg: CallableArg, compiler: DDLCompiler, **kw):
    return "%s%s%s%s" %(
        f"{arg.mode} " if arg.mode else "",
        f"{arg.name} " if arg.name else "",
        compiler.type_compiler.process(arg.type),
        f" = {compiler.process(arg.default)}" if arg.default else ""
    )


@dataclass(kw_only=True)
class Callable(DialectKWArgs, HasSchemaAttr):
    name: str
    schema: str
    args: list[CallableArg] = field(default_factory=list)
    body: CallableBody
    type: Literal['PROCEDURE', 'FUNCTION'] = field(init=False)
    comment: Optional[str] = None


@dataclass(kw_only=True)
class Procedure(Callable):
    type = "PROCEDURE"


@dataclass
class ReturnColumn:
    name: str
    type: TypeEngine


@dataclass
class ReturnTable:
    columns: list[ColumnElement]


@dataclass(kw_only=True)
class Function(Callable):
    volatility: Literal['VOLATILE', 'STABLE', 'IMMUTABLE']
    rettype: Union[TypeEngine, ReturnTable, Table, View]
    type = "FUNCTION"


@dataclass(kw_only=True)
class TableFunction(Function):
    
    @property
    def columns(self) -> list[ColumnElement]:
        match self.rettype:
            case ReturnTable():
                return self.rettype.columns
            case Table():
                return self.rettype.columns
            case View():
                return self.rettype.query.selected_columns
            case _:
                raise Exception("uncompatible rettype for a table function")

    def func(self, *args, **kwargs) -> TableValuedAlias:
        return getattr(getattr(func, self.schema), self.name)(
            *args, **kwargs
        ).table_valued(*self.columns)
        


class Call(Executable, ClauseElement):
    inherit_cache = False

    proc: Function

    def __init__(self, proc: Function):
        self.proc = proc

    __visit_name__ = "call_procedure"


def call(proc: Function):
    return Call(proc)


@compiles(Call)
def visit_call_procedure(call: Call, compiler: DDLCompiler, **kw):
    return "CALL %s" %(
        compiler.process(call.proc),
    )


class CreateCallable(_CreateDropBase):
    element: Callable
    or_replace: bool

    __visit_name__ = "create_callable"

    def __init__(self, element: Callable, or_replace=False) -> None:
        super().__init__(element)
        self.or_replace = or_replace


@compiles(CreateCallable)
def visit_create_procedure(create: CreateCallable, compiler: DDLCompiler, **kw):
    e = create.element

    match e:
        case Procedure():
            returns_part = ""
            volatility_part = ""
        case Function():
            match e.rettype:
                case ReturnTable():
                    returns_type = "TABLE (%s)" % (
                        ",".join(
                            "%s %s" % (
                                c.name,
                                compiler.type_compiler.process(c.type)
                            )
                            for c in e.rettype.columns
                        )
                    )
                case Table():
                    returns_type = "SETOF %s.%s" % (
                        e.rettype.schema,
                        e.rettype.name,
                    )
                case View():
                    returns_type = "SETOF %s.%s" % (
                        e.rettype.schema,
                        e.rettype.name,
                    )
                case _:
                    returns_type = compiler.type_compiler.process(e.rettype)
            returns_part = " RETURNS %s" % (
                returns_type,
            )
            volatility_part = e.volatility

    definition = "%s %s.%s (%s)" % (
        e.type,
        compiler.preparer.format_schema(e.schema),
        compiler.preparer.quote(e.name),
        ", ".join([compiler.process(arg) for arg in e.args]),

    )
    
    return "CREATE%s %s%s %s %s;\n" % (
        " OR REPLACE" if create.or_replace else "",
        definition,
        returns_part,
        volatility_part,
        compiler.process(e.body),
    ) + ("COMMENT ON %s IS %s;\n" % (
        definition,
        compiler.sql_compiler.render_literal_value(
            clean_str(e.comment), sqltypes.String()
        ),
    ) if e.comment else "")
