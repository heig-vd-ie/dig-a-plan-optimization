from __future__ import annotations
from collections import OrderedDict
from dataclasses import dataclass
import sys
from types import ModuleType
from typing import Any, Callable, NamedTuple, Optional, Self, TypedDict, Unpack

from sqlalchemy import CheckConstraint, Column, ColumnClause, ColumnElement, ExecutableDDLElement, ForeignKey, ForeignKeyConstraint, MetaData, Select, Table, delete, insert, literal_column, select, event, update
from sqlalchemy.sql.schema import SchemaItem, SchemaEventTarget
from sqlalchemy.dialects.postgresql import ExcludeConstraint
from sqlalchemy.sql.expression import and_

from twindigrid_sql.custom_types import TIMESTAMPTZ
from twindigrid_sql.ddl.callable import CreateCallable, Procedure, CallableArg, ReturnTable, SqlBody, SqlTextBody, TableFunction, TextBody
from twindigrid_sql.ddl.utils import NamedTupleMeta, clean_str


class SchemaMeta(NamedTuple):
    name: str
    comment: str

    @classmethod
    def of(cls, m: ModuleType):
        module_name = m.__name__
        ms = module_name.split('.')
        s = ms[ms.index('schema')+1]

        assert m.__doc__ is not None, f"Missing schema module doc string for {module_name}"

        return SchemaMeta(
            name=s,
            comment=clean_str(m.__doc__),
        )


@dataclass(frozen=True)
class GeneratedDDL:
    meta: SchemaElementMeta


@dataclass(frozen=True)
class SchemaElementMeta:
    name: str
    schema: str
    comment: str
    type: str
    metadata_object: MetaData

    def qs(self, name: str) -> str:
        """Fully qualifed element of the schema"""
        return f"{self.schema}.{name}"

    def generate_ddl(self) -> GeneratedDDL:
        return GeneratedDDL(meta=self)
    
    @classmethod
    def from_module(cls, module_name: str, metadata_object: MetaData) -> Self:
        """
        Create a SchemaElementMeta from a module name.
        
        The module name must end with the pattern: schema.<schema_name>.<elem_type>_<elem_name>
        """
        module_segments = module_name.split('.')
        [schema_name, mn] = module_segments[module_segments.index('schema')+1:]

        type_end = mn.index("_")
        elem_type = mn[:type_end]
        elem_name = mn[type_end + 1:]

        module = sys.modules[module_name]
        assert module.__doc__ is not None, "Missing schema element doc string"

        return SchemaElementMeta(
            name=elem_name, 
            schema=schema_name,
            comment=clean_str(module.__doc__),
            type=elem_type,
            metadata_object=metadata_object,
        )
    
    def specify[**P, S](self, subtype: Callable[[Self], Callable[P, S]]) -> Callable[P, S]:
        return subtype(self)


class TableParams(NamedTuple):
    args: tuple[SchemaItem, ...]
    kwargs: dict[str, Any]

    def __add__(self, o):
        self.kwargs.update(o.kwargs)
        return TableParams(
            self.args + o.args,
            self.kwargs
        )

    @classmethod
    def of(cls, *args, **kwargs) -> Self:
        return TableParams(args, kwargs)


class ColumnArg(TypedDict):
    nullable: bool
    primary_key: bool
    unique: bool
    server_default: ColumnElement[Any]


@dataclass(frozen=True)
class TableMeta[F, C, I](SchemaElementMeta):
    fields: Optional[NamedTupleMeta[F]]
    constraints: Optional[NamedTupleMeta[C]]
    indices: Optional[NamedTupleMeta[I]]

    def __post_init__(self):
        valid_types = ["mixin", "table"]
        if self.type not in valid_types:
            raise Exception(f"TableMeta should be of type {" or ".join(valid_types)}, not {self.type}")
    
    @classmethod
    def inherits(cls, parent: SchemaElementMeta):
        def inner[F2, C2, I2](
            fields_nt: Optional[type[F2]] = None,
            constraints_nt: Optional[type[C2]] = None,
            indices_nt: Optional[type[I2]] = None,
        ) -> TableMeta[F2, C2, I2]:
            return TableMeta(parent.name, parent.schema, parent.comment, parent.type, parent.metadata_object, 
                            NamedTupleMeta.from_namedtuple(fields_nt), 
                            NamedTupleMeta.from_namedtuple(constraints_nt), 
                            NamedTupleMeta.from_namedtuple(indices_nt),
                            )
        return inner
        

    def Table(self, 
              params: TableParams, 
              depends_on: list[Table] = []
              ) -> Table:
        t = Table(self.name, self.metadata_object,
                     *params.args,
                     **params.kwargs,
                     schema=self.schema,
                     comment=self.comment)
        
        # Check if there exists unused documented columns
        if self.fields:
            created_cols = set(c.name for c in t.columns)
            documented_cols = set(self.fields.type._fields)
            unused_documented_cols = documented_cols - created_cols
            assert len(unused_documented_cols) == 0, f"The following columns are documented but not present in {self.schema}.{self.name}: {", ".join(unused_documented_cols)}"

        for dep in depends_on:
            t.add_is_dependent_on(dep)          

        return t
    
    def Column(self, name, *args: SchemaEventTarget, **kwargs: Unpack[ColumnArg]) -> Column:
        return Column(name, *args, **kwargs, comment=self.fields.comments[name])

    def CheckConstraint(self, name, sqltext, *args, **kwargs) -> CheckConstraint:
        return CheckConstraint(sqltext, *args, **kwargs, name=name, comment=self.constraints.comments[name])

    def ExcludeConstraint(self, name, *args, **kwargs) -> ExcludeConstraint:
        return ExcludeConstraint(*args, **kwargs, name=name, comment=self.constraints.comments[name])

    def qt(self, name: str) -> str:
        """Fully qualified element of the table"""
        return f"{self.schema}.{self.name}.{name}"

    def qts(self, names: list[str]) -> str:
        """Fully qualified elements of the table"""
        return [f"{self.schema}.{self.name}.{name}" for name in names]

    @property
    def f(self):
        return self.fields.named if self.fields else None

    @property
    def c(self):
        return self.constraints.named if self.constraints else None

    @property
    def i(self):
        return self.indices.named if self.indices else None
    
    def explode(self) -> tuple[Self, F, C, I]:
        """Allows quick access to name of fields, constraints and indices"""
        return (self, 
                self.f, 
                self.c, 
                self.i,
                )

    def generate_ddl(self, params: TableParams) -> GeneratedTableDDL:
        table = self.Table(params)
        return GeneratedTableDDL(
            meta=self,
            table=table,
            params=params,
        )


@dataclass(frozen=True)
class GeneratedTableDDL[F, C, I](GeneratedDDL):
    meta: TableMeta[F, C, I]
    table: Table
    params: TableParams
