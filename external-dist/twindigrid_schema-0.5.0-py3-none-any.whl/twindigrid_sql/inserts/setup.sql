insert into "Abstraction" values
	(uuid_generate_v5('bc4d4e0c-98c9-11ec-b909-0242ac120002', 'Abstraction.physical'), 'physical', null),
	(uuid_generate_v5('bc4d4e0c-98c9-11ec-b909-0242ac120002', 'Abstraction.abstract'), 'abstract', uuid_generate_v5('bc4d4e0c-98c9-11ec-b909-0242ac120002', 'Abstraction.physical'));

insert into "MeasurementSource" values
	(uuid_generate_v5('bc4d4e0c-98c9-11ec-b909-0242ac120002', 'MeasurementSource.scada'), 'scada'),
	(uuid_generate_v5('bc4d4e0c-98c9-11ec-b909-0242ac120002', 'MeasurementSource.smartMeter'), 'smartMeter'),
	(uuid_generate_v5('bc4d4e0c-98c9-11ec-b909-0242ac120002', 'MeasurementSource.aggregatedMeter'), 'aggregatedMeter'),
	(uuid_generate_v5('bc4d4e0c-98c9-11ec-b909-0242ac120002', 'MeasurementSource.gridEye'), 'gridEye'),
	(uuid_generate_v5('bc4d4e0c-98c9-11ec-b909-0242ac120002', 'MeasurementSource.conventionalMeter'), 'conventionalMeter'),
	(uuid_generate_v5('bc4d4e0c-98c9-11ec-b909-0242ac120002', 'MeasurementSource.digitalTwin'), 'digitalTwin');

insert into "Heartbeat" values
	-- align stardate to previous interval (aligned to midnight)
	(date_bin('10 min', now(), '2022-01-15'), interval '10 min');

-- Insert a single group mapping for each abstraction.
-- Insertion of non-root abstraction because MeasurementDevice can be created with no group mapping
insert into "GroupMapping" (uuid, abstraction_fk, record_install_date)
	select a.uuid, a.uuid, hb.start_date
	from
		"Abstraction" a,
		( -- retrieve the start_date of the first heartbeat
			select *
			from "Heartbeat"
			order by start_date asc
			limit 1
		) hb;
