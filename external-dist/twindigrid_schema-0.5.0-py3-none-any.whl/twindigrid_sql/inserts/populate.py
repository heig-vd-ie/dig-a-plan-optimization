from sqlalchemy import insert, Connection
from twindigrid_sql.entries import NAMESPACE_UUID
import twindigrid_sql.entries.abstraction as a
import twindigrid_sql.entries.source as s
from twindigrid_sql.entries.measurement_type import *
from twindigrid_sql.entries.operation_type import *
from twindigrid_sql.entries.unit_symbol import *
from twindigrid_sql.entries.equipment_class import *
from twindigrid_sql.entries.container_class import *
from twindigrid_sql.schema.enum import ResourceClassGroup, TerminalSide as T, VoltageType
from twindigrid_sql.schema import history

def populate(conn: Connection):
    conn.execute(insert(history.table_abstraction.g.table), [
        dict(name=a.PHYSICAL,     description="The abstraction layer where the actual real word topology is stored",    parent_fk=None),
        dict(name=a.DIGITAL_TWIN, description="The abstraction layer where the result of the digital twin computation are stored", parent_fk=a.PHYSICAL),
    ])

    conn.execute(insert(history.table_resource_class.g.table), [
        dict(name=BESS,             group=ResourceClassGroup.EQUIPMENT, valid_sides=[T.T1],               description=history.table_bess.g.meta.comment),
        dict(name=BRANCH,           group=ResourceClassGroup.EQUIPMENT, valid_sides=[T.T1],               description=history.table_branch.g.meta.comment),
        dict(name=BUSBAR_SECTION,   group=ResourceClassGroup.EQUIPMENT, valid_sides=[T.T1],               description=history.table_busbar_section.g.meta.comment),
        dict(name=ENERGY_CONSUMER,  group=ResourceClassGroup.EQUIPMENT, valid_sides=[T.T1],               description=history.table_energy_consumer.g.meta.comment),
        dict(name=EXTERNAL_NETWORK, group=ResourceClassGroup.EQUIPMENT, valid_sides=[T.T1],               description=history.table_external_network.g.meta.comment),
        dict(name=SWITCH,           group=ResourceClassGroup.EQUIPMENT, valid_sides=[T.T1, T.T2],         description=history.table_switch.g.meta.comment),
        dict(name=TRANSFORMER,      group=ResourceClassGroup.EQUIPMENT, valid_sides=[T.T1, T.T2, T.T3],   description=history.table_transformer.g.meta.comment),
        dict(name=GENERATING_UNIT,  group=ResourceClassGroup.EQUIPMENT, valid_sides=[T.T1, T.T2],         description=history.table_generating_unit.g.meta.comment),
        dict(name=METER,            group=ResourceClassGroup.EQUIPMENT, valid_sides=[T.T1, T.T2],         description="Meters"),
        dict(name=INDIRECT_FEEDER,  group=ResourceClassGroup.EQUIPMENT, valid_sides=[T.T1, T.T2],         description="Represents an indirect connection between 2 connectivity node"),
        dict(name=SUBSTATION,       group=ResourceClassGroup.CONTAINER, valid_sides=None,                 description=history.table_substation.g.meta.comment),
        dict(name=CLIENT,           group=ResourceClassGroup.CONTAINER, valid_sides=None,                 description=history.table_client.g.meta.comment),
        dict(name=BAY,              group=ResourceClassGroup.CONTAINER, valid_sides=None,                 description="Groups the terminals of a cell"),
    ])

    conn.execute(insert(history.table_base_voltage.g.table), [
        dict(nominal_voltage=    400, type=VoltageType.LV.value,  low_voltage_limit=    360, high_voltage_limit=    440),
        dict(nominal_voltage=  1_000, type=VoltageType.LV.value,  low_voltage_limit=    900, high_voltage_limit=  1_000),
        dict(nominal_voltage=  2_500, type=VoltageType.MV.value,  low_voltage_limit=  2_250, high_voltage_limit=  2_750),
        dict(nominal_voltage=  6_000, type=VoltageType.MV.value,  low_voltage_limit=  5_400, high_voltage_limit=  6_600),
        dict(nominal_voltage= 18_200, type=VoltageType.MV.value,  low_voltage_limit= 17_920, high_voltage_limit= 19_110),
        dict(nominal_voltage= 64_000, type=VoltageType.HV.value, low_voltage_limit= 67_200, high_voltage_limit= 60_800),
        dict(nominal_voltage=130_000, type=VoltageType.HV.value,  low_voltage_limit=123_500, high_voltage_limit=136_500),
        dict(nominal_voltage=220_000, type=VoltageType.EHV.value, low_voltage_limit=198_000, high_voltage_limit=242_000),
        dict(nominal_voltage=380_000, type=VoltageType.EHV.value, low_voltage_limit=342_000, high_voltage_limit=418_000),
    ])

    conn.execute(insert(history.table_group_mapping.g.table), [
        dict(uuid=a.abstraction_uuid(a.PHYSICAL),    abstraction_fk=a.PHYSICAL),
        dict(uuid=a.abstraction_uuid(a.DIGITAL_TWIN), abstraction_fk=a.DIGITAL_TWIN),
    ])

    conn.execute(insert(history.table_source.g.table), [
        dict(name=s.SCADA,              abstraction_fk=a.PHYSICAL,     description=""),
        dict(name=s.ESTIMATED,          abstraction_fk=a.PHYSICAL,     description=""),
        dict(name=s.OTC,                abstraction_fk=a.PHYSICAL,     description=""),
        dict(name=s.SMART_METER,        abstraction_fk=a.PHYSICAL,     description=""),
        dict(name=s.GRID_EYE,           abstraction_fk=a.PHYSICAL,     description=""),
        dict(name=s.GRID_LOAD,          abstraction_fk=a.PHYSICAL,     description=""),
        dict(name=s.POWER_QUALITY,      abstraction_fk=a.PHYSICAL,     description=""),
        dict(name=s.DISTURBANCE,        abstraction_fk=a.PHYSICAL,     description=""),
        dict(name=s.CONVENTIONAL_METER, abstraction_fk=a.PHYSICAL,     description=""),
        dict(name=s.AGGREGATED_METER,   abstraction_fk=a.DIGITAL_TWIN, description=""),
        dict(name=s.DIGITAL_TWIN,       abstraction_fk=a.DIGITAL_TWIN, description=""),
    ])

    conn.execute(insert(history.table_measurement_type.g.table), [
        dict(name=VOLTAGE, description=None),
        dict(name=CURRENT, description=None),
        dict(name=ACTIVE_POWER, description=None),
        dict(name=REACTIVE_POWER, description=None),
        dict(name=APPARENT_POWER, description=None),
        dict(name=ENERGY, description=None),
    ])

    conn.execute(insert(history.table_operation_type.g.table), [
        dict(name=AVG),
        dict(name=MAX),
        dict(name=MIN),
        dict(name=RMS),
        dict(name=ABS),
        dict(name=COS_PHI),
        dict(name=TAN_PHI),
    ] + [
        dict(name=HARMONIC(i + 1))
        for i in range(50)
    ] + [
        dict(name=INTER_HARMONIC(i + 1))
        for i in range(50)
    ])

    conn.execute(insert(history.table_unit_symbol.g.table), [
        dict(name=VOLT,   description="volt"),
        dict(name=AMPERE,   description="ampere"),
        dict(name=WATT,   description="watt"),
        dict(name=WATTHOUR,   description="watt hour"),
        dict(name=VOLT_AMPERE, description="volt-ampere"),
    ])
