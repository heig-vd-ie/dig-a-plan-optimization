import uuid
from twindigrid_sql.entries import NAMESPACE_UUID

PHYSICAL = "physical"
DIGITAL_TWIN = "digital_twin"

def abstraction_uuid(name: str) -> uuid:
    """Used when creating the initial group mapping for an equipment."""
    return uuid.uuid5(NAMESPACE_UUID, f"Abstraction.{name}")
