SUBSTATION = "substation"
CLIENT = "client"
BAY = "bay"
