VOLTAGE="voltage"
CURRENT="current"
ACTIVE_POWER="active power"
REACTIVE_POWER="reactive power"
APPARENT_POWER="apparent power"
ENERGY="energy"

