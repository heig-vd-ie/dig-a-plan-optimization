import uuid
from twindigrid_sql.entries import NAMESPACE_UUID

SCADA = "scada"
ESTIMATED = "estimated"
OTC = "otc"
SMART_METER = "smartMeter"
AGGREGATED_METER = "aggregated_meter"
GRID_EYE = "grid_eye"
GRID_LOAD = "grid_load"
POWER_QUALITY = "power_quality"
DISTURBANCE = "disturbance"
CONVENTIONAL_METER = "conventional_meter"
DIGITAL_TWIN = "digital_twin"
