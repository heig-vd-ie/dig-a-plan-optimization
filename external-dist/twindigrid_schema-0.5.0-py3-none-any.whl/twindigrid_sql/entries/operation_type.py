AVG="AVG"
MAX="MAX"
MIN="MIN"
RMS="RMS"
ABS="ABS"
COS_PHI="COS_PHI"
TAN_PHI="TAN_PHI"

def INTER_HARMONIC(number: int) -> str:
    return f"INTER_HARMONIC{number}"

def HARMONIC(number: int) -> str:
    return f"HARMONIC{number}"

def op(*ops) -> str:
    return "." + ".".join(ops)