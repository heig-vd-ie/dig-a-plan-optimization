import uuid

# The namespace used to create fixed UUID for default entries
NAMESPACE_UUID: uuid.UUID = uuid.UUID('{bc4d4e0c-98c9-11ec-b909-0242ac120002}')
