
from sqlalchemy.dialects.postgresql import TIMESTAMP

TIMESTAMPTZ = TIMESTAMP(timezone=True)
