CREATE TYPE "diff" AS ENUM ('+', '!', '-');
CREATE TYPE "equipmenttype" AS ENUM ( 'bess', 'branch', 'busbarSection', 'energyConsumer', 'externalNetwork', 'pv', 'switch', 'transformer', 'synchronousGenerationUnit', 'measurementDevice');

-- 't1' is always higher voltage side in transformer
-- 't1' is start of linestring of a branch
CREATE TYPE "terminalside" AS ENUM ( 't', 't1', 't2');
CREATE TYPE "phases" AS ENUM ('ABC', 'ABCn', 'An', 'Bn', 'Cn', 'AB', 'BC', 'AC');
create type "eventsource" as enum ('autoRaw', 'manualRaw' , 'digitaltwin');
create type "profiletype" as enum ('residential', 'commercial', 'industrial');
CREATE TYPE "controllable" AS ENUM ('manualOffLoad', 'manualOnLoad', 'autoOffLoad', 'autoOnLoad', 'no');
CREATE TYPE "vectorgroup" AS ENUM ('Dy1', 'Dy5', 'Dy11', 'Yy0', 'Yz1', 'Yz5', 'Yz11', 'Ynd1');
CREATE TYPE "phase" AS ENUM ('A', 'B', 'C');
CREATE TYPE "eventtype" AS ENUM ('noVoltage', 'underVoltage', 'overVoltage', 'overCurrent');
-- as Snapshot
-- as Diff

-- todo add foreign key?
CREATE TABLE "Heartbeat"(
	start_date TIMESTAMP PRIMARY KEY,
	freq INTERVAL NOT NULL,
	record_date TIMESTAMP NOT NULL,
    diff diff
);
CREATE TABLE "Bess"(
    uuid UUID PRIMARY KEY,
    charging_eff FLOAT8,
    discharging_eff FLOAT8,
    rated_s FLOAT8,
    rated_e FLOAT8,
    min_charging_p FLOAT8,
    max_charging_p FLOAT8,
    min_discharging_p FLOAT8,
    max_discharging_p FLOAT8,
    geo json,
    name varchar,
    phases phases,
    gm_fk UUID,
    diff diff
);
CREATE TABLE "Branch"(
    uuid UUID PRIMARY KEY,
    current_limit FLOAT8,
    length FLOAT8,
    is_underground boolean,
    geo json,
    name varchar,
    t1_phases phases,
    t2_phases phases,
    gm_fk UUID,
    diff diff
);
CREATE TABLE "BranchParameterEvent"(
	eq_fk UUID NOT NULL,
    timestamp timestamp NOT NULL,
    value_source eventsource NOT NULL,
	r float8 NOT NULL,
	r0 float8 NOT NULL DEFAULT 0,
	x float8 NOT NULL,
	x0 float8 NOT NULL DEFAULT 0,
	b float8 NOT NULL DEFAULT 0,
	b0 float8 NOT NULL DEFAULT 0,
    diff diff,
	PRIMARY KEY(eq_fk, timestamp, value_source)
);
CREATE TABLE "BusbarSection"(
    uuid UUID PRIMARY KEY,
	voltage_level float8 NOT NULL,
	voltage_min float8 NOT NULL,
	voltage_max float8 NOT NULL,
    geo json,
    name varchar,
    phases phases,
    gm_fk UUID,
    diff diff
);
CREATE TABLE "EnergyConsumer"(
    uuid UUID PRIMARY KEY,
	rated_s float8 NOT NULL,
	profile_type profiletype NOT NULL,
    geo json,
    name varchar,
    phases phases,
    gm_fk UUID,
    diff diff
);
CREATE TABLE "ExternalNetwork"(
    uuid UUID PRIMARY KEY,
	r_eq float8 NOT NULL DEFAULT 0,
	x_eq float8 NOT NULL DEFAULT 0,
    geo json,
    name varchar,
    phases phases,
    gm_fk UUID,
    diff diff
);
CREATE TABLE "Pv"(
    uuid UUID PRIMARY KEY,
	cos_phi_limit float8 NOT NULL DEFAULT 1,
	rated_s float8 NOT NULL,
    geo json,
    name varchar,
    phases phases,
    gm_fk UUID,
    diff diff
);
CREATE TABLE "Switch"(
    uuid UUID PRIMARY KEY,
	normal_open bool NOT NULL,
	controllable controllable NOT NULL,
    geo json,
    name varchar,
    t1_phases phases,
    t2_phases phases,
    gm_fk UUID,
    diff diff
);
CREATE TABLE "SwitchEvent"(
	eq_fk UUID NOT NULL,
    timestamp timestamp NOT NULL,
    value_source eventsource NOT NULL,
	"open" bool NOT NULL,
    diff diff,
	PRIMARY KEY(eq_fk, timestamp, value_source)
);
CREATE TABLE "SynchronousGenerationUnit"(
    uuid UUID PRIMARY KEY,
	max_operating_p float8 NOT NULL,
	min_operating_p float8 NOT NULL,
	rated_s float8 NOT NULL,
    geo json,
    name varchar,
    phases phases,
    gm_fk UUID,
    diff diff
);
CREATE TABLE "Transformer"(
    uuid UUID PRIMARY KEY,
	vector_group vectorgroup NOT NULL,
	rated_s float8 NOT NULL,
    taps_t1 float8[] NOT NULL,
    taps_t2 float8[] NOT NULL,
    geo json,
    name varchar,
    t1_phases phases,
    t2_phases phases,
    gm_fk UUID,
    diff diff
);
CREATE TABLE "TransformerParameterEvent"(
	eq_fk UUID NOT NULL,
    timestamp timestamp NOT NULL,
    value_source eventsource NOT NULL,
	r float8 NOT NULL,
	r0 float8 NOT NULL DEFAULT 0,
	x float8 NOT NULL,
	x0 float8 NOT NULL DEFAULT 0,
	b float8 NOT NULL DEFAULT 0,
	b0 float8 NOT NULL DEFAULT 0,
	g float8 NOT NULL DEFAULT 0,
	g0 float8 NOT NULL DEFAULT 0,
    diff diff,
	PRIMARY KEY(eq_fk, timestamp, value_source)
);
CREATE TABLE "TapEvent"(
	eq_fk UUID NOT NULL,
    timestamp timestamp NOT NULL,
	value FLOAT8 NOT NULL,
	is_tap_t1 bool NOT NULL,
    value_source eventsource NOT NULL,
    diff diff,
	PRIMARY KEY(is_tap_t1, eq_fk)
);
CREATE TABLE "Abstraction"(
    uuid UUID PRIMARY KEY,
    "name" VARCHAR NOT NULL,
    parent_fk UUID,
    diff diff
);
CREATE TABLE "GroupMapping"(
    uuid UUID PRIMARY KEY,
    abstraction_fk UUID NOT NULL,
    diff diff
);
CREATE TABLE "EquipmentGroupMapping"(
    eq_fk UUID NOT NULL,
    gm_fk UUID NOT NULL,
    diff diff
);
CREATE TABLE "TerminalMapping"(
    gm_fk UUID NOT NULL,
    source_eq_fk UUID NOT NULL,
	source_side terminalside NOT NULL,
	sink_eq_fk UUID NOT NULL,
	sink_side terminalside NOT NULL,
    diff diff
);
CREATE TABLE "CnMapping"(
    gm_fk UUID NOT NULL,
    source_cn_fk UUID NOT NULL,
	sink_cn_fk UUID NOT NULL,
    diff diff
);
CREATE TABLE "Connectivity"(
    eq_fk UUID NOT NULL,
    side "terminalside" NOT NULL,
    concrete_type equipmenttype NOT NULL,
    abstraction_fk UUID NOT NULL,
    cn_fk UUID,
	timestamp TIMESTAMP NOT NULL,
    diff diff
);
CREATE TABLE "Topology"(
    cn_fk UUID NOT NULL,
    tn_fk UUID NOT NULL,
    diff diff
);
CREATE TABLE "ConnectedGroup"(
    uuid UUID NOT NULL,
    name VARCHAR,
	is_disconnected bool not null,
    diff diff
);
CREATE TABLE "EquipmentConnectedGroup"(
    connected_group_fk UUID NOT NULL,
	eq_fk UUID NOT NULL,
    diff diff
);
CREATE TABLE "MeasurementSource" (
	uuid uuid primary key,
	name varchar NULL,
	metadata json,
    diff diff
);
CREATE TABLE "MeasurementDevice" (
	uuid uuid primary key,
	accuracy_active_power float8 not null,
	accuracy_current float8 not null,
	accuracy_reactive_power float8 not null,
	accuracy_voltage float8 not null,
	rated_current float8 not null,
	aggregation_period float8 not null,
	value_source_fk uuid NOT null,
    geo json,
    name varchar,
    gm_fk UUID,
    diff diff
);
-- TODO: split MeasurementValue because of forecasting
CREATE TABLE "MeasurementTerminal" (
	uuid uuid primary key,
	measurement_device_fk uuid not null,
	eq_fk uuid not null,
	side terminalside not null,
    diff diff
);
CREATE TABLE "MeasurementValue"(
	measurement_terminal_fk uuid not null,
	timestamp timestamp NOT NULL,
	avg_active_power_a float8 NULL,
	avg_active_power_b float8 NULL,
	avg_active_power_c float8 NULL,
	std_active_power_a float8 NULL,
	std_active_power_b float8 NULL,
	std_active_power_c float8 NULL,
	med_active_power_a float8 NULL,
	med_active_power_b float8 NULL,
	med_active_power_c float8 NULL,
	lq_active_power_a float8 NULL,
	lq_active_power_b float8 NULL,
	lq_active_power_c float8 NULL,
	uq_active_power_a float8 NULL,
	uq_active_power_b float8 NULL,
	uq_active_power_c float8 NULL,
	min_active_power_a float8 NULL,
	min_active_power_b float8 NULL,
	min_active_power_c float8 NULL,
	max_active_power_a float8 NULL,
	max_active_power_b float8 NULL,
	max_active_power_c float8 NULL,
	avg_current_a float8 NULL,
	avg_current_b float8 NULL,
	avg_current_c float8 NULL,
	std_current_a float8 NULL,
	std_current_b float8 NULL,
	std_current_c float8 NULL,
	med_current_a float8 NULL,
	med_current_b float8 NULL,
	med_current_c float8 NULL,
	lq_current_a float8 NULL,
	lq_current_b float8 NULL,
	lq_current_c float8 NULL,
	uq_current_a float8 NULL,
	uq_current_b float8 NULL,
	uq_current_c float8 NULL,
	min_current_a float8 NULL,
	min_current_b float8 NULL,
	min_current_c float8 NULL,
	max_current_a float8 NULL,
	max_current_b float8 NULL,
	max_current_c float8 NULL,
	avg_reactive_power_a float8 NULL,
	avg_reactive_power_b float8 NULL,
	avg_reactive_power_c float8 NULL,
	std_reactive_power_a float8 NULL,
	std_reactive_power_b float8 NULL,
	std_reactive_power_c float8 NULL,
	med_reactive_power_a float8 NULL,
	med_reactive_power_b float8 NULL,
	med_reactive_power_c float8 NULL,
	lq_reactive_power_a float8 NULL,
	lq_reactive_power_b float8 NULL,
	lq_reactive_power_c float8 NULL,
	uq_reactive_power_a float8 NULL,
	uq_reactive_power_b float8 NULL,
	uq_reactive_power_c float8 NULL,
	min_reactive_power_a float8 NULL,
	min_reactive_power_b float8 NULL,
	min_reactive_power_c float8 NULL,
	max_reactive_power_a float8 NULL,
	max_reactive_power_b float8 NULL,
	max_reactive_power_c float8 NULL,
	avg_voltage_a float8 NULL,
	avg_voltage_b float8 NULL,
	avg_voltage_c float8 NULL,
	std_voltage_a float8 NULL,
	std_voltage_b float8 NULL,
	std_voltage_c float8 NULL,
	med_voltage_a float8 NULL,
	med_voltage_b float8 NULL,
	med_voltage_c float8 NULL,
	lq_voltage_a float8 NULL,
	lq_voltage_b float8 NULL,
	lq_voltage_c float8 NULL,
	uq_voltage_a float8 NULL,
	uq_voltage_b float8 NULL,
	uq_voltage_c float8 NULL,
	min_voltage_a float8 NULL,
	min_voltage_b float8 NULL,
	min_voltage_c float8 NULL,
	max_voltage_a float8 NULL,
	max_voltage_b float8 NULL,
	max_voltage_c float8 NULL,
    diff diff
);
CREATE TABLE "MeasurementEvent"(
	timestamp timestamp NOT NULL,
	value float8 NULL,
	"type" eventtype NULL,
	measurement_terminal_fk uuid not null,
	phase phase not NULL,
    diff diff
);
