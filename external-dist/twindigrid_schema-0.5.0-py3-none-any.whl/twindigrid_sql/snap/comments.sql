comment on schema snap is $md$
### Data classification:
---
It contains the table used for the in-memory data structure, classified into the following categories, sub-categories, and sub-subcategories modeled by set of tables:

* Grid model:
Grid model information usually comes from **GIS** (Geographical Information System), **AIS** (Asset Information System), or **NIS** (Network Information System).
    * Equipment models:
        + `Bess`, `Branch`, `EnergyConsumer`, `BusbarSection`, `ExternalNetwork`, `Pv`, `Switch`, `SynchronousGenerationUnit`, `Transformer`.
    *  Connectivity model:
        + `Connectivity`, `Topology`, `ConnectedGroup`, `EquipmentConnectedGroup`.
    * Abstractions model:
        + `Abstraction`, `GroupMapping`, `EquipmentGroupMapping`, `TerminalMapping`, `CnMapping`.

* Electrical quantities measurements:
The electrical quantities can be any kind of grid measurements (e.g., **GridEye** data) and end-customer metering data (e.g., **smart metering** data).
    * Measurements model:
        + `MeasurementSource`, `MeasurementDevice`, `MeasurementTerminal`, `MeasurementValue`.
    * Events model:
        + `MeasurementEvent`, `SwitchEvent`, `TapEvent`, `BranchParameterEvent`, `TransformerParameterEvent`.
    * Heartbeat model:
        + `Heartbeat`.
---

### Naming convention rules:
---
1. The naming would be the same for the classes and attributes that exist within **CGMES** (Common Grid Model Exchange Specification).
2. The table name follows `PascalCase` (it begins with an uppercase letter), such as `ConnectivityNode`.
3. The attribute follows `snake_case` (it begins with a lowercase letter and each word is separated by an underscore).
4. The name of intermediary tables includes the names of both connected tables, e.g., `EquipmentGroupMapping`.
---

### Integrity constraints:
---
1. If the `value_source` of a `MeasurementDevice` is `estimated` or `forecasted`, then the `Abstraction` of that `MeasurementDevice` must be `abstract`.
2. If the `value_source` of a `MeasurementDevice` is `scada`, `smartMeter`, `gridEye`, `conventionalMeter`, or `aggregatedMeter`, then the `Abstraction` of that `MeasurementDevice` must be `physical`.
3. The `install_date` of each `Connectivity` must be before the `uninstall_date`.
4. The `record_install_date` of each `Connectivity` must be before the `record_uninstall_date`.
5. The `record_install_date` and `record_uninstall_date` of each `Connectivity` must be after the `install_date` and `uninstall_date`, respectively.
6. The geo attribute of `BusbarSection` is obligatory; however, the `geo` attributes of other equipment are optional.
7. If there are two `BusbarSection` not seperated by any `Branch`, both must have same `geo`.
8. If there is a `geo` for a `Branch`, it should be a linestring from `t1` to `t2` without any repetition of the point in the linestring.
---

<p align="center">
<img src="https://www.depsys.com/assets/img/depsys_Identity-202008.png" alt="DEPsys logo" height="120"> <img src="https://heig-vd.ch/docs/default-source/doc-global-newsletter/2020-slim.svg" alt="HEIG-VD logo" height="80">
</p>

$md$;
COMMENT ON Table "Heartbeat" is $md$
Heartbeat of running digital twin algorithms.
$md$;
COMMENT ON COLUMN "Heartbeat".start_date IS $md$
Start date of running digital twin algorithms.
$md$;
COMMENT ON COLUMN "Heartbeat".freq IS $md$
Frequency of running digital twin algorithms (Unit: `minutes`).
$md$;
COMMENT ON COLUMN "Heartbeat".diff IS $md$
To determine if this row is added (`+`), modified (`!`), or removed (`-`).
$md$;
COMMENT ON TABLE "Bess" IS $md$
Battery energy storage systems (BESSs) components.
$md$;
COMMENT ON COLUMN "Bess".uuid IS $md$
The uuid of the battery energy storage system determined by this row.
$md$;
COMMENT ON COLUMN "Bess".charging_eff IS $md$
Charging efficiency in percentage (Symbol: `Eta_bess_ch`, Unit: `%`).
$md$;
COMMENT ON COLUMN "Bess".discharging_eff IS $md$
Discharging efficiency in percentage (Symbol: `Eta_bess_dch`, Unit: `%`).
$md$;
COMMENT ON COLUMN "Bess".rated_s IS $md$
maximum apparent power of BESS inverter (Symbol: `S_bess_nom`, Unit: `kVA`).
$md$;
COMMENT ON COLUMN "Bess".rated_e IS $md$
Nominal capacity (Symbol: `E_bess_nom`, Unit: `kW`).
$md$;
COMMENT ON COLUMN "Bess".min_charging_p IS $md$
Minimum charging power (Symbol: `P_bess_ch_min`, Unit: `kW`).
$md$;
COMMENT ON COLUMN "Bess".max_charging_p IS $md$
Maximum charging power (Symbol: `P_bess_ch_max`, Unit: `kW`).
$md$;
COMMENT ON COLUMN "Bess".min_discharging_p IS $md$
Minimum discharging power (Symbol: `P_bess_dch_min`, Unit: `kW`).
$md$;
COMMENT ON COLUMN "Bess".max_discharging_p IS $md$
Maximum discharging power (Symbol: `P_bess_dch_max`, Unit: `kW`).
$md$;
COMMENT ON COLUMN "Bess".geo IS $md$
Latitude and Longitude of the `BESS` location (Unit: `WGS84`).
$md$;
COMMENT ON COLUMN "Bess".name IS $md$
Human readable name of the `BESS` determined by this row.
$md$;
COMMENT ON COLUMN "Bess".phases IS $md$
Represents the normal network phasing condition of `BESS`. `phases` is the type of this column, which is one of the following values: `ABC`, `ABCn`, `An`, `Bn`, `Cn`, `AB`, `BC`, `AC`.
$md$;
COMMENT ON COLUMN "Bess".gm_fk IS $md$
The uuid of the `GroupMapping` that represents the relationship among a number of `BESS` across abstraction.
$md$;
COMMENT ON COLUMN "Bess".diff IS $md$
To determine if this row is added (`+`), modified (`!`), or removed (`-`).
$md$;

COMMENT ON TABLE "Branch" IS $md$
Overhead or underground cables/lines that connects the equipment of a grid in a geographical region.
$md$;
COMMENT ON COLUMN "Branch".uuid IS $md$
The uuid of the `Branch` determined by this row.
$md$;
COMMENT ON COLUMN "Branch".current_limit IS $md$
Nominal current of `Branch` (Symbol: `I_b_nom`,Unit: `A`)
$md$;
COMMENT ON COLUMN "Branch".length IS $md$
Length of `Branch` (Symbol: `L_b`,Unit: `km`)
$md$;
COMMENT ON COLUMN "Branch".is_underground IS $md$
Boolean that determines whether the `Branch` is underground or not; `True` if it is underground and `False` otherwise.

**Remark:** When this columns is null, it means that the `Branch` is a mixture of underground and over overground.
$md$;
COMMENT ON COLUMN "Branch".geo IS $md$
Latitude and Longitude of the `Branch` location (Unit: `WGS84`).
$md$;
COMMENT ON COLUMN "Branch".name IS $md$
Human readable name of the `Branch` determined by this row.
$md$;
COMMENT ON COLUMN "Branch".t1_phases IS $md$
Represents the normal network phasing condition at `t1` side. `phases` is the type of this column, which is one of the following values: `ABC`, `ABCn`, `An`, `Bn`, `Cn`, `AB`, `BC`, `AC`.
$md$;
COMMENT ON COLUMN "Branch".t2_phases IS $md$
Represents the normal network phasing condition at `t2` side. `phases` is the type of this column, which is one of the following values: `ABC`, `ABCn`, `An`, `Bn`, `Cn`, `AB`, `BC`, `AC`.
$md$;
COMMENT ON COLUMN "Branch".gm_fk IS $md$
The uuid of the `GroupMapping` that represents the relationship among a number of `Branch` across abstraction.
$md$;
COMMENT ON COLUMN "Branch".diff IS $md$
To determine if this row is added (`+`), modified (`!`), or removed (`-`).
$md$;
COMMENT ON TABLE "BranchParameterEvent" IS $md$
Parameter events capture all changes in the parameters branches due to aging or new calculation.
$md$;
COMMENT ON COLUMN "BranchParameterEvent".timestamp IS $md$
Time stamp of parameter change event (Symbol: `t`).
$md$;
COMMENT ON COLUMN "BranchParameterEvent".value_source IS $md$
Whether the parameter event is determined after calculation or it is based on nominal values; `eventsource` is the type of this column, which is one of the following: `autoRaw`, `manualRaw`, `digitaltwin`.
$md$;
COMMENT ON COLUMN "BranchParameterEvent".r IS $md$
Positive sequence series resistance of the one unit of length of branch (Symbol: `R_b`, Unit: `Ohms_per_km`).
$md$;
COMMENT ON COLUMN "BranchParameterEvent".r0 IS $md$
Zero sequence series resistance of the entire line (Symbol: `R0_b`, Unit: `Ohms_per_km`).
$md$;
COMMENT ON COLUMN "BranchParameterEvent".x IS $md$
Positive sequence series reactance of the one unit of length of branch (Symbol: `X_b`, Unit: `Ohms_per_km`).
$md$;
COMMENT ON COLUMN "BranchParameterEvent".x0 IS $md$
Zero sequence series reactance of the entire line section (Symbol: `X_b`, Unit: `Ohms_per_km`).
$md$;
COMMENT ON COLUMN "BranchParameterEvent".b IS $md$
Positive sequence shunt (charging) susceptance, uniformly distributed, of the entire line section. This value represents the full charging over the one unit of length of the line. The value can be positive or negative (Symbol: `B_b`, Unit: `Siemens_per_km`).
$md$;
COMMENT ON COLUMN "BranchParameterEvent".b0 IS $md$
Zero sequence shunt (charging) susceptance, uniformly distributed, of the entire line (Symbol: `B0_b`, Unit: `Siemens_per_km`).
$md$;
COMMENT ON COLUMN "BranchParameterEvent".diff IS $md$
To determine if this row is added (`+`), modified (`!`), or removed (`-`).
$md$;
COMMENT ON TABLE "BusbarSection" IS $md$
A conductor, or group of conductors, with negligible impedance, that serve to connect other conducting equipment within a single substation. Voltage measurements are typically obtained from VoltageTransformers that are connected to busbar sections. A bus bar section may have many physical terminals but for analysis is modelled with exactly one logical terminal.
$md$;
COMMENT ON COLUMN "BusbarSection".uuid IS $md$
The uuid of the `BusbarSection` determined by this row.
$md$;
COMMENT ON COLUMN "BusbarSection".voltage_level IS $md$
Value of nominal voltage at busbar section (Symbol: `V_bb_nom`,Unit: `V`).
$md$;
COMMENT ON COLUMN "BusbarSection".voltage_min IS $md$
Minimum acceptable voltage level of a busbar section (Symbol: `V_bb_min`, Unit: `V`).
$md$;
COMMENT ON COLUMN "BusbarSection".voltage_max IS $md$
Maximum acceptable voltage level of a busbar section (Symbol: `V_bb_max`, Unit: `V`).
$md$;
COMMENT ON COLUMN "BusbarSection".geo IS $md$
Latitude and Longitude of the `BusbarSection` location (Unit: `WGS84`).
$md$;
COMMENT ON COLUMN "BusbarSection".name IS $md$
Human readable name of the `BusbarSection` determined by this row.
$md$;
COMMENT ON COLUMN "BusbarSection".phases IS $md$
Represents the normal network phasing condition of `BusbarSection`. `phases` is the type of this column, which is one of the following values: `ABC`, `ABCn`, `An`, `Bn`, `Cn`, `AB`, `BC`, `AC`.
$md$;
COMMENT ON COLUMN "BusbarSection".gm_fk IS $md$
The uuid of the `GroupMapping` that represents the relationship among a number of `BusbarSection` across abstraction.
$md$;
COMMENT ON COLUMN "BusbarSection".diff IS $md$
To determine if this row is added (`+`), modified (`!`), or removed (`-`).
$md$;
COMMENT ON TABLE "EnergyConsumer" IS $md$
Generic user of energy - a point of consumption on the power system model.
$md$;
COMMENT ON COLUMN "EnergyConsumer".uuid IS $md$
The uuid of the `EnergyConsumer` determined by this row.
$md$;
COMMENT ON COLUMN "EnergyConsumer".rated_s IS $md$
Nominal apparent power of `EnergyConsumer` (Symbol: `S_ec_nom`, Unit: `kVA`).
$md$;
COMMENT ON COLUMN "EnergyConsumer".profile_type IS $md$
Profile type of the `EnergyConsumer`; `profiletype` is the type of this column, which is one of the following values: `residential`, `commercial`, `industrial`.
$md$;
COMMENT ON COLUMN "EnergyConsumer".geo IS $md$
Latitude and Longitude of the `EnergyConsumer` location (Unit: `WGS84`).
$md$;
COMMENT ON COLUMN "EnergyConsumer".name IS $md$
Human readable name of the `EnergyConsumer` determined by this row.
$md$;
COMMENT ON COLUMN "EnergyConsumer".phases IS $md$
Represents the normal network phasing condition of `EnergyConsumer`. `phases` is the type of this column, which is one of the following values: `ABC`, `ABCn`, `An`, `Bn`, `Cn`, `AB`, `BC`, `AC`.
$md$;
COMMENT ON COLUMN "EnergyConsumer".gm_fk IS $md$
The uuid of the `GroupMapping` that represents the relationship among a number of `EnergyConsumer` across abstraction.
$md$;
COMMENT ON COLUMN "EnergyConsumer".diff IS $md$
To determine if this row is added (`+`), modified (`!`), or removed (`-`).
$md$;
COMMENT ON TABLE "ExternalNetwork" IS $md$
This class represents external network and it is used for IEC 60909 calculations.
$md$;
COMMENT ON COLUMN "ExternalNetwork".uuid IS $md$
The uuid of the `ExternalNetwork` determined by this row.
$md$;
COMMENT ON COLUMN "ExternalNetwork".r_eq IS $md$
The equivalent resistance of External Network to consider multiple upstream networks (Symbol: `R_ex_eq`, Unit: `Ohms`).
$md$;
COMMENT ON COLUMN "ExternalNetwork".x_eq IS $md$
The equivalent inductance of External Network to consider multiple upstream networks (Symbol: `X_eq_eq`, Unit: `Ohms`).
$md$;
COMMENT ON COLUMN "ExternalNetwork".geo IS $md$
Latitude and Longitude of the `ExternalNetwork` location (Unit: `WGS84`).
$md$;
COMMENT ON COLUMN "ExternalNetwork".name IS $md$
Human readable name of the `ExternalNetwork` determined by this row.
$md$;
COMMENT ON COLUMN "ExternalNetwork".phases IS $md$
Represents the normal network phasing condition of `ExternalNetwork`. `phases` is the type of this column, which is one of the following values: `ABC`, `ABCn`, `An`, `Bn`, `Cn`, `AB`, `BC`, `AC`.
$md$;
COMMENT ON COLUMN "ExternalNetwork".gm_fk IS $md$
The uuid of the `GroupMapping` that represents the relationship among a number of `ExternalNetwork` across abstraction.
$md$;
COMMENT ON COLUMN "ExternalNetwork".diff IS $md$
To determine if this row is added (`+`), modified (`!`), or removed (`-`).
$md$;
COMMENT ON TABLE "Pv" IS $md$
Photovoltaic system.
$md$;
COMMENT ON COLUMN "Pv".uuid IS $md$
The uuid of the `Pv` determined by this row.
$md$;
COMMENT ON COLUMN "Pv".cos_phi_limit IS $md$
Power factor limit of the photovoltaic system (Symbol: `Pf_pv_limit`).
$md$;
COMMENT ON COLUMN "Pv".rated_s IS $md$
Maximum apparent power of PV inverter (Symbol: `S_pv_nom`, Unit: `kVA`).
$md$;
COMMENT ON COLUMN "Pv".geo IS $md$
Latitude and Longitude of the `Pv` location (Unit: `WGS84`).
$md$;
COMMENT ON COLUMN "Pv".name IS $md$
Human readable name of the `Pv` determined by this row.
$md$;
COMMENT ON COLUMN "Pv".phases IS $md$
Represents the normal network phasing condition of `Pv`. `phases` is the type of this column, which is one of the following values: `ABC`, `ABCn`, `An`, `Bn`, `Cn`, `AB`, `BC`, `AC`.
$md$;
COMMENT ON COLUMN "Pv".gm_fk IS $md$
The uuid of the `GroupMapping` that represents the relationship among a number of `Pv` across abstraction.
$md$;
COMMENT ON COLUMN "Pv".diff IS $md$
To determine if this row is added (`+`), modified (`!`), or removed (`-`).
$md$;
COMMENT ON TABLE "Switch" IS $md$
Switches, breakers, or disconnectors. A generic device designed to close, or open, or both, one or more electric circuits. All switches are two terminal devices including grounding switches.
$md$;
COMMENT ON COLUMN "Switch".uuid IS $md$
The uuid of the switch determined by this row.
$md$;
COMMENT ON COLUMN "Switch".normal_open IS $md$
Normal state of the switch (Symbol: `u0_s`); `False`: close, `True`: open.
$md$;
COMMENT ON COLUMN "Switch".controllable IS $md$
Type of switch. `controllable` is the type of this column, which is one of the following values: `manualOffLoad`, `manualOnLoad`, `autoOffLoad`, `autoOnLoad`, `no`.
<strong>Remark:</strong> Switch is `manualOffLoad`, Breaker is `autoOnLoad` or `manualOnLoad`, Sectionalizer is `autoOffLoad` or `manualOffLoad`, Fuse is `no`.
$md$;
COMMENT ON COLUMN "Switch".geo IS $md$
Latitude and Longitude of the `Switch` location (Unit: `WGS84`).
$md$;
COMMENT ON COLUMN "Switch".name IS $md$
Human readable name of the `Switch` determined by this row.
$md$;
COMMENT ON COLUMN "Switch".t1_phases IS $md$
Represents the normal network phasing condition at `t1` side. `phases` is the type of this column, which is one of the following values: `ABC`, `ABCn`, `An`, `Bn`, `Cn`, `AB`, `BC`, `AC`.
$md$;
COMMENT ON COLUMN "Switch".t2_phases IS $md$
Represents the normal network phasing condition at `t2` side. `phases` is the type of this column, which is one of the following values: `ABC`, `ABCn`, `An`, `Bn`, `Cn`, `AB`, `BC`, `AC`.
$md$;
COMMENT ON COLUMN "Switch".gm_fk IS $md$
The uuid of the `GroupMapping` that represents the relationship among a number of `Switch` across abstraction.
$md$;
COMMENT ON COLUMN "Switch".diff IS $md$
To determine if this row is added (`+`), modified (`!`), or removed (`-`).
$md$;
COMMENT ON TABLE "SwitchEvent" IS $md$
Grid events capture changes in the grid model, i.e., the change in status of switches.
$md$;
COMMENT ON COLUMN "SwitchEvent".eq_fk IS $md$
The uuid of the switch at which the event is recorded.
$md$;
COMMENT ON COLUMN "SwitchEvent".timestamp IS $md$
Time stamp of switch change event (Symbol: `t`).
$md$;
COMMENT ON COLUMN "SwitchEvent".value_source IS $md$
Whether the switch event is determined after estimation or it is logged by scada; `eventsource` is the type of this column, which is one of the following: `autoRaw`, `manualRaw`, `digitaltwin`.
$md$;
COMMENT ON COLUMN "SwitchEvent".open IS $md$
The new status of switches after the change. Only for switches that changed; It is `True` if the status changed to Open and `False` otherwise (Symbol: `u_sw`).
$md$;
COMMENT ON COLUMN "SwitchEvent".diff IS $md$
To determine if this row is added (`+`), modified (`!`), or removed (`-`).
$md$;
COMMENT ON TABLE "SynchronousGenerationUnit" IS $md$
A single or set of synchronous machines for converting mechanical power into alternating-current power. For example, individual machines within a set may be defined for scheduling purposes while a single control signal is derived for the set. In this case there would be a generating unit for each member of the set and an additional generation unit to the set.
$md$;
COMMENT ON COLUMN "SynchronousGenerationUnit".uuid IS $md$
The uuid of the `SynchronousGenerationUnit` determined by this row.
$md$;
COMMENT ON COLUMN "SynchronousGenerationUnit".rated_s IS $md$
Maximum apparent power of the generation unit (Symbol: `S_dg_nom`, Unit: `kVA`).
$md$;
COMMENT ON COLUMN "SynchronousGenerationUnit".min_operating_p IS $md$
Minimum active power of generating unit (Symbol: `P_dg_min`, Unit: `kW`).
$md$;
COMMENT ON COLUMN "SynchronousGenerationUnit".max_operating_p IS $md$
Maximum active power of generating unit (Symbol: `P_dg_max`, Unit: `kW`).
$md$;
COMMENT ON COLUMN "SynchronousGenerationUnit".geo IS $md$
Latitude and Longitude of the `SynchronousGenerationUnit` location (Unit: `WGS84`).
$md$;
COMMENT ON COLUMN "SynchronousGenerationUnit".name IS $md$
Human readable name of the `SynchronousGenerationUnit` determined by this row.
$md$;
COMMENT ON COLUMN "SynchronousGenerationUnit".phases IS $md$
Represents the normal network phasing condition of `SynchronousGenerationUnit`. `phases` is the type of this column, which is one of the following values: `ABC`, `ABCn`, `An`, `Bn`, `Cn`, `AB`, `BC`, `AC`.
$md$;
COMMENT ON COLUMN "SynchronousGenerationUnit".gm_fk IS $md$
The uuid of the `GroupMapping` that represents the relationship among a number of `SynchronousGenerationUnit` across abstraction.
$md$;
COMMENT ON COLUMN "SynchronousGenerationUnit".diff IS $md$
To determine if this row is added (`+`), modified (`!`), or removed (`-`).
$md$;
COMMENT ON TABLE "Transformer" IS $md$
An electrical device consisting of two windings, with or without a magnetic core, for introducing mutual coupling between electric circuits. Transformers can be used to control voltage and phase shift (active power flow). A power transformer may be composed of separate transformer tanks that need not be identical. A power transformer can be modeled with or without tanks and is intended for use in both balanced and unbalanced representations. A power transformer typically has two terminals, but may have one (grounding), three or more terminals.
<strong>Remark:</strong> The higher voltage terminal of a transformer is on side `t1`.
$md$;
COMMENT ON COLUMN "Transformer".uuid IS $md$
The uuid of the `Transformer` determined by this row.
$md$;
COMMENT ON COLUMN "Transformer".vector_group IS $md$
Kind of connection. `vectorgroup` is the of this column, which is one of the following values: `Dy1`, `Dy5`, `Dy11`, `Yy0`, `Yz1`, `Yz5`, `Yz11`, `Ynd1`.
$md$;
COMMENT ON COLUMN "Transformer".rated_s IS $md$
Normal apparent power rating. The attribute shall be a positive value. For a two-winding transformer the values for the high and low voltage sides shall be identical (Symbol: `S_trf_nom`, Unit: `kVA`).
$md$;
COMMENT ON COLUMN "Transformer".taps_t1 IS $md$
Possible tap values for the tap `t1` of the transformer.
$md$;
COMMENT ON COLUMN "Transformer".taps_t2 IS $md$
Possible tap values for the tap `t2` of the transformer.
$md$;
COMMENT ON COLUMN "Transformer".geo IS $md$
Latitude and Longitude of the `Transformer` location (Unit: `WGS84`).
$md$;
COMMENT ON COLUMN "Transformer".name IS $md$
Human readable name of the `Transformer` determined by this row.
$md$;
COMMENT ON COLUMN "Transformer".t1_phases IS $md$
Represents the normal network phasing condition at `t1` side. `phases` is the type of this column, which is one of the following values: `ABC`, `ABCn`, `An`, `Bn`, `Cn`, `AB`, `BC`, `AC`.
$md$;
COMMENT ON COLUMN "Transformer".t2_phases IS $md$
Represents the normal network phasing condition at `t2` side. `phases` is the type of this column, which is one of the following values: `ABC`, `ABCn`, `An`, `Bn`, `Cn`, `AB`, `BC`, `AC`.
$md$;
COMMENT ON COLUMN "Transformer".gm_fk IS $md$
The uuid of the `GroupMapping` that represents the relationship among a number of `Transformer` across abstraction.
$md$;
COMMENT ON COLUMN "Transformer".diff IS $md$
To determine if this row is added (`+`), modified (`!`), or removed (`-`).
$md$;
COMMENT ON TABLE "TransformerParameterEvent" IS $md$
Parameter events capture all changes in the parameters transformers due to aging or new calculation.
$md$;
COMMENT ON COLUMN "TransformerParameterEvent".timestamp IS $md$
Time stamp of parameter change event (Symbol: `t`).
$md$;
COMMENT ON COLUMN "TransformerParameterEvent".value_source IS $md$
Whether the parameter event is determined after calculation or it is based on nominal values; `eventsource` is the type of this column, which is one of the following: `autoRaw`, `manualRaw`, `digitaltwin`.
$md$;
COMMENT ON COLUMN "TransformerParameterEvent".b IS $md$
Magnetizing branch susceptance (B mag) at fundamental frequency at the lower voltage side. The value can be positive or negative (Symbol: `B_trf`, Unit: `Siemens`).
$md$;
COMMENT ON COLUMN "TransformerParameterEvent".b0 IS $md$
Zero sequence magnetizing branch susceptance at the lower voltage side (Symbol: `B0_trf`, Unit: `Siemens`).
$md$;
COMMENT ON COLUMN "TransformerParameterEvent".g IS $md$
Magnetizing branch conductance at the lower voltage side of transformer (Symbol: `G_trf`, Unit: `Siemens`).
$md$;
COMMENT ON COLUMN "TransformerParameterEvent".g0 IS $md$
Zero sequence magnetizing branch conductance (star-model) at the lower voltage side (Symbol: `G0_trf`, Unit: `Siemens`).
$md$;
COMMENT ON COLUMN "TransformerParameterEvent".r IS $md$
Resistance (star-model) of the transformer at the lower voltage side. The attribute shall be equal or greater than zero for non-equivalent transformers (Symbol: `R_trf`, Unit: `Ohms`).
$md$;
COMMENT ON COLUMN "TransformerParameterEvent".r0 IS $md$
Zero sequence series resistance (star-model) at the lower voltage side (Symbol: `R0_trf`, Unit: `Ohms`).
$md$;
COMMENT ON COLUMN "TransformerParameterEvent".x IS $md$
Positive sequence series reactance (star-model) at fundamental frequency at the lower voltage side (Symbol: `X_trf`, Unit: `Ohms`).
$md$;
COMMENT ON COLUMN "TransformerParameterEvent".x0 IS $md$
Zero sequence series reactance at the lower voltage side (Symbol: `X0_trf`, Unit: `Ohms`).
$md$;
COMMENT ON COLUMN "TransformerParameterEvent".diff IS $md$
To determine if this row is added (`+`), modified (`!`), or removed (`-`).
$md$;
COMMENT ON TABLE "TapEvent" IS $md$
Grid events capture changes in the grid model, i.e., the change in status of tap of transformers.
$md$;
COMMENT ON COLUMN "TapEvent".timestamp IS $md$
Time stamp of Tap changer Events (Symbol: `t`).
$md$;
COMMENT ON COLUMN "TapEvent".value_source IS $md$
Whether the tap event is determined after estimation or it is logged by scada; `eventsource` is the type of this column, which is one of the following: `autoRaw`, `manualRaw`, `digitaltwin`.
$md$;
COMMENT ON COLUMN "TapEvent".eq_fk IS $md$
The uuid of the transformer at which the event is recorded; Note that this value is redundant to facilitate the access to uuid of the transformer.
$md$;
COMMENT ON COLUMN "TapEvent".value IS $md$
The value of the tap event; Note that this value is redundant to facilitate the access to the new value of the tap event (Unit: `V`).
$md$;
COMMENT ON COLUMN "TapEvent".is_tap_t1 IS $md$
Boolean determining the tap side in the transformer; `True`: it is `t1` side equivalent ot higher voltage side and `False`: it is `t2` or lower voltage side; Note that this value is redundant to facilitate the access to the side of transformer.
$md$;
COMMENT ON COLUMN "TapEvent".diff IS $md$
To determine if this row is added (`+`), modified (`!`), or removed (`-`).
$md$;
COMMENT ON TABLE "Abstraction" IS $md$
It contains the abstraction layer and inheritance.
In following figures, we present two examples. The first one is where a number of series `Branch` and `BusbarSection` aggregated to one `Branch`. The second one is where a zero length `Branch` is removed and two `BusbarSection` at both ends will be aggregated to one `BusbarSection`.

<p align="center">
<img src="/assets/schema/abstraction_terminalMapping.svg" alt="Figure with an example of a terminal mapping" width="500" />
</p>
<p align="center" style="font-size:90%"><i>
First example of abstraction.
</i></p>
---
<p align="center">
<img src="/assets/schema/abstraction_cnMapping.svg" alt="Figure with an example of a connectivity node mapping" width="500" />
</p>
<p align="center" style="font-size:90%"><i>
Second example of abstraction.
</i></p>
---
<strong>Remark:</strong> The object `Abstraction` is defined to individuate among `Equipment`, `Terminal`, `ConnectivityNode`, and `TopologicalNode` in the `physical` and `abstract` models. Note that it is possible one `Equipment` or `Terminal` is in both layers.
$md$;
COMMENT ON COLUMN "Abstraction".uuid IS $md$
The uuid of the abstraction determined by this row.
$md$;
COMMENT ON COLUMN "Abstraction".name IS $md$
Human readable name of the abstraction determined by this row.
$md$;
COMMENT ON COLUMN "Abstraction".parent_fk IS $md$
The uuid of the parent abstraction. It indicates that the abstraction determined by this row inherits by default the equipment and connectivity of its parent abstraction.

<strong>Remark:</strong> When this columns is null, the abstraction layer is a base `physical` layer.
$md$;
COMMENT ON COLUMN "Abstraction".diff IS $md$
To determine if this row is added (`+`), modified (`!`), or removed (`-`).
$md$;
COMMENT ON TABLE "GroupMapping" IS $md$

It contains the group mapping that allow mapping of `Equipment`, `Terminal` and `ConnectivityNode` across abstraction.
It is also used to indicate the abstraction layer that the equipment has been created. Therefore, all the `Equipment`, `Terminal` and `ConnectivityNode` in the root abstraction layers have a single group.
In following figures, we present two examples. The first one is where a number of series `Branch` and `BusbarSection` aggregated to one `Branch`. The second one is where a zero length `Branch` is removed and two `BusbarSection` at both ends will be aggregated to one `BusbarSection`.

<p align="center">
<img src="/assets/schema/abstraction_terminalMapping.svg" alt="Figure with an example of a terminal mapping" width="500" />
</p>
<p align="center" style="font-size:90%"><i>
First example of GroupMapping.
</i></p>
---
<p align="center">
<img src="/assets/schema/abstraction_cnMapping.svg" alt="Figure with an example of a connectivity node mapping" width="500" />
</p>
<p align="center" style="font-size:90%"><i>
Second example of GroupMapping.
</i></p>
---
<strong>Remark:</strong>  The object `GroupMapping` is added to keep the dependency among abstract and physical `Equipment`, `Terminal`, and `ConnectivityNode`. With this table, we can easily derive that each abstract `Equipment` is resulted from which physical one.

$md$;
COMMENT ON COLUMN "GroupMapping".uuid IS $md$
The uuid of the group.
Has the same uuid as the abstraction when it's a root abstraction.
Otherwise, the uuid is derived from the target `Equipment`, `Terminal` or `ConnectivityNode`.
$md$;
COMMENT ON COLUMN "GroupMapping".abstraction_fk IS $md$
The uuid of the abstraction layer that `Equipment`, `Terminal` or `ConnectivityNode` has been created.
$md$;
COMMENT ON COLUMN "GroupMapping".diff IS $md$
To determine if this row is added (`+`), modified (`!`), or removed (`-`).
$md$;
COMMENT ON TABLE "EquipmentGroupMapping" IS $md$
Contains the group mapping that allow mapping of `Equipment` across abstraction.

<strong>Remark:</strong> Contrary to the main schema, this table contains only the source equipment of a group mapping. The sink equipments are found using the `gm_fk` column of the equipment tables.
$md$;
COMMENT ON COLUMN "EquipmentGroupMapping".eq_fk IS $md$
The uuid of the `Equipment` that is in this group mapping.
$md$;
COMMENT ON COLUMN "EquipmentGroupMapping".gm_fk IS $md$
The uuid of the `GroupMapping` that represents the relationship among a number of `Equipment` across abstraction.
$md$;
COMMENT ON COLUMN "EquipmentGroupMapping".diff IS $md$
To determine if this row is added (`+`), modified (`!`), or removed (`-`).
$md$;
COMMENT ON TABLE "TerminalMapping" IS $md$
Contains the group mapping that allow mapping of `Terminal` across abstraction.
$md$;
COMMENT ON COLUMN "TerminalMapping".gm_fk IS $md$
The uuid of the `GroupMapping` that represents the relationship among a number of `Terminal` across abstraction.
$md$;
COMMENT ON COLUMN "TerminalMapping".source_eq_fk IS $md$
The uuid of the `Equipment` that its terminal is source of this group mapping.
$md$;
COMMENT ON COLUMN "TerminalMapping".source_side IS $md$
Side of the terminal that is source of this group mapping. Either `t1`, `t2`, or `t`.
$md$;
COMMENT ON COLUMN "TerminalMapping".sink_eq_fk IS $md$
The uuid of the `Equipment` that its terminal is sink of this group mapping.
$md$;
COMMENT ON COLUMN "TerminalMapping".sink_side IS $md$
Side of the terminal that is sink of this group mapping. Either `t1`, `t2`, or `t`.
$md$;
COMMENT ON COLUMN "TerminalMapping".diff IS $md$
To determine if this row is added (`+`), modified (`!`), or removed (`-`).
$md$;
COMMENT ON TABLE "CnMapping" IS $md$
Contains the group mapping that allow mapping of `ConnectivityNode` across abstraction.
$md$;
COMMENT ON COLUMN "CnMapping".gm_fk IS $md$
The uuid of the `GroupMapping` which represents the relationship among a number of `ConnectivityNode` across abstraction.
$md$;
COMMENT ON COLUMN "CnMapping".source_cn_fk IS $md$
The uuid of the `ConnectivityNode` that is source of this group mapping.
$md$;
COMMENT ON COLUMN "CnMapping".sink_cn_fk IS $md$
The uuid of the `ConnectivityNode` that is sink of this group mapping.
$md$;
COMMENT ON COLUMN "CnMapping".diff IS $md$
To determine if this row is added (`+`), modified (`!`), or removed (`-`).
$md$;
COMMENT ON TABLE "Connectivity" IS $md$
Record of connection information of `Terminal` and `ConnectivityNode` across all abstraction.
$md$;
COMMENT ON COLUMN "Connectivity".eq_fk IS $md$
The uuid of the `Equipment` that its terminal is connected in this row.
$md$;
COMMENT ON COLUMN "Connectivity".side IS $md$
Side of the `Equipment` (`Terminal`) that is connected in this row. Either `t1`, `t2`, or `t`.
$md$;
COMMENT ON COLUMN "Connectivity".concrete_type IS $md$
It is used to determine the concrete equipment that is connected in this row; `equipmenttype` is the type of the equipment, which is one of the following values: `bess`, `branch`, `busbarSection`, `energyConsumer`, `externalNetwork`, `pv`, `switch`, `transformer`, `synchronousGenerationUnit`, `measurementDevice`.$md$;
COMMENT ON COLUMN "Connectivity".abstraction_fk IS $md$
The uuid of the abstraction layer that `Equipment` that its terminal is connected in this row.
$md$;
COMMENT ON COLUMN "Connectivity".cn_fk IS $md$
The uuid of the `ConnectivityNode` that the `Terminal` is connected to.
$md$;
COMMENT ON COLUMN "Connectivity".diff IS $md$
To determine if this row is added (`+`), modified (`!`), or removed (`-`).
$md$;
COMMENT ON TABLE "Topology" IS $md$
Record of topological connection information of `Terminal` and `TopologyNode` across all abstraction.
$md$;
COMMENT ON COLUMN "Topology".cn_fk IS $md$
The uuid of the `ConnectivityNode` that is connected to a topological connection this row.
$md$;
COMMENT ON COLUMN "Topology".tn_fk IS $md$
The uuid of the `TopologyNode` that the `ConnectivityNode` is connected to.
$md$;
COMMENT ON COLUMN "Topology".diff IS $md$
To determine if this row is added (`+`), modified (`!`), or removed (`-`).
$md$;
COMMENT ON TABLE "ConnectedGroup" IS $md$
Area divided off from other areas and not connected to other groups. It may be part of the electrical network.
$md$;
COMMENT ON COLUMN "ConnectedGroup".uuid IS $md$
The uuid of the `ConnectedGroup` determined by this row.
$md$;
COMMENT ON COLUMN "ConnectedGroup".name IS $md$
Human readable name of the associated group determined by this row.
$md$;
COMMENT ON COLUMN "ConnectedGroup".is_disconnected IS $md$
If the associated group is disconnected from the main grid then `is_disconnected` is `False` otherwise `True`.
$md$;
COMMENT ON COLUMN "ConnectedGroup".diff IS $md$
To determine if this row is added (`+`), modified (`!`), or removed (`-`).
$md$;
COMMENT ON TABLE "EquipmentConnectedGroup" IS $md$
Relation of `Equipment` and `ConnectedGroup` over time.
$md$;
COMMENT ON COLUMN "EquipmentConnectedGroup".connected_group_fk IS $md$
The uuid of `ConnectedGroup` that the `Equipment` is connected to.
$md$;
COMMENT ON COLUMN "EquipmentConnectedGroup".eq_fk IS $md$
The uuid of the `Equipment`.
$md$;
COMMENT ON COLUMN "EquipmentConnectedGroup".diff IS $md$
To determine if this row is added (`+`), modified (`!`), or removed (`-`).
$md$;
COMMENT ON TABLE "MeasurementSource" IS $md$
Table of all measurement sources.
$md$;
COMMENT ON COLUMN "MeasurementSource".uuid IS $md$
The uuid of the `MeasurementSource`.
$md$;
COMMENT ON COLUMN "MeasurementSource".name IS $md$
Human readable name of the `MeasurementSource`.
$md$;
COMMENT ON COLUMN "MeasurementSource".metadata IS $md$
It is used to store details about the `MeasurementSource`, specially useful if it is ML model or forecasting.
$md$;
COMMENT ON COLUMN "MeasurementSource".diff IS $md$
To determine if this row is added (`+`), modified (`!`), or removed (`-`).
$md$;
COMMENT ON TABLE "MeasurementDevice" IS $md$
Table of all measurement devices that are exist in the network, either physical or abstract ones.
$md$;
COMMENT ON COLUMN "MeasurementDevice".uuid IS $md$
The uuid of `MeasurementDevice`.
$md$;
COMMENT ON COLUMN "MeasurementDevice".accuracy_active_power IS $md$
The limit, expressed as a percentage of the sensor maximum, that accuracy would not less than when the sensor is used under reference conditions (Unit: `%`).
$md$;
COMMENT ON COLUMN "MeasurementDevice".accuracy_current IS $md$
The limit, expressed as a percentage of the sensor maximum, that accuracy would not less than when the sensor is used under reference conditions (Unit: `%`).
$md$;
COMMENT ON COLUMN "MeasurementDevice".accuracy_reactive_power IS $md$
The limit, expressed as a percentage of the sensor maximum, that accuracy would not less than when the sensor is used under reference conditions (Unit: `%`).
$md$;
COMMENT ON COLUMN "MeasurementDevice".accuracy_voltage IS $md$
The limit, expressed as a percentage of the sensor maximum, that accuracy would not less than when the sensor is used under reference conditions (Unit: `%`).
$md$;
COMMENT ON COLUMN "MeasurementDevice".aggregation_period IS $md$
Aggregation period of `MeasurementDevice`, e.g., 600 seconds or 60 seconds (Unit: `seconds`).
$md$;
COMMENT ON COLUMN "MeasurementDevice".rated_current IS $md$
Maximum current that measurement device can measure and the accuracies of current, active power, and reactive power are based on that (Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementDevice".value_source_fk IS $md$
The uuid of measurement source that this `MeasurementDevice` is associated with.
$md$;
COMMENT ON COLUMN "MeasurementDevice".geo IS $md$
Latitude and Longitude of the `MeasurementDevice` location (Unit: `WGS84`).
$md$;
COMMENT ON COLUMN "MeasurementDevice".name IS $md$
Human readable name of the `MeasurementDevice` determined by this row.
$md$;
COMMENT ON COLUMN "MeasurementDevice".gm_fk IS $md$
The uuid of the `GroupMapping` that represents the relationship among a number of `MeasurementDevice` across abstraction.
$md$;
COMMENT ON COLUMN "MeasurementDevice".diff IS $md$
To determine if this row is added (`+`), modified (`!`), or removed (`-`).
$md$;
COMMENT ON TABLE "MeasurementTerminal" IS $md$
`MeasurementTerminal` class is defined for two reasons: (i) to consider the case of a `MeasurementDevice` measuring multiple terminals; and (ii) to easily distinguish between measured and non-measurement Terminals (because most of terminals are not measured).
$md$;
COMMENT ON COLUMN "MeasurementTerminal".uuid IS $md$
The uuid of the `MeasurementTerminal`.
$md$;
COMMENT ON COLUMN "MeasurementTerminal".measurement_device_fk IS $md$
The uuid of `MeasurementDevice` that is associated with this measurement.
$md$;
COMMENT ON COLUMN "MeasurementTerminal".eq_fk IS $md$
The uuid of the `Equipment` that its terminal is measured.
$md$;
COMMENT ON COLUMN "MeasurementTerminal".side IS $md$
Side of the `Equipment` (`Terminal`) that is measured by the `MeasurementDevice`.
$md$;
COMMENT ON COLUMN "MeasurementTerminal".diff IS $md$
To determine if this row is added (`+`), modified (`!`), or removed (`-`).
$md$;
COMMENT ON TABLE "MeasurementEvent" IS $md$
The object of events associated to a `MeasurementDevice`.
$md$;
COMMENT ON COLUMN "MeasurementEvent".timestamp IS $md$
Time stamp for the event (Symbol: `t`).
$md$;
COMMENT ON COLUMN "MeasurementEvent".value IS $md$
Value of concerned parameter during the event (Unit: either `V`, `A`, `kW`, or `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementEvent".type IS $md$
Type of event; eventtype is the type of this column, which is one of the following values: `noVoltage`, `underVoltage`, `overVoltage`, `overCurrent`.
$md$;
COMMENT ON COLUMN "MeasurementEvent".measurement_terminal_fk IS $md$
The uuid of associated measurement terminal.
$md$;
COMMENT ON COLUMN "MeasurementEvent".phase IS $md$
Phase of event; `phase` is the type of this column, which is one of the following values: `A`, `B`, `C`.
$md$;
COMMENT ON COLUMN "MeasurementEvent".diff IS $md$
To determine if this row is added (`+`), modified (`!`), or removed (`-`).
$md$;
COMMENT ON TABLE "MeasurementValue" IS $md$
The object of time series associated to a measurement device (i.e., Analog values of GridEye measurements, PMUs, forecasted values, smart meters, and etc.).
$md$;
COMMENT ON COLUMN "MeasurementValue".measurement_terminal_fk IS $md$
The uuid of associated measurement terminal.
$md$;
COMMENT ON COLUMN "MeasurementValue".timestamp IS $md$
Time stamp for the measurement value (Symbol: `t`).
$md$;
COMMENT ON COLUMN "MeasurementValue".avg_active_power_a IS $md$
Average magnitude of active power phase A (Symbol: `pA`, Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".avg_active_power_b IS $md$
Average magnitude of active power phase B (Symbol: `pB`, Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".avg_active_power_c IS $md$
Average magnitude of active power phase C (Symbol: `pC`, Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".std_active_power_a IS $md$
Standard deviation magnitude of active power phase A (Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".std_active_power_b IS $md$
Standard deviation magnitude of active power phase B (Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".std_active_power_c IS $md$
Standard deviation magnitude of active power phase C (Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".med_active_power_a IS $md$
Median magnitude of active power phase A (Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".med_active_power_b IS $md$
Median magnitude of active power phase B (Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".med_active_power_c IS $md$
Median magnitude of active power phase C (Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".lq_active_power_a IS $md$
0.05 quantile magnitude of active power phase A (Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".lq_active_power_b IS $md$
0.05 quantile  magnitude of active power phase B (Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".lq_active_power_c IS $md$
0.05 quantile  magnitude of active power phase C (Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".uq_active_power_a IS $md$
0.95 quantile magnitude of active power phase A (Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".uq_active_power_b IS $md$
0.95 quantile magnitude of active power phase B (Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".uq_active_power_c IS $md$
0.95 quantile magnitude of active power phase C (Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".min_active_power_a IS $md$
Minimum magnitude of active power phase A (Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".min_active_power_b IS $md$
Minimum magnitude of active power phase B (Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".min_active_power_c IS $md$
Minimum magnitude of active power phase C (Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".max_active_power_a IS $md$
Maximum magnitude of active power phase A (Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".max_active_power_b IS $md$
Maximum magnitude of active power phase B (Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".max_active_power_c IS $md$
Maximum magnitude of active power phase C (Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".avg_current_a IS $md$
Average magnitude of current phase A (Symbol: `iA`, Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".avg_current_b IS $md$
Average magnitude of current phase B (Symbol: `iB`, Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".avg_current_c IS $md$
Average magnitude of current phase C (Symbol: `iC`, Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".std_current_a IS $md$
Standard deviation magnitude of current phase A (Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".std_current_b IS $md$
Standard deviation magnitude of current phase B (Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".std_current_c IS $md$
Standard deviation magnitude of current phase C (Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".med_current_a IS $md$
Median magnitude of current phase A (Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".med_current_b IS $md$
Median magnitude of current phase B (Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".med_current_c IS $md$
Median magnitude of current phase C (Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".lq_current_a IS $md$
0.05 quantile magnitude of current phase A (Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".lq_current_b IS $md$
0.05 quantile magnitude of current phase B (Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".lq_current_c IS $md$
0.05 quantile magnitude of current phase C (Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".uq_current_a IS $md$
0.95 quantile magnitude of current phase A (Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".uq_current_b IS $md$
0.95 quantile magnitude of current phase B (Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".uq_current_c IS $md$
0.95 quantile magnitude of current phase C (Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".min_current_a IS $md$
Minimum magnitude of current phase A (Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".min_current_b IS $md$
Minimum magnitude of current phase B (Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".min_current_c IS $md$
Minimum magnitude of current phase C (Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".max_current_a IS $md$
Maximum magnitude of current phase A (Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".max_current_b IS $md$
Maximum magnitude of current phase B (Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".max_current_c IS $md$
Maximum magnitude of current phase C (Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".avg_reactive_power_a IS $md$
Average magnitude of reactive power phase A (Symbol: `qA`, Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".avg_reactive_power_b IS $md$
Average magnitude of reactive power phase B (Symbol: `qB`, Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".avg_reactive_power_c IS $md$
Average magnitude of reactive power phase C (Symbol: `qC`, Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".std_reactive_power_a IS $md$
Standard deviation magnitude of reactive power phase A (Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".std_reactive_power_b IS $md$
Standard deviation magnitude of reactive power phase B (Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".std_reactive_power_c IS $md$
Standard deviation magnitude of reactive power phase C (Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".med_reactive_power_a IS $md$
Median magnitude of reactive power phase A (Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".med_reactive_power_b IS $md$
Median magnitude of reactive power phase B (Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".med_reactive_power_c IS $md$
Median magnitude of reactive power phase C (Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".lq_reactive_power_a IS $md$
0.05 quantile magnitude of reactive power phase A (Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".lq_reactive_power_b IS $md$
0.05 quantile magnitude of reactive power phase B (Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".lq_reactive_power_c IS $md$
0.05 quantile magnitude of reactive power phase C (Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".uq_reactive_power_a IS $md$
0.95 quantile magnitude of reactive power phase A (Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".uq_reactive_power_b IS $md$
0.95 quantile magnitude of reactive power phase B (Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".uq_reactive_power_c IS $md$
0.95 quantile magnitude of reactive power phase C (Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".min_reactive_power_a IS $md$
Minimum magnitude of reactive power phase A (Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".min_reactive_power_b IS $md$
Minimum magnitude of reactive power phase B (Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".min_reactive_power_c IS $md$
Minimum magnitude of reactive power phase C (Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".max_reactive_power_a IS $md$
Maximum magnitude of reactive power phase A (Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".max_reactive_power_b IS $md$
Maximum magnitude of reactive power phase B (Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".max_reactive_power_c IS $md$
Maximum magnitude of reactive power phase C (Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".avg_voltage_a IS $md$
Average magnitude of voltage phase A (Symbol: `vA`, Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".avg_voltage_b IS $md$
Average magnitude of voltage phase B (Symbol: `vB`, Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".avg_voltage_c IS $md$
Average magnitude of voltage phase C (Symbol: `vC`, Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".std_voltage_a IS $md$
Standard deviation magnitude of voltage phase A (Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".std_voltage_b IS $md$
Standard deviation magnitude of voltage phase B (Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".std_voltage_c IS $md$
Standard deviation magnitude of voltage phase C (Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".med_voltage_a IS $md$
Median magnitude of voltage phase A (Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".med_voltage_b IS $md$
Median magnitude of voltage phase B (Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".med_voltage_c IS $md$
Median magnitude of voltage phase C (Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".lq_voltage_a IS $md$
0.05 quantile magnitude of voltage phase A (Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".lq_voltage_b IS $md$
0.05 quantile magnitude of voltage phase B (Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".lq_voltage_c IS $md$
0.05 quantile magnitude of voltage phase C (Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".uq_voltage_a IS $md$
0.95 quantile magnitude of voltage phase A (Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".uq_voltage_b IS $md$
0.95 quantile magnitude of voltage phase B (Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".uq_voltage_c IS $md$
0.95 quantile magnitude of voltage phase C (Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".min_voltage_a IS $md$
Minimum magnitude of voltage phase A (Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".min_voltage_b IS $md$
Minimum magnitude of voltage phase B (Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".min_voltage_c IS $md$
Minimum magnitude of voltage phase C (Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".max_voltage_a IS $md$
Maximum magnitude of voltage phase A (Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".max_voltage_b IS $md$
Maximum magnitude of voltage phase B (Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".max_voltage_c IS $md$
Maximum magnitude of voltage phase C (Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".diff IS $md$
To determine if this row is added (`+`), modified (`!`), or removed (`-`).
$md$;
