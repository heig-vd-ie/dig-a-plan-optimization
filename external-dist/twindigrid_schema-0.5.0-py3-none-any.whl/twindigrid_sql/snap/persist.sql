CREATE OR REPLACE PROCEDURE "PersistHeartbeat" (t TIMESTAMP) AS $$
    -- New elements
    INSERT INTO main."Heartbeat" AS p
        SELECT s.start_date, s.freq
        FROM snap."Heartbeat" AS s
        WHERE s.diff = '+';

    -- Updated elements
    -- TODO: when would we want to update an heartbeat?
    UPDATE main."Heartbeat" AS p
        SET start_date = s.start_date, freq = s.freq
        FROM snap."Heartbeat" AS s
        WHERE s.diff = '!'
t            AND s.start_date = p.start_date;

    -- Removed elements
    -- TODO: when would we want to delete an heartbeat?
    DELETE FROM main."Heartbeat" AS p
        USING snap."Heartbeat" AS s
        WHERE s.diff = '-'
            AND s.start_date = p.start_date;
$$ LANGUAGE SQL;

CREATE OR REPLACE PROCEDURE "PersistBess" (t TIMESTAMP) AS $$
    -- New elements
    INSERT INTO main."Equipment" AS p
        SELECT s.uuid
            , 'bess'
            , s.geo
            , s.name
        FROM snap."Bess" AS s
        WHERE s.diff = '+';
    INSERT INTO main."Bess" AS p
        SELECT s.uuid
             , s.charging_eff
             , s.discharging_eff
             , s.rated_s
             , s.rated_e
             , s.min_charging_p
             , s.max_charging_p
             , s.min_discharging_p
             , s.max_discharging_p
        FROM snap."Bess" AS s
        WHERE s.diff = '+';
    INSERT INTO main."Terminal" AS p
        SELECT s.uuid
            , 't'
            , s.phases
        FROM snap."Bess" AS s
        WHERE s.diff = '+';
    INSERT INTO main."EquipmentGroupMapping" AS p
        SELECT s.uuid
            , s.gm_fk
            , true
        FROM snap."Bess" AS s
        WHERE s.diff = '+';

    -- Updated elements
    UPDATE main."Bess" AS p
        SET charging_eff = s.charging_eff
          , discharging_eff = s.discharging_eff
          , rated_s = s.rated_s
          , rated_e = s.rated_e
          , min_charging_p = s.min_charging_p
          , max_charging_p = s.max_charging_p
          , min_discharging_p = s.min_discharging_p
          , max_discharging_p = s.max_discharging_p
        FROM snap."Bess" AS s
        WHERE s.diff = '!'
            AND s.uuid = p.uuid;
    UPDATE main."Equipment" AS p
        SET geo = s.geo
          , name = s.name
        FROM snap."Bess" AS s
        WHERE s.diff = '!'
            AND s.uuid = p.uuid;
    UPDATE main."Terminal" AS p
        SET phases = s.phases
        FROM snap."Bess" AS s
        WHERE s.diff = '!'
            AND s.uuid = p.eq_fk;
    -- TODO: When would we update gm_fk?
    UPDATE main."EquipmentGroupMapping" AS p
        SET gm_fk = s.gm_fk
        FROM snap."Bess" AS s
        WHERE s.diff = '!'
            AND s.uuid = p.eq_fk;

    -- Removed elements
    DELETE FROM main."Bess" AS p
        USING snap."Bess" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.uuid;
    DELETE FROM main."Equipment" AS p
        USING snap."Bess" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.uuid;
    DELETE FROM main."Terminal" AS p
        USING snap."Bess" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.eq_fk;
    -- TODO: Automatized using CASCADE?
    DELETE FROM main."EquipmentGroupMapping" AS p
        USING snap."Bess" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.eq_fk; -- should remove both sink and source
$$ LANGUAGE SQL;

CREATE OR REPLACE PROCEDURE "PersistBranch" (t TIMESTAMP) AS $$
    -- New elements
    INSERT INTO main."Equipment" AS p
        SELECT s.uuid
            , 'branch'
            , s.geo
            , s.name
        FROM snap."Branch" AS s
        WHERE s.diff = '+';
    INSERT INTO main."Branch" AS p
        SELECT s.uuid
             , s.current_limit
             , s.length
             , s.is_underground
        FROM snap."Branch" AS s
        WHERE s.diff = '+';
    INSERT INTO main."Terminal" AS p
        SELECT s.uuid
            , 't1'
            , s.t1_phases
        FROM snap."Branch" AS s
        WHERE s.diff = '+';
    INSERT INTO main."Terminal" AS p
        SELECT s.uuid
            , 't2'
            , s.t2_phases
        FROM snap."Branch" AS s
        WHERE s.diff = '+';
    INSERT INTO main."EquipmentGroupMapping" AS p
        SELECT s.uuid
            , s.gm_fk
            , true
        FROM snap."Branch" AS s
        WHERE s.diff = '+';

    -- Updated elements
    UPDATE main."Branch" AS p
        SET current_limit = s.current_limit
          , length = s.length
          , is_underground = s.is_underground
        FROM snap."Branch" AS s
        WHERE s.diff = '!'
            AND s.uuid = p.uuid;
    UPDATE main."Equipment" AS p
        SET geo = s.geo
          , name = s.name
        FROM snap."Branch" AS s
        WHERE s.diff = '!'
            AND s.uuid = p.uuid;
    UPDATE main."Terminal" AS p
        SET phases = s.t1_phases
        FROM snap."Branch" AS s
        WHERE s.diff = '!' AND p.side = 't1'
            AND s.uuid = p.eq_fk;
    UPDATE main."Terminal" AS p
        SET phases = s.t2_phases
        FROM snap."Branch" AS s
        WHERE s.diff = '!' AND p.side = 't2'
            AND s.uuid = p.eq_fk;
    -- TODO: When would we update gm_fk?
    UPDATE main."EquipmentGroupMapping" AS p
        SET gm_fk = s.gm_fk
        FROM snap."Branch" AS s
        WHERE s.diff = '!'
            AND s.uuid = p.eq_fk;

    -- Removed elements
    DELETE FROM main."Branch" AS p
        USING snap."Branch" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.uuid;
    DELETE FROM main."Equipment" AS p
        USING snap."Branch" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.uuid;
    DELETE FROM main."Terminal" AS p
        USING snap."Branch" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.eq_fk;
    -- TODO: Automatized using CASCADE?
    DELETE FROM main."EquipmentGroupMapping" AS p
        USING snap."Branch" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.eq_fk; -- should remove both sink and source
$$ LANGUAGE SQL;

CREATE OR REPLACE PROCEDURE "PersistBranchParameterEvent" (t TIMESTAMP) AS $$
    -- New elements
    INSERT INTO main."BranchParameterEvent" AS p
        SELECT s.timestamp
             , $1
             , s.eq_fk
             , s.value_source
             , s.r
             , s.r0
             , s.x
             , s.x0
             , s.b
             , s.b0
        FROM snap."BranchParameterEvent" AS s
        WHERE s.diff = '+';

    -- Updated elements
    UPDATE main."BranchParameterEvent" AS p
        SET timestamp = s.timestamp
          , r = s.r
          , r0 = s.r0
          , x = s.x
          , x0 = s.x0
          , b = s.b
          , b0 = s.b0
        FROM snap."BranchParameterEvent" AS s
        WHERE s.diff = '!'
            AND p.record_date = $1
            AND s.value_source = p.value_source -- TODO: use value_source to differentiate?
            AND s.eq_fk = p.eq_fk;

    -- Removed elements
    DELETE FROM main."BranchParameterEvent" AS p
        USING snap."BranchParameterEvent" AS s
        WHERE s.diff = '-'
            AND p.record_date = $1
            AND s.value_source = p.value_source -- TODO: use value_source to differentiate?
            AND s.eq_fk = p.eq_fk;
$$ LANGUAGE SQL;

CREATE OR REPLACE PROCEDURE "PersistBusbarSection" (t TIMESTAMP) AS $$
    -- New elements
    INSERT INTO main."Equipment" AS p
        SELECT s.uuid
            , 'busbarSection'
            , s.geo
            , s.name
        FROM snap."BusbarSection" AS s
        WHERE s.diff = '+';
    INSERT INTO main."BusbarSection" AS p
        SELECT s.uuid
             , s.voltage_level
             , s.voltage_min
             , s.voltage_max
        FROM snap."BusbarSection" AS s
        WHERE s.diff = '+';
    INSERT INTO main."Terminal" AS p
        SELECT s.uuid
            , 't'
            , s.phases
        FROM snap."BusbarSection" AS s
        WHERE s.diff = '+';
    INSERT INTO main."EquipmentGroupMapping" AS p
        SELECT s.uuid
            , s.gm_fk
            , true
        FROM snap."BusbarSection" AS s
        WHERE s.diff = '+';

    -- Updated elements
    UPDATE main."BusbarSection" AS p
        SET voltage_level = s.voltage_level
          , voltage_min = s.voltage_min
          , voltage_max = s.voltage_max
        FROM snap."BusbarSection" AS s
        WHERE s.diff = '!'
            AND s.uuid = p.uuid;
    UPDATE main."Equipment" AS p
        SET geo = s.geo
          , name = s.name
        FROM snap."BusbarSection" AS s
        WHERE s.diff = '!'
            AND s.uuid = p.uuid;
    UPDATE main."Terminal" AS p
        SET phases = s.phases
        FROM snap."BusbarSection" AS s
        WHERE s.diff = '!'
            AND s.uuid = p.eq_fk;
    -- TODO: When would we update gm_fk?
    UPDATE main."EquipmentGroupMapping" AS p
        SET gm_fk = s.gm_fk
        FROM snap."BusbarSection" AS s
        WHERE s.diff = '!'
            AND s.uuid = p.eq_fk;

    -- Removed elements
    DELETE FROM main."BusbarSection" AS p
        USING snap."BusbarSection" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.uuid;
    DELETE FROM main."Equipment" AS p
        USING snap."BusbarSection" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.uuid;
    DELETE FROM main."Terminal" AS p
        USING snap."BusbarSection" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.eq_fk;
    -- TODO: Automatized using CASCADE?
    DELETE FROM main."EquipmentGroupMapping" AS p
        USING snap."BusbarSection" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.eq_fk; -- should remove both sink and source
$$ LANGUAGE SQL;

CREATE OR REPLACE PROCEDURE "PersistEnergyConsumer" (t TIMESTAMP) AS $$
    -- New elements
    INSERT INTO main."Equipment" AS p
        SELECT s.uuid
            , 'energyConsumer'
            , s.geo
            , s.name
        FROM snap."EnergyConsumer" AS s
        WHERE s.diff = '+';
    INSERT INTO main."EnergyConsumer" AS p
        SELECT s.uuid
             , s.rated_s
             , s.profile_type
        FROM snap."EnergyConsumer" AS s
        WHERE s.diff = '+';
    INSERT INTO main."Terminal" AS p
        SELECT s.uuid
            , 't'
            , s.phases
        FROM snap."EnergyConsumer" AS s
        WHERE s.diff = '+';
    INSERT INTO main."EquipmentGroupMapping" AS p
        SELECT s.uuid
            , s.gm_fk
            , true
        FROM snap."EnergyConsumer" AS s
        WHERE s.diff = '+';

    -- Updated elements
    UPDATE main."EnergyConsumer" AS p
        SET rated_s = s.rated_s
          , profile_type = s.profile_type
        FROM snap."EnergyConsumer" AS s
        WHERE s.diff = '!'
            AND s.uuid = p.uuid;
    UPDATE main."Equipment" AS p
        SET geo = s.geo
          , name = s.name
        FROM snap."EnergyConsumer" AS s
        WHERE s.diff = '!'
            AND s.uuid = p.uuid;
    UPDATE main."Terminal" AS p
        SET phases = s.phases
        FROM snap."EnergyConsumer" AS s
        WHERE s.diff = '!'
            AND s.uuid = p.eq_fk;
    -- TODO: When would we update gm_fk?
    UPDATE main."EquipmentGroupMapping" AS p
        SET gm_fk = s.gm_fk
        FROM snap."EnergyConsumer" AS s
        WHERE s.diff = '!'
            AND s.uuid = p.eq_fk;

    -- Removed elements
    DELETE FROM main."EnergyConsumer" AS p
        USING snap."EnergyConsumer" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.uuid;
    DELETE FROM main."Equipment" AS p
        USING snap."EnergyConsumer" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.uuid;
    DELETE FROM main."Terminal" AS p
        USING snap."EnergyConsumer" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.eq_fk;
    -- TODO: Automatized using CASCADE?
    DELETE FROM main."EquipmentGroupMapping" AS p
        USING snap."EnergyConsumer" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.eq_fk; -- should remove both sink and source
$$ LANGUAGE SQL;

CREATE OR REPLACE PROCEDURE "PersistExternalNetwork" (t TIMESTAMP) AS $$
    -- New elements
    INSERT INTO main."Equipment" AS p
        SELECT s.uuid
            , 'externalNetwork'
            , s.geo
            , s.name
        FROM snap."ExternalNetwork" AS s
        WHERE s.diff = '+';
    INSERT INTO main."ExternalNetwork" AS p
        SELECT s.uuid
             , s.r_eq
             , s.x_eq
        FROM snap."ExternalNetwork" AS s
        WHERE s.diff = '+';
    INSERT INTO main."Terminal" AS p
        SELECT s.uuid
            , 't'
            , s.phases
        FROM snap."ExternalNetwork" AS s
        WHERE s.diff = '+';
    INSERT INTO main."EquipmentGroupMapping" AS p
        SELECT s.uuid
            , s.gm_fk
            , true
        FROM snap."ExternalNetwork" AS s
        WHERE s.diff = '+';

    -- Updated elements
    UPDATE main."ExternalNetwork" AS p
        SET r_eq = s.r_eq
          , x_eq = s.x_eq
        FROM snap."ExternalNetwork" AS s
        WHERE s.diff = '!'
            AND s.uuid = p.uuid;
    UPDATE main."Equipment" AS p
        SET geo = s.geo
          , name = s.name
        FROM snap."ExternalNetwork" AS s
        WHERE s.diff = '!'
            AND s.uuid = p.uuid;
    UPDATE main."Terminal" AS p
        SET phases = s.phases
        FROM snap."ExternalNetwork" AS s
        WHERE s.diff = '!'
            AND s.uuid = p.eq_fk;
    -- TODO: When would we update gm_fk?
    UPDATE main."EquipmentGroupMapping" AS p
        SET gm_fk = s.gm_fk
        FROM snap."ExternalNetwork" AS s
        WHERE s.diff = '!'
            AND s.uuid = p.eq_fk;

    -- Removed elements
    DELETE FROM main."EnergyConsumer" AS p
        USING snap."ExternalNetwork" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.uuid;
    DELETE FROM main."Equipment" AS p
        USING snap."ExternalNetwork" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.uuid;
    DELETE FROM main."Terminal" AS p
        USING snap."ExternalNetwork" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.eq_fk;
    -- TODO: Automatized using CASCADE?
    DELETE FROM main."EquipmentGroupMapping" AS p
        USING snap."ExternalNetwork" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.eq_fk; -- should remove both sink and source
$$ LANGUAGE SQL;

CREATE OR REPLACE PROCEDURE "PersistPv" (t TIMESTAMP) AS $$
    -- New elements
    INSERT INTO main."Equipment" AS p
        SELECT s.uuid
            , 'pv'
            , s.geo
            , s.name
        FROM snap."Pv" AS s
        WHERE s.diff = '+';
    INSERT INTO main."Pv" AS p
        SELECT s.uuid
             , s.cos_phi_limit
             , s.rated_s
        FROM snap."Pv" AS s
        WHERE s.diff = '+';
    INSERT INTO main."Terminal" AS p
        SELECT s.uuid
            , 't'
            , s.phases
        FROM snap."Pv" AS s
        WHERE s.diff = '+';
    INSERT INTO main."EquipmentGroupMapping" AS p
        SELECT s.uuid
            , s.gm_fk
            , true
        FROM snap."Pv" AS s
        WHERE s.diff = '+';

    -- Updated elements
    UPDATE main."Pv" AS p
        SET cos_phi_limit = s.cos_phi_limit
          , rated_s = s.rated_s
        FROM snap."Pv" AS s
        WHERE s.diff = '!'
            AND s.uuid = p.uuid;
    UPDATE main."Equipment" AS p
        SET geo = s.geo
          , name = s.name
        FROM snap."Pv" AS s
        WHERE s.diff = '!'
            AND s.uuid = p.uuid;
    UPDATE main."Terminal" AS p
        SET phases = s.phases
        FROM snap."Pv" AS s
        WHERE s.diff = '!'
            AND s.uuid = p.eq_fk;
    -- TODO: When would we update gm_fk?
    UPDATE main."EquipmentGroupMapping" AS p
        SET gm_fk = s.gm_fk
        FROM snap."Pv" AS s
        WHERE s.diff = '!'
            AND s.uuid = p.eq_fk;

    -- Removed elements
    DELETE FROM main."EnergyConsumer" AS p
        USING snap."Pv" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.uuid;
    DELETE FROM main."Equipment" AS p
        USING snap."Pv" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.uuid;
    DELETE FROM main."Terminal" AS p
        USING snap."Pv" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.eq_fk;
    -- TODO: Automatized using CASCADE?
    DELETE FROM main."EquipmentGroupMapping" AS p
        USING snap."Pv" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.eq_fk; -- should remove both sink and source
$$ LANGUAGE SQL;

CREATE OR REPLACE PROCEDURE "PersistSwitch" (t TIMESTAMP) AS $$
    -- New elements
    INSERT INTO main."Equipment" AS p
        SELECT s.uuid
            , 'switch'
            , s.geo
            , s.name
        FROM snap."Switch" AS s
        WHERE s.diff = '+';
    INSERT INTO main."Switch" AS p
        SELECT s.uuid
             , s.normal_open
             , s.controllable
        FROM snap."Switch" AS s
        WHERE s.diff = '+';
    INSERT INTO main."Terminal" AS p
        SELECT s.uuid
            , 't1'
            , s.t1_phases
        FROM snap."Switch" AS s
        WHERE s.diff = '+';
    INSERT INTO main."Terminal" AS p
        SELECT s.uuid
            , 't2'
            , s.t2_phases
        FROM snap."Switch" AS s
        WHERE s.diff = '+';
    INSERT INTO main."EquipmentGroupMapping" AS p
        SELECT s.uuid
            , s.gm_fk
            , true
        FROM snap."Switch" AS s
        WHERE s.diff = '+';

    -- Updated elements
    UPDATE main."Switch" AS p
        SET normal_open = s.normal_open
          , controllable = s.controllable
        FROM snap."Switch" AS s
        WHERE s.diff = '!'
            AND s.uuid = p.uuid;
    UPDATE main."Equipment" AS p
        SET geo = s.geo
          , name = s.name
        FROM snap."Switch" AS s
        WHERE s.diff = '!'
            AND s.uuid = p.uuid;
    UPDATE main."Terminal" AS p
        SET phases = s.t1_phases
        FROM snap."Switch" AS s
        WHERE s.diff = '!' AND p.side = 't1'
            AND s.uuid = p.eq_fk;
    UPDATE main."Terminal" AS p
        SET phases = s.t2_phases
        FROM snap."Switch" AS s
        WHERE s.diff = '!' AND p.side = 't2'
            AND s.uuid = p.eq_fk;
    -- TODO: When would we update gm_fk?
    UPDATE main."EquipmentGroupMapping" AS p
        SET gm_fk = s.gm_fk
        FROM snap."Switch" AS s
        WHERE s.diff = '!'
            AND s.uuid = p.eq_fk;

    -- Removed elements
    DELETE FROM main."Switch" AS p
        USING snap."Switch" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.uuid;
    DELETE FROM main."Equipment" AS p
        USING snap."Switch" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.uuid;
    DELETE FROM main."Terminal" AS p
        USING snap."Switch" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.eq_fk;
    -- TODO: Automatized using CASCADE?
    DELETE FROM main."EquipmentGroupMapping" AS p
        USING snap."Switch" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.eq_fk; -- should remove both sink and source
$$ LANGUAGE SQL;

CREATE OR REPLACE PROCEDURE "PersistSwitchEvent" (t TIMESTAMP) AS $$
    -- New elements
    INSERT INTO main."SwitchEvent" AS p
        SELECT s.timestamp
             , $1
             , s.eq_fk
             , s.value_source
             , s.open
        FROM snap."SwitchEvent" AS s
        WHERE s.diff = '+';

    -- Updated elements
    UPDATE main."SwitchEvent" AS p
        SET timestamp = s.timestamp
          , open = s.open
        FROM snap."SwitchEvent" AS s
        WHERE s.diff = '!'
            AND p.record_date = $1
            AND s.value_source = p.value_source -- TODO: use value_source to differentiate?
            AND s.eq_fk = p.eq_fk;

    -- Removed elements
    DELETE FROM main."SwitchEvent" AS p
        USING snap."SwitchEvent" AS s
        WHERE s.diff = '-'
            AND p.record_date = $1
            AND s.value_source = p.value_source -- TODO: use value_source to differentiate?
            AND s.eq_fk = p.eq_fk;
$$ LANGUAGE SQL;

CREATE OR REPLACE PROCEDURE "PersistSynchronousGenerationUnit" (t TIMESTAMP) AS $$
    -- New elements
    INSERT INTO main."Equipment" AS p
        SELECT s.uuid
            , 'synchronousGenerationUnit'
            , s.geo
            , s.name
        FROM snap."SynchronousGenerationUnit" AS s
        WHERE s.diff = '+';
    INSERT INTO main."SynchronousGenerationUnit" AS p
        SELECT s.uuid
             , s.rated_s
             , s.min_operating_p
             , s.max_operating_p
        FROM snap."SynchronousGenerationUnit" AS s
        WHERE s.diff = '+';
    INSERT INTO main."Terminal" AS p
        SELECT s.uuid
            , 't'
            , s.phases
        FROM snap."SynchronousGenerationUnit" AS s
        WHERE s.diff = '+';
    INSERT INTO main."EquipmentGroupMapping" AS p
        SELECT s.uuid
            , s.gm_fk
            , true
        FROM snap."SynchronousGenerationUnit" AS s
        WHERE s.diff = '+';

    -- Updated elements
    UPDATE main."SynchronousGenerationUnit" AS p
        SET rated_s = s.rated_s
          , min_operating_p = s.min_operating_p
          , max_operating_p = s.max_operating_p
        FROM snap."SynchronousGenerationUnit" AS s
        WHERE s.diff = '!'
            AND s.uuid = p.uuid;
    UPDATE main."Equipment" AS p
        SET geo = s.geo
          , name = s.name
        FROM snap."SynchronousGenerationUnit" AS s
        WHERE s.diff = '!'
            AND s.uuid = p.uuid;
    UPDATE main."Terminal" AS p
        SET phases = s.phases
        FROM snap."SynchronousGenerationUnit" AS s
        WHERE s.diff = '!'
            AND s.uuid = p.eq_fk;
    -- TODO: When would we update gm_fk?
    UPDATE main."EquipmentGroupMapping" AS p
        SET gm_fk = s.gm_fk
        FROM snap."SynchronousGenerationUnit" AS s
        WHERE s.diff = '!'
            AND s.uuid = p.eq_fk;

    -- Removed elements
    DELETE FROM main."EnergyConsumer" AS p
        USING snap."SynchronousGenerationUnit" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.uuid;
    DELETE FROM main."Equipment" AS p
        USING snap."SynchronousGenerationUnit" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.uuid;
    DELETE FROM main."Terminal" AS p
        USING snap."SynchronousGenerationUnit" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.eq_fk;
    -- TODO: Automatized using CASCADE?
    DELETE FROM main."EquipmentGroupMapping" AS p
        USING snap."SynchronousGenerationUnit" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.eq_fk; -- should remove both sink and source
$$ LANGUAGE SQL;

CREATE OR REPLACE PROCEDURE "PersistTransformer" (t TIMESTAMP) AS $$
    -- New elements
    INSERT INTO main."Equipment" AS p
        SELECT s.uuid
            , 'transformer'
            , s.geo
            , s.name
        FROM snap."Transformer" AS s
        WHERE s.diff = '+';
    INSERT INTO main."Transformer" AS p
        SELECT s.uuid
             , s.vector_group
             , s.rated_s
        FROM snap."Transformer" AS s
        WHERE s.diff = '+';
    INSERT INTO main."Tap" AS p
        SELECT uuid_generate_v4()
             , s.uuid
             , tap.v
             , true
        FROM snap."Transformer" AS s
        CROSS JOIN LATERAL UNNEST(s.taps_t1) AS tap(v)
        WHERE s.diff = '+';
    INSERT INTO main."Tap" AS p
        SELECT uuid_generate_v4()
             , s.uuid
             , tap.v
             , false
        FROM snap."Transformer" AS s
        CROSS JOIN LATERAL UNNEST(s.taps_t2) AS tap(v)
        WHERE s.diff = '+';
    INSERT INTO main."Terminal" AS p
        SELECT s.uuid
            , 't1'
            , s.t1_phases
        FROM snap."Transformer" AS s
        WHERE s.diff = '+';
    INSERT INTO main."Terminal" AS p
        SELECT s.uuid
            , 't2'
            , s.t2_phases
        FROM snap."Transformer" AS s
        WHERE s.diff = '+';
    INSERT INTO main."EquipmentGroupMapping" AS p
        SELECT s.uuid
            , s.gm_fk
            , true
        FROM snap."Transformer" AS s
        WHERE s.diff = '+';

    -- Updated elements
    UPDATE main."Transformer" AS p
        SET vector_group = s.vector_group
          , rated_s = s.rated_s
        FROM snap."Transformer" AS s
        WHERE s.diff = '!'
            AND s.uuid = p.uuid;
    -- remove old tap
    DELETE FROM main."Tap" AS p
        USING snap."Transformer" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.eq_fk
            AND p.is_tap_t1 = true
            AND p.value <> ANY (s.taps_t1);
    DELETE FROM main."Tap" AS p
        USING snap."Transformer" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.eq_fk
            AND p.is_tap_t1 = false
            AND p.value <> ANY (s.taps_t2);
    -- add new tap
    INSERT INTO main."Tap" AS p
        SELECT uuid_generate_v4()
             , s.uuid
             , tap.v
             , true
        FROM snap."Transformer" AS s
        CROSS JOIN LATERAL UNNEST(s.taps_t1) AS tap(v)
        LEFT JOIN main."Tap" AS t ON t.eq_fk = s.uuid AND t.is_tap_t1 = true AND t.value = tap.v
        WHERE t.uuid IS NULL
            AND s.diff = '+';
    INSERT INTO main."Tap" AS p
        SELECT uuid_generate_v4()
             , s.uuid
             , tap.v
             , false
        FROM snap."Transformer" AS s
        CROSS JOIN LATERAL UNNEST(s.taps_t2) AS tap(v)
        LEFT JOIN main."Tap" AS t ON t.eq_fk = s.uuid AND t.is_tap_t1 = false AND t.value = tap.v
        WHERE t.uuid IS NULL
            AND s.diff = '+';
    UPDATE main."Equipment" AS p
        SET geo = s.geo
          , name = s.name
        FROM snap."Transformer" AS s
        WHERE s.diff = '!'
            AND s.uuid = p.uuid;
    UPDATE main."Terminal" AS p
        SET phases = s.t1_phases
        FROM snap."Transformer" AS s
        WHERE s.diff = '!' AND p.side = 't1'
            AND s.uuid = p.eq_fk;
    UPDATE main."Terminal" AS p
        SET phases = s.t2_phases
        FROM snap."Transformer" AS s
        WHERE s.diff = '!' AND p.side = 't2'
            AND s.uuid = p.eq_fk;
    -- TODO: When would we update gm_fk?
    UPDATE main."EquipmentGroupMapping" AS p
        SET gm_fk = s.gm_fk
        FROM snap."Transformer" AS s
        WHERE s.diff = '!'
            AND s.uuid = p.eq_fk;

    -- Removed elements
    DELETE FROM main."Transformer" AS p
        USING snap."Transformer" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.uuid;
    DELETE FROM main."Tap" AS p
        USING snap."Transformer" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.eq_fk;
    DELETE FROM main."Equipment" AS p
        USING snap."Transformer" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.uuid;
    DELETE FROM main."Terminal" AS p
        USING snap."Transformer" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.eq_fk;
    -- TODO: Automatized using CASCADE?
    DELETE FROM main."EquipmentGroupMapping" AS p
        USING snap."Transformer" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.eq_fk; -- should remove both sink and source
$$ LANGUAGE SQL;

CREATE OR REPLACE PROCEDURE "PersistTransformerParameterEvent" (t TIMESTAMP) AS $$
    -- New elements
    INSERT INTO main."TransformerParameterEvent" AS p
        SELECT s.timestamp
             , $1
             , s.eq_fk
             , s.value_source
             , s.r
             , s.r0
             , s.x
             , s.x0
             , s.b
             , s.b0
             , s.g
             , s.g0
        FROM snap."TransformerParameterEvent" AS s
        WHERE s.diff = '+';

    -- Updated elements
    UPDATE main."TransformerParameterEvent" AS p
        SET timestamp = s.timestamp
          , r = s.r
          , r0 = s.r0
          , x = s.x
          , x0 = s.x0
          , b = s.b
          , b0 = s.b0
          , g = s.g
          , g0 = s.g0
        FROM snap."TransformerParameterEvent" AS s
        WHERE s.diff = '!'
            AND p.record_date = $1
            AND s.value_source = p.value_source -- TODO: use value_source to differentiate?
            AND s.eq_fk = p.eq_fk;

    -- Removed elements
    DELETE FROM main."TransformerParameterEvent" AS p
        USING snap."TransformerParameterEvent" AS s
        WHERE s.diff = '-'
            AND p.record_date = $1
            AND s.value_source = p.value_source -- TODO: use value_source to differentiate?
            AND s.eq_fk = p.eq_fk;
$$ LANGUAGE SQL;

CREATE OR REPLACE PROCEDURE "PersistTapEvent" (t TIMESTAMP) AS $$
    -- New elements
    INSERT INTO main."TapEvent" AS p
        SELECT s.timestamp
             , $1
             , t.uuid -- tap_fk
             , s.value_source
             , s.eq_fk
             , s.value
             , s.is_tap_t1
        FROM snap."TapEvent" AS s
        LEFT JOIN main."Tap" t ON t.eq_fk = s.eq_fk AND t.value = s.value AND t.is_tap_t1 = s.is_tap_t1
        WHERE s.diff = '+';

    -- Updated elements
    UPDATE main."TapEvent" AS p
        SET timestamp = s.timestamp
          , tap_fk = t.uuid
          , value = s.value
          , is_tap_t1 = s.is_tap_t1
        FROM snap."TapEvent" AS s
        LEFT JOIN main."Tap" t ON t.eq_fk = s.eq_fk AND t.value = s.value AND t.is_tap_t1 = s.is_tap_t1
        WHERE s.diff = '!'
            AND p.record_date = $1
            AND s.value_source = p.value_source -- TODO: use value_source to differentiate?
            AND s.eq_fk = p.eq_fk;

    -- Removed elements
    DELETE FROM main."TapEvent" AS p
        USING snap."TapEvent" AS s
        WHERE s.diff = '-'
            AND p.record_date = $1
            AND s.value_source = p.value_source -- TODO: use value_source to differentiate?
            AND s.eq_fk = p.eq_fk;
$$ LANGUAGE SQL;

CREATE OR REPLACE PROCEDURE "PersistAbstraction" (t TIMESTAMP) AS $$
    -- New elements
    INSERT INTO main."Abstraction" AS p
        SELECT s.uuid
             , s.name
             , s.parent_fk
        FROM snap."Abstraction" AS s
        WHERE s.diff = '+';

    -- Updated elements
    UPDATE main."Abstraction" AS p
        SET name = s.name
          , parent_fk = s.parent_fk
        FROM snap."Abstraction" AS s
        WHERE s.diff = '!'
            AND s.uuid = p.uuid;

    -- Removed elements
    DELETE FROM main."Abstraction" AS p
        USING snap."Abstraction" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.uuid;
$$ LANGUAGE SQL;

CREATE OR REPLACE PROCEDURE "PersistGroupMapping" (t TIMESTAMP) AS $$
    -- New elements
    INSERT INTO main."GroupMapping" AS p
        SELECT s.uuid
             , s.abstraction_fk
             , t
             , null
        FROM snap."GroupMapping" AS s
        WHERE s.diff = '+';

    -- Updated elements
    UPDATE main."GroupMapping" AS p
        SET abstraction_fk = s.abstraction_fk
        FROM snap."GroupMapping" AS s
        WHERE s.diff = '!'
            AND s.uuid = p.uuid;

    -- Removed elements
    DELETE FROM main."GroupMapping" AS p
        USING snap."GroupMapping" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.uuid;
$$ LANGUAGE SQL;

CREATE OR REPLACE PROCEDURE "PersistCnMapping" (t TIMESTAMP) AS $$
    -- New elements
    INSERT INTO main."CnMapping" AS p
        SELECT s.gm_fk
             , s.source_cn_fk
             , s.sink_cn_fk
        FROM snap."CnMapping" AS s
        WHERE s.diff = '+';

    -- Updated elements
    -- All element are primary key

    -- Removed elements
    DELETE FROM main."CnMapping" AS p
        USING snap."CnMapping" AS s
        WHERE s.diff = '-'
            AND s.gm_fk = p.gm_fk
            AND s.source_cn_fk = p.source_cn_fk
            AND s.sink_cn_fk = p.sink_cn_fk;
$$ LANGUAGE SQL;

CREATE OR REPLACE PROCEDURE "PersistEquipmentGroupMapping" (t TIMESTAMP) AS $$
    -- New elements
    INSERT INTO main."EquipmentGroupMapping" AS p
        SELECT s.eq_fk
             , s.gm_fk
             , false
        FROM snap."EquipmentGroupMapping" AS s
        WHERE s.diff = '+';

    -- Updated elements
    -- All element are primary key

    -- Removed elements
    DELETE FROM main."EquipmentGroupMapping" AS p
        USING snap."EquipmentGroupMapping" AS s
        WHERE s.diff = '-'
            AND s.eq_fk = p.eq_fk
            AND s.gm_fk = p.gm_fk;
$$ LANGUAGE SQL;

CREATE OR REPLACE PROCEDURE "PersistTerminalMapping" (t TIMESTAMP) AS $$
    -- New elements
    INSERT INTO main."TerminalMapping" AS p
        SELECT s.gm_fk
             , s.source_eq_fk
             , s.source_side
             , s.sink_eq_fk
             , s.sink_side
        FROM snap."TerminalMapping" AS s
        WHERE s.diff = '+';

    -- Updated elements
    UPDATE main."TerminalMapping" AS p
        SET gm_fk = s.gm_fk
          , source_eq_fk = s.source_eq_fk
          , source_side = s.source_side
        FROM snap."TerminalMapping" AS s
        WHERE s.diff = '!'
            AND s.sink_eq_fk = p.sink_eq_fk
            AND s.sink_side = p.sink_side;

    -- Removed elements
    DELETE FROM main."TerminalMapping" AS p
        USING snap."TerminalMapping" AS s
        WHERE s.diff = '-'
            AND s.sink_eq_fk = p.sink_eq_fk
            AND s.sink_side = p.sink_side;
$$ LANGUAGE SQL;

CREATE OR REPLACE PROCEDURE "PersistConnectivity" (t TIMESTAMP) AS $$
    -- New elements
    INSERT INTO main."Connectivity" AS p (eq_fk, side, concrete_type, abstraction_fk, cn_fk, install_date, record_install_date, uninstall_date, record_uninstall_date)
        SELECT s.eq_fk
             , s.side
             , s.concrete_type
             , s.abstraction_fk
             , s.cn_fk
             , s.timestamp
             , $1
             , null
             , null
        FROM snap."Connectivity" AS s
        WHERE s.diff = '+';

    -- Updated elements
    -- TODO: doesn't apply here?

    -- Removed elements
    -- Completely remove if same record_date?
    UPDATE main."Connectivity" AS p
        SET uninstall_date = s.timestamp
          , record_uninstall_date = $1
        FROM snap."Connectivity" AS s
        WHERE s.diff = '-'
            AND s.eq_fk = p.eq_fk
            AND s.side = p.side
            AND s.abstraction_fk = p.abstraction_fk;
$$ LANGUAGE SQL;

CREATE OR REPLACE PROCEDURE "PersistTopology" (t TIMESTAMP) AS $$
    -- New elements
    INSERT INTO main."Topology" AS p
        SELECT s.cn_fk
             , s.tn_fk
             , $1
             , null
        FROM snap."Topology" AS s
        WHERE s.diff = '+';

    -- Updated elements
    -- TODO: doesn't apply here?

    -- Removed elements
    -- Completely remove if same record_date?
    UPDATE main."Topology" AS p
        SET record_uninstall_date = $1
        FROM snap."Topology" AS s
        WHERE s.diff = '-'
            AND s.cn_fk = p.cn_fk
            AND s.tn_fk = p.tn_fk;
$$ LANGUAGE SQL;

CREATE OR REPLACE PROCEDURE "PersistMeasurementSource" (t TIMESTAMP) AS $$
    -- New elements
    INSERT INTO main."MeasurementSource" AS p
        SELECT s.uuid
             , s.name
             , s.metadata
        FROM snap."MeasurementSource" AS s
        WHERE s.diff = '+';

    -- Updated elements
    UPDATE main."MeasurementSource" AS p
        SET name = s.name
          , metadata = s.metadata
        FROM snap."MeasurementSource" AS s
        WHERE s.diff = '!'
            AND s.uuid = p.uuid;

    -- Removed elements
    DELETE FROM main."MeasurementSource" AS p
        USING snap."MeasurementSource" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.uuid;
$$ LANGUAGE SQL;

CREATE OR REPLACE PROCEDURE "PersistMeasurementDevice" (t TIMESTAMP) AS $$
    -- New elements
    INSERT INTO main."Equipment" AS p
        SELECT s.uuid
            , 'measurementDevice'
            , s.geo
            , s.name
        FROM snap."MeasurementDevice" AS s
        WHERE s.diff = '+';
    INSERT INTO main."MeasurementDevice" AS p
        SELECT s.uuid
             , s.accuracy_active_power
             , s.accuracy_current
             , s.accuracy_reactive_power
             , s.accuracy_voltage
             , s.rated_current
             , s.aggregation_period
             , s.value_source_fk
        FROM snap."MeasurementDevice" AS s
        WHERE s.diff = '+';
    INSERT INTO main."EquipmentGroupMapping" AS p
        SELECT s.uuid
            , s.gm_fk
            , true
        FROM snap."MeasurementDevice" AS s
        WHERE s.diff = '+';

    -- Updated elements
    UPDATE main."MeasurementDevice" AS p
        SET accuracy_active_power = s.accuracy_active_power
          , accuracy_current = s.accuracy_current
          , accuracy_reactive_power = s.accuracy_reactive_power
          , accuracy_voltage = s.accuracy_voltage
          , rated_current = s.rated_current
          , aggregation_period = s.aggregation_period
          , value_source_fk = s.value_source_fk
        FROM snap."MeasurementDevice" AS s
        WHERE s.diff = '!'
            AND s.uuid = p.uuid;
    UPDATE main."Equipment" AS p
        SET geo = s.geo
          , name = s.name
        FROM snap."MeasurementDevice" AS s
        WHERE s.diff = '!'
            AND s.uuid = p.uuid;
    -- TODO: When would we update gm_fk?
    UPDATE main."EquipmentGroupMapping" AS p
        SET gm_fk = s.gm_fk
        FROM snap."MeasurementDevice" AS s
        WHERE s.diff = '!'
            AND s.uuid = p.eq_fk;

    -- Removed elements
    DELETE FROM main."MeasurementDevice" AS p
        USING snap."MeasurementDevice" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.uuid;
    DELETE FROM main."Equipment" AS p
        USING snap."MeasurementDevice" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.uuid;
    -- TODO: Automatized using CASCADE?
    DELETE FROM main."EquipmentGroupMapping" AS p
        USING snap."MeasurementDevice" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.eq_fk; -- should remove both sink and source
$$ LANGUAGE SQL;

CREATE OR REPLACE PROCEDURE "PersistMeasurementTerminal" (t TIMESTAMP) AS $$
    -- New elements
    INSERT INTO main."MeasurementTerminal" AS p
        SELECT s.uuid
             , s.measurement_device_fk
             , s.eq_fk
             , s.side
        FROM snap."MeasurementTerminal" AS s
        WHERE s.diff = '+';

    -- Updated elements
    UPDATE main."MeasurementTerminal" AS p
        SET measurement_device_fk = s.measurement_device_fk
          , eq_fk = s.eq_fk
          , side = s.side
        FROM snap."MeasurementTerminal" AS s
        WHERE s.diff = '!'
            AND s.uuid = p.uuid;

    -- Removed elements
    DELETE FROM main."MeasurementTerminal" AS p
        USING snap."MeasurementTerminal" AS s
        WHERE s.diff = '-'
            AND s.uuid = p.uuid;
$$ LANGUAGE SQL;

CREATE OR REPLACE PROCEDURE "PersistMeasurementValue" (t TIMESTAMP) AS $$
    -- New elements
    INSERT INTO main."MeasurementValue" AS p
        SELECT s.measurement_terminal_fk
             , s.timestamp
             , $1
             , avg_active_power_a
             , avg_active_power_b
             , avg_active_power_c
             , std_active_power_a
             , std_active_power_b
             , std_active_power_c
             , med_active_power_a
             , med_active_power_b
             , med_active_power_c
             , lq_active_power_a
             , lq_active_power_b
             , lq_active_power_c
             , uq_active_power_a
             , uq_active_power_b
             , uq_active_power_c
             , min_active_power_a
             , min_active_power_b
             , min_active_power_c
             , max_active_power_a
             , max_active_power_b
             , max_active_power_c
             , avg_current_a
             , avg_current_b
             , avg_current_c
             , std_current_a
             , std_current_b
             , std_current_c
             , med_current_a
             , med_current_b
             , med_current_c
             , lq_current_a
             , lq_current_b
             , lq_current_c
             , uq_current_a
             , uq_current_b
             , uq_current_c
             , min_current_a
             , min_current_b
             , min_current_c
             , max_current_a
             , max_current_b
             , max_current_c
             , avg_reactive_power_a
             , avg_reactive_power_b
             , avg_reactive_power_c
             , std_reactive_power_a
             , std_reactive_power_b
             , std_reactive_power_c
             , med_reactive_power_a
             , med_reactive_power_b
             , med_reactive_power_c
             , lq_reactive_power_a
             , lq_reactive_power_b
             , lq_reactive_power_c
             , uq_reactive_power_a
             , uq_reactive_power_b
             , uq_reactive_power_c
             , min_reactive_power_a
             , min_reactive_power_b
             , min_reactive_power_c
             , max_reactive_power_a
             , max_reactive_power_b
             , max_reactive_power_c
             , avg_voltage_a
             , avg_voltage_b
             , avg_voltage_c
             , std_voltage_a
             , std_voltage_b
             , std_voltage_c
             , med_voltage_a
             , med_voltage_b
             , med_voltage_c
             , lq_voltage_a
             , lq_voltage_b
             , lq_voltage_c
             , uq_voltage_a
             , uq_voltage_b
             , uq_voltage_c
             , min_voltage_a
             , min_voltage_b
             , min_voltage_c
             , max_voltage_a
             , max_voltage_b
             , max_voltage_c
        FROM snap."MeasurementValue" AS s
        WHERE s.diff = '+';

    -- Updated elements
    UPDATE main."MeasurementValue" AS p
        SET avg_active_power_a = s.avg_active_power_a
          , avg_active_power_b = s.avg_active_power_b
          , avg_active_power_c = s.avg_active_power_c
          , std_active_power_a = s.std_active_power_a
          , std_active_power_b = s.std_active_power_b
          , std_active_power_c = s.std_active_power_c
          , med_active_power_a = s.med_active_power_a
          , med_active_power_b = s.med_active_power_b
          , med_active_power_c = s.med_active_power_c
          , lq_active_power_a = s.lq_active_power_a
          , lq_active_power_b = s.lq_active_power_b
          , lq_active_power_c = s.lq_active_power_c
          , uq_active_power_a = s.uq_active_power_a
          , uq_active_power_b = s.uq_active_power_b
          , uq_active_power_c = s.uq_active_power_c
          , min_active_power_a = s.min_active_power_a
          , min_active_power_b = s.min_active_power_b
          , min_active_power_c = s.min_active_power_c
          , max_active_power_a = s.max_active_power_a
          , max_active_power_b = s.max_active_power_b
          , max_active_power_c = s.max_active_power_c
          , avg_current_a = s.avg_current_a
          , avg_current_b = s.avg_current_b
          , avg_current_c = s.avg_current_c
          , std_current_a = s.std_current_a
          , std_current_b = s.std_current_b
          , std_current_c = s.std_current_c
          , med_current_a = s.med_current_a
          , med_current_b = s.med_current_b
          , med_current_c = s.med_current_c
          , lq_current_a = s.lq_current_a
          , lq_current_b = s.lq_current_b
          , lq_current_c = s.lq_current_c
          , uq_current_a = s.uq_current_a
          , uq_current_b = s.uq_current_b
          , uq_current_c = s.uq_current_c
          , min_current_a = s.min_current_a
          , min_current_b = s.min_current_b
          , min_current_c = s.min_current_c
          , max_current_a = s.max_current_a
          , max_current_b = s.max_current_b
          , max_current_c = s.max_current_c
          , avg_reactive_power_a = s.avg_reactive_power_a
          , avg_reactive_power_b = s.avg_reactive_power_b
          , avg_reactive_power_c = s.avg_reactive_power_c
          , std_reactive_power_a = s.std_reactive_power_a
          , std_reactive_power_b = s.std_reactive_power_b
          , std_reactive_power_c = s.std_reactive_power_c
          , med_reactive_power_a = s.med_reactive_power_a
          , med_reactive_power_b = s.med_reactive_power_b
          , med_reactive_power_c = s.med_reactive_power_c
          , lq_reactive_power_a = s.lq_reactive_power_a
          , lq_reactive_power_b = s.lq_reactive_power_b
          , lq_reactive_power_c = s.lq_reactive_power_c
          , uq_reactive_power_a = s.uq_reactive_power_a
          , uq_reactive_power_b = s.uq_reactive_power_b
          , uq_reactive_power_c = s.uq_reactive_power_c
          , min_reactive_power_a = s.min_reactive_power_a
          , min_reactive_power_b = s.min_reactive_power_b
          , min_reactive_power_c = s.min_reactive_power_c
          , max_reactive_power_a = s.max_reactive_power_a
          , max_reactive_power_b = s.max_reactive_power_b
          , max_reactive_power_c = s.max_reactive_power_c
          , avg_voltage_a = s.avg_voltage_a
          , avg_voltage_b = s.avg_voltage_b
          , avg_voltage_c = s.avg_voltage_c
          , std_voltage_a = s.std_voltage_a
          , std_voltage_b = s.std_voltage_b
          , std_voltage_c = s.std_voltage_c
          , med_voltage_a = s.med_voltage_a
          , med_voltage_b = s.med_voltage_b
          , med_voltage_c = s.med_voltage_c
          , lq_voltage_a = s.lq_voltage_a
          , lq_voltage_b = s.lq_voltage_b
          , lq_voltage_c = s.lq_voltage_c
          , uq_voltage_a = s.uq_voltage_a
          , uq_voltage_b = s.uq_voltage_b
          , uq_voltage_c = s.uq_voltage_c
          , min_voltage_a = s.min_voltage_a
          , min_voltage_b = s.min_voltage_b
          , min_voltage_c = s.min_voltage_c
          , max_voltage_a = s.max_voltage_a
          , max_voltage_b = s.max_voltage_b
          , max_voltage_c = s.max_voltage_c
        FROM snap."MeasurementValue" AS s
        WHERE s.diff = '!'
            AND p.record_date = $1
            AND s.timestamp = p.timestamp
            AND s.measurement_terminal_fk = p.measurement_terminal_fk;

    -- Removed elements
    DELETE FROM main."MeasurementValue" AS p
        USING snap."MeasurementValue" AS s
        WHERE s.diff = '-'
            AND p.record_date = $1
            AND s.timestamp = p.timestamp
            AND s.measurement_terminal_fk = p.measurement_terminal_fk;
$$ LANGUAGE SQL;

CREATE OR REPLACE PROCEDURE "PersistMeasurementEvent" (t TIMESTAMP) AS $$
    -- New elements
    INSERT INTO main."MeasurementEvent" AS p
        SELECT s.timestamp
             , $1
             , null
             , null
             , s.value
             , s.type
             , s.measurement_terminal_fk
             , s.phase
             --, $1 record_date ??
        FROM snap."MeasurementEvent" AS s
        WHERE s.diff = '+';

    -- Updated elements
    UPDATE main."MeasurementEvent" AS p
        SET value = s.value
        FROM snap."MeasurementEvent" AS s
        WHERE s.diff = '!'
            AND p.timestamp = s.timestamp
            AND s.type = p.type
            AND s.phase = p.phase
            AND s.measurement_terminal_fk = p.measurement_terminal_fk;

    -- Removed elements
    -- CONSTRAINT: for each measurementTerminal, phase and eventType there can only be one MeasurementEvent at a time
    UPDATE main."MeasurementEvent" AS p
        SET end_date = s.timestamp
          , record_end_date = $1
        FROM snap."MeasurementEvent" AS s
        WHERE s.diff = '-'
            AND p.end_date IS NULL
            AND s.type = p.type
            AND s.phase = p.phase
            AND s.measurement_terminal_fk = p.measurement_terminal_fk;
$$ LANGUAGE SQL;
