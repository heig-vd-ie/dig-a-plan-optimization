from dataclasses import dataclass
from functools import cached_property, reduce
from sqlalchemy import *
from sqlalchemy import Table
from sqlalchemy.dialects.postgresql import *


@dataclass
class AttrExtractor():
    query: Selectable
    name: str
    json_columns: list[Column]
    join_columns: list[Column]

    attr_col: str = 'attr'

    @cached_property
    def select(self):
        # Create row with specified columns only
        lat = (
            select(*self.json_columns)
            .correlate(self.query)
            .lateral(f"{self.name}_lat")
        )
        # Convert above row to a JSON object
        attr = (
            select(*self.join_columns, func.row_to_json(lat.table_valued()).cast(JSONB).label(self.attr_col))
            .join_from(self.query, lat, true)
        ).alias(f"{self.name}_attr")
        return attr



@dataclass
class AttrMerger():
    parent_table: Table
    pk_cols: list[Column]  # Shared pk col name between main table and its specialisation
    class_col: Column
    spec_data: list[AttrExtractor]

    attr_col: str = 'attr'

    def select(self):
        # SELECT clause to merge JSON objects
        def merge_attr(acc: ColumnClause, x: AttrExtractor):
            new_col = acc.concat(func.coalesce(x.select.c[x.attr_col], '{}')).label(self.attr_col)
            return new_col
        select_clause = select(
            *self.pk_cols,
            reduce(
                merge_attr, 
                self.spec_data,
                literal('{}').cast(JSONB),
            )
        ).select_from(self.parent_table)

        # JOIN from clauses together
        def join_spec(acc: Select, d: AttrExtractor):
            return acc.join(
                d.select,
                and_(
                    self.class_col == d.name,
                    *[p == d.select.c[c.name] for p, c in zip(self.pk_cols, d.join_columns)],
                ),
                isouter=True)
        spec = reduce(
            join_spec, 
            self.spec_data,
            select_clause
        )

        return spec
    
def attr_extractor_from(table: Table, primary_keys: ColumnCollection) -> AttrExtractor:
    return AttrExtractor(
        query=table,
        name=table.name,
        join_columns=primary_keys,
        json_columns=[c for c in table.columns if not primary_keys.contains_column(c)],
    )

def attr_extractor_from_table(table: Table) -> AttrExtractor:
    return attr_extractor_from(table, table.primary_key.columns)
