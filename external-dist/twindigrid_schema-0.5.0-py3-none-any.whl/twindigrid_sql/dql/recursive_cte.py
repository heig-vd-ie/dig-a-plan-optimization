from typing import Callable, Literal, Optional
from sqlalchemy import CTE, SelectBase, select


def recursive_cte(non_recursive_term: SelectBase, union_type: Literal['UNION', 'UNION ALL'], recursive_term: Callable[[CTE], SelectBase], name: Optional[str] = None) -> CTE:
    init_term = non_recursive_term.cte(name=name, recursive=True)
    rc_alias = init_term.alias()
    union = init_term.union if union_type == 'UNION' else init_term.union_all
    rec = union(
        recursive_term(rc_alias)
    )

    return rec
