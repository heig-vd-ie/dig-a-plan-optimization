-- Other way to store connectivity
create view "ConnectivityEvent" as
	select c.eq_fk, c.side, c.concrete_type, c.abstraction_fk, c.cn_fk, c.install_date as event_date, c.record_install_date as record_date, true as is_install
	from main."Connectivity" c
	union
	select c.eq_fk, c.side, c.concrete_type, c.abstraction_fk, c.cn_fk, c.uninstall_date as event_date, c.record_uninstall_date as record_date, false as is_install
	from main."Connectivity" c
	where c.record_uninstall_date is not null;
COMMENT ON VIEW "ConnectivityEvent" IS $md$
View of all `Connectivity` instances either connected or disconnected.
$md$;
COMMENT ON COLUMN "ConnectivityEvent".eq_fk IS $md$
The uuid of the `Equipment` that its terminal is connected in this row.
$md$;
COMMENT ON COLUMN "ConnectivityEvent".side IS $md$
Side of the `Equipment` (`Terminal`) that is connected in this row. Either `t1`, `t2`, or `t`.
$md$;
COMMENT ON COLUMN "ConnectivityEvent".concrete_type IS $md$
It is used to determine the concrete equipment that is connected in this row; `equipmenttype` is the type of the equipment, which is one of the following values: `bess`, `branch`, `busbarSection`, `energyConsumer`, `externalNetwork`, `pv`, `switch`, `transformer`, `synchronousGenerationUnit`, `measurementDevice`.
$md$;
COMMENT ON COLUMN "ConnectivityEvent".abstraction_fk IS $md$
The uuid of the abstraction layer that `Equipment` that its terminal is connected in this row.
$md$;
COMMENT ON COLUMN "ConnectivityEvent".cn_fk IS $md$
The uuid of the `ConnectivityNode` that the `Terminal` is connected to.
$md$;
COMMENT ON COLUMN "ConnectivityEvent".event_date IS $md$
Actual installation date of this connectivity.
$md$;
COMMENT ON COLUMN "ConnectivityEvent".record_date IS $md$
Record installation date of this connectivity.
$md$;
COMMENT ON COLUMN "ConnectivityEvent".is_install IS $md$
A boolean value indicating whether the connectivity is installed or not.
$md$;

CREATE VIEW "SnapConnectivity" AS
	SELECT c.eq_fk, c.side, c.concrete_type, c.abstraction_fk, c.cn_fk, c.install_date as timestamp
	FROM main."Connectivity" c
	WHERE c.record_uninstall_date is null;
CREATE FUNCTION "SnapConnectivity"(t timestamp) RETURNS SETOF "SnapConnectivity" AS $$
	SELECT c.eq_fk, c.side, c.concrete_type, c.abstraction_fk, c.cn_fk, c.install_date as timestamp
	FROM main."Connectivity" c
	WHERE main.in_period(c.record_install_date, $1, c.record_uninstall_date)
$$ language sql stable;
-- connectivity at time t and for abstraction a
create function "ConnectivityAtTime"(t timestamp, a uuid) returns table(
	eq_fk uuid,
	side snap.terminalside,
	concrete_type snap.equipmenttype,
	cn_fk uuid
) as $$
	select tc.*
	from (
		SELECT distinct on (cs.terminal_uuid) cs.eq_fk, cs.side, cs.concrete_type, cs.cn_fk
		FROM (
			SELECT cl.*, s.lvl
			FROM main."Connectivity" cl
			INNER JOIN main."AbstractionStack"($2) s ON s.uuid = cl.abstraction_fk
			where cl.record_install_date <= $1 and (cl.record_uninstall_date is null or $1 < cl.record_uninstall_date)
		) cs
		order by cs.terminal_uuid, cs.lvl asc
	) tc
	where cn_fk is not null
$$ language sql stable;
COMMENT ON VIEW "SnapConnectivity" IS $md$
A view to insert data into the table of `Connectivity` if we we want to insert data related to the connection.
$md$;
COMMENT ON COLUMN "SnapConnectivity".eq_fk IS $md$
The uuid of the equipment that its terminal is connected to.
$md$;
COMMENT ON COLUMN "SnapConnectivity".side IS $md$
Side of the `Equipment` (`Terminal`) that is connected to the `ConnectivityNode`; either it is `t1`, `t2` or `t`.
$md$;
COMMENT ON COLUMN "SnapConnectivity".concrete_type IS $md$
It is used to determine the concrete equipment that is connected in this row; `equipmenttype` is the type of the equipment, which is one of the following values: `bess`, `branch`, `busbarSection`, `energyConsumer`, `externalNetwork`, `pv`, `switch`, `transformer`, `synchronousGenerationUnit`, `measurementDevice`.
$md$;
COMMENT ON COLUMN "SnapConnectivity".abstraction_fk IS $md$
The uuid of the abstraction layer that `Equipment` that its terminal is connected in this row.
$md$;
COMMENT ON COLUMN "SnapConnectivity".cn_fk IS $md$
The uuid of the `ConnectivityNode` that the `Terminal` is connected to.
$md$;

-- View to match terminal with topological node
-- CONSTRAINT: connectivity of CN and topology should have installation overlap
create view "TerminalTopology" as
	select con.eq_fk, con.side, topo.tn_fk,
		greatest(topo.record_install_date, con.record_install_date) as record_install_date,
		least(topo.record_uninstall_date, con.record_uninstall_date) as record_uninstall_date
	from "Topology" topo
	inner join "Connectivity" con on topo.cn_fk = con.cn_fk
		and (topo.record_uninstall_date > con.record_install_date or topo.record_uninstall_date is null)
		and (topo.record_install_date < con.record_uninstall_date or con.record_uninstall_date is null);
COMMENT ON VIEW "TerminalTopology" IS $md$
A view to relation of `Terminal` data and table of `Topology`.
$md$;
COMMENT ON COLUMN "TerminalTopology".eq_fk IS $md$
The uuid of the equipment that its terminal is connected to.
$md$;
COMMENT ON COLUMN "TerminalTopology".side IS $md$
Side of the `Equipment` (`Terminal`) that is connected to the `ConnectivityNode`; either it is `t1`, `t2` or `t`.
$md$;
COMMENT ON COLUMN "TerminalTopology".tn_fk IS $md$
The uuid of the `TopologyNode` that the `Terminal` is connected to.
$md$;
COMMENT ON COLUMN "TerminalTopology".record_install_date IS $md$
Record installation date of this topological connection.
$md$;
COMMENT ON COLUMN "TerminalTopology".record_uninstall_date IS $md$
Record uninstallation date of this topological connection.
$md$;

CREATE VIEW "SnapTopology" AS
	SELECT t.cn_fk, t.tn_fk
	FROM main."Topology" t
	WHERE t.record_uninstall_date is null;
CREATE FUNCTION "SnapTopology"(t timestamp) RETURNS SETOF "SnapTopology" AS $$
	SELECT t.cn_fk, t.tn_fk
	FROM main."Topology" t
	WHERE main.in_period(t.record_install_date, $1, t.record_uninstall_date)
$$ language sql stable;
COMMENT ON VIEW "SnapTopology" IS $md$
A view to insert data into the table of `Topology` if we we want to insert data related to the topology.
$md$;
COMMENT ON COLUMN "SnapTopology".cn_fk IS $md$
The uuid of the `ConnectivityNode` that is connected to a topological connection this row.
$md$;
COMMENT ON COLUMN "SnapTopology".tn_fk IS $md$
The uuid of the `TopologyNode` that the `ConnectivityNode` is connected to.
$md$;
