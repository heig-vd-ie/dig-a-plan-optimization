-- for all abstraction layers get the number of layers that are beneath it
-- CONSTRAINT: abstraction parentage MUST BE a tree
create k view "AbstractionDepth" (uuid, parent_fk, depth, parents) as
	select a.uuid, a.parent_fk, 0, '{}'::uuid[]
	from "Abstraction" a
	where a.parent_fk is null
	union
	SELECT a.uuid, a.parent_fk, s.depth + 1, s.parents || ARRAY[a.parent_fk]
	FROM "AbstractionDepth" s
	INNER JOIN "Abstraction" a ON s.uuid = a.parent_fk;
COMMENT ON VIEW "AbstractionDepth" IS $md$
A view to find all antecedent of an abstraction layer.
$md$;
COMMENT ON COLUMN "AbstractionDepth".uuid IS $md$
The uuid of the abstraction determined by this row.
$md$;
COMMENT ON COLUMN "AbstractionDepth".parent_fk IS $md$
The uuid of the parent abstraction. It indicates that the abstraction determined by this row inherits by default the equipment and connectivity of its parent abstraction.
**Remark:** When null, the layer is a base physical layer.
$md$;
COMMENT ON COLUMN "AbstractionDepth".depth IS $md$
Number of antecedent that this layer inherits from.
$md$;
COMMENT ON COLUMN "AbstractionDepth".parents IS $md$
The uuid of all parent abstraction.
$md$;

-- for a given abstraction layer get itself and the abstraction from which it inherits
CREATE FUNCTION "AbstractionStack"(a uuid) RETURNS TABLE(
	uuid uuid, parent_fk uuid, lvl int
) as $$
	WITH RECURSIVE stack (
		uuid, parent_fk, lvl
	) AS (
		SELECT a.uuid, a.parent_fk, 0
		FROM main."Abstraction" a
		WHERE a.uuid = $1
		UNION
		SELECT a.uuid, a.parent_fk, s.lvl + 1
		FROM stack s
		INNER JOIN main."Abstraction" a ON a.uuid = s.parent_fk
	)
	select uuid, parent_fk, lvl
	from stack;
$$ language sql stable;


-- Return if it exists the uuid of a group mapping (at time t and for abstraction a) that has all the given equipments as source.
create function "GroupMappingOf"(t timestamp, a uuid, gms variadic uuid[]) returns uuid
language sql as $$
	select gm.uuid
	from "GroupMapping" gm
	where main.in_period(gm.record_install_date, $1, gm.record_uninstall_date)
		and gm.abstraction_fk = $2
		and exists(
			select egm.eq_fk
			from "EquipmentGroupMapping" egm
			where egm.gm_fk = gm.uuid
				and egm.is_sink = false
				and egm.eq_fk = ANY($3)
		)
$$ stable;

-- CONSTRAINT: equipment MUST always keep the same base abstraction.
-- CONSTRAINT: all side of an equipment MUST BE created on the same base abstraction layer (but can be abstracted to diff layer)
create view "EquipmentBaseAbstraction" as
	select egm.eq_fk, gm.abstraction_fk
	from "EquipmentGroupMapping" egm
	inner join "GroupMapping" gm on egm.gm_fk = gm.uuid
	where egm.is_sink;
COMMENT ON VIEW "EquipmentBaseAbstraction" IS $md$
Retrieve the base abstraction of an equipment using the `groupMapping`.
$md$;
COMMENT ON COLUMN "EquipmentBaseAbstraction".eq_fk IS $md$
The uuid of the equipment.
$md$;
COMMENT ON COLUMN "EquipmentBaseAbstraction".abstraction_fk IS $md$
The uuid of the base abstraction of an equipment using the `groupMapping`.
$md$;
