CREATE OR REPLACE FUNCTION "SnapMeasurementTerminal"(t timestamp) RETURNS SETOF "MeasurementTerminal" as $$
	select mt.*
	from main."MeasurementTerminal" mt
	where (mt.eq_fk, mt.side) in (SELECT eq_fk, side FROM main."SnapConnectivity"($1))
$$ language sql stable;

CREATE OR REPLACE VIEW "SnapMeasurementDevice" AS
	SELECT
		md.*,
		eq.geo, eq.name, egm.gm_fk
	FROM main."MeasurementDevice" md
	LEFT JOIN main."EquipmentGroupMapping" egm ON md.uuid = egm.eq_fk AND egm.is_sink
	INNER JOIN main."Equipment" eq ON md.uuid = eq.uuid;
CREATE FUNCTION measurementDevice_insert() RETURNS trigger AS $$
    BEGIN
	    INSERT INTO main."Equipment" SELECT NEW.uuid, 'measurementDevice', NEW.geo, NEW.name;
	    INSERT INTO main."MeasurementDevice" SELECT NEW.uuid, NEW.accuracy_active_power, NEW.accuracy_current, NEW.accuracy_reactive_power, NEW.accuracy_voltage, NEW.rated_current, NEW.aggregation_period, NEW.value_source_fk;
	    INSERT INTO main."EquipmentGroupMapping"(eq_fk, gm_fk, is_sink) SELECT new.uuid, new.gm_fk, true;
	    RETURN null;
    END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER measurementDevice_insert
    instead OF INSERT ON "SnapMeasurementDevice"
    FOR EACH ROW
    EXECUTE FUNCTION measurementDevice_insert();
CREATE OR REPLACE FUNCTION "SnapMeasurementDevice"(t timestamp) RETURNS SETOF "SnapMeasurementDevice" as $$
	select md.*, eq.geo, eq.name, egm.gm_fk
	from main."MeasurementDevice" md
	LEFT JOIN main."EquipmentGroupMapping" egm ON md.uuid = egm.eq_fk AND egm.is_sink
	INNER JOIN main."Equipment" eq ON md.uuid = eq.uuid
	where (md.uuid) in (SELECT measurement_device_fk FROM main."SnapMeasurementTerminal"($1))
$$ language sql stable;
COMMENT ON VIEW "SnapMeasurementDevice" IS $md$
A view to insert data into the table of `MeasurementDevice` and all associated tables if we we want to insert new `MeasurementDevice`.
$md$;
COMMENT ON COLUMN "SnapMeasurementDevice".uuid IS $md$
The uuid of the `MeasurementDevice` determined by this row.
$md$;
COMMENT ON COLUMN "SnapMeasurementDevice".accuracy_active_power IS $md$
The limit, expressed as a percentage of the sensor maximum, that accuracy would not less than when the sensor is used under reference conditions (Unit: `%`).
$md$;
COMMENT ON COLUMN "SnapMeasurementDevice".accuracy_current IS $md$
The limit, expressed as a percentage of the sensor maximum, that accuracy would not less than when the sensor is used under reference conditions (Unit: `%`).
$md$;
COMMENT ON COLUMN "SnapMeasurementDevice".accuracy_reactive_power IS $md$
The limit, expressed as a percentage of the sensor maximum, that accuracy would not less than when the sensor is used under reference conditions (Unit: `%`).
$md$;
COMMENT ON COLUMN "SnapMeasurementDevice".accuracy_voltage IS $md$
The limit, expressed as a percentage of the sensor maximum, that accuracy would not less than when the sensor is used under reference conditions (Unit: `%`).
$md$;
COMMENT ON COLUMN "SnapMeasurementDevice".rated_current IS $md$
Maximum current that measurement device can measure and the accuracies of current, active power, and reactive power are based on that (Unit: `A`).
$md$;
COMMENT ON COLUMN "SnapMeasurementDevice".aggregation_period IS $md$
Aggregation period of `MeasurementDevice`, e.g., 600 seconds or 60 seconds (Unit: `seconds`).
$md$;
COMMENT ON COLUMN "SnapMeasurementDevice".geo IS $md$
Latitude and Longitude of the `MeasurementDevice` location (Unit: `WGS84`).
$md$;
COMMENT ON COLUMN "SnapMeasurementDevice".value_source_fk IS $md$
The uuid of measurement source that this `MeasurementDevice` is associated with.
$md$;
COMMENT ON COLUMN "SnapMeasurementDevice".name IS $md$
Human readable name of the `MeasurementDevice` determined by this row.
$md$;
COMMENT ON COLUMN "SnapMeasurementDevice".gm_fk IS $md$
The uuid of the `GroupMapping` that represents the relationship among a number of `MeasurementDevice` across abstraction.
$md$;

CREATE OR REPLACE FUNCTION "SnapMeasurementValue"(t timestamp) RETURNS SETOF "MeasurementValue" as $$
	select mv.*
	from main."MeasurementValue" mv
    where mv.record_date = $1
$$ language sql stable;

CREATE OR REPLACE FUNCTION "SnapMeasurementEvent"(t timestamp) RETURNS SETOF "MeasurementEvent" as $$
	select me.*
	from main."MeasurementEvent" me
	where main.in_period(me.timestamp, $1, me.end_date)
$$ language sql stable;
