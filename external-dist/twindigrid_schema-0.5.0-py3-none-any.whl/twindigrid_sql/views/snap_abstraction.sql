CREATE OR REPLACE FUNCTION "SnapGroupMapping"(t timestamp) RETURNS SETOF "GroupMapping" as $$
	SELECT gm.*
	FROM main."GroupMapping" gm
	WHERE main.in_period(gm.record_install_date, $1, gm.record_uninstall_date)
$$ language sql stable;

CREATE OR REPLACE FUNCTION "SnapEquipmentGroupMapping"(t timestamp) RETURNS SETOF "EquipmentGroupMapping" as $$
	SELECT map.*
	FROM main."EquipmentGroupMapping" map
    WHERE map.gm_fk IN (SELECT uuid FROM main."SnapGroupMapping"($1))
$$ language sql stable;

CREATE OR REPLACE FUNCTION "SnapTerminalMapping"(t timestamp) RETURNS SETOF "TerminalMapping" AS $$
	SELECT map.*
	FROM main."TerminalMapping" map
    WHERE map.gm_fk IN (SELECT uuid FROM main."SnapGroupMapping"($1))
$$ language sql stable;

CREATE OR REPLACE FUNCTION "SnapCnMapping"(t timestamp) RETURNS SETOF "CnMapping" as $$
	select map.*
	from main."CnMapping" map
    WHERE map.gm_fk IN (SELECT uuid FROM main."SnapGroupMapping"($1))
$$ language sql stable;
