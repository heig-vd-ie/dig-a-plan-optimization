-- "Equipment" insert, to automatically insert into:
--		- "Equipment"
--		- specialization
--		- "Terminal"
--		- "EquipmentGroupMapping"
--		- event if applicable (tap, parameter, switch)
-- TODO: auto correct/fill recordDate to next heartbeat of self/timestamp?

-- CONSTRAINT: Should we require a new event on each installation?
create view "SnapBranch" as
	select
		eqs.*,
		eq.geo, eq.name,
		t1.phases as t1_phases, t2.phases as t2_phases,
		egm.gm_fk,
		param.timestamp, param.record_date, param.value_source,
		param.b, param.b0, param.r, param.r0, param.x, param.x0
	from main."Branch" eqs
	left join lateral (
		select ev.*
		from main."SnapBranchParameterEvent"('infinity') ev
		where ev.eq_fk = eqs.uuid
	) param on true
	left join main."EquipmentGroupMapping" egm on eqs.uuid = egm.eq_fk and egm.is_sink
	inner join main."Equipment" eq on eqs.uuid = eq.uuid
	inner join main."Terminal" t1 on eqs.uuid = t1.eq_fk and t1.side = 't1'
	inner join main."Terminal" t2 on eqs.uuid = t2.eq_fk and t2.side = 't2';
alter view "SnapBranch" alter b set default 0;
alter view "SnapBranch" alter b0 set default 0;
alter view "SnapBranch" alter r0 set default 0;
alter view "SnapBranch" alter x0 set default 0;
alter view "SnapBranch" alter value_source set default 'manualRaw';
alter view "SnapBranch" alter t1_phases set default 'ABCn';
alter view "SnapBranch" alter t2_phases set default 'ABCn';
alter view "SnapBranch" alter is_underground set default null;
CREATE FUNCTION branch_insert() RETURNS trigger AS $$
    begin
	    insert into main."Equipment" select NEW.uuid, 'branch', NEW.geo, NEW.name;
	    insert into main."Branch" select new.uuid, new.current_limit, new.length, new.is_underground;
	    insert into main."Terminal" select new.uuid, 't1', new.t1_phases;
	    insert into main."Terminal" select new.uuid, 't2', new.t2_phases;
	    insert into main."EquipmentGroupMapping"(eq_fk, gm_fk, is_sink) select new.uuid, new.gm_fk, true;
	    insert into main."BranchParameterEvent"(
	    	timestamp, record_date, eq_fk, value_source,
	    	b, b0, r, r0, x, x0
	    ) select
	    	new.timestamp, new.record_date, new.uuid, new.value_source,
	    	new.b, new.b0, new.r, new.r0, new.x, new.x0;
	    return null;
    END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER branch_insert
    instead OF INSERT ON "SnapBranch"
    FOR EACH ROW
    EXECUTE FUNCTION branch_insert();
CREATE OR REPLACE FUNCTION "SnapBranch"(t timestamp) RETURNS SETOF "SnapBranch" as $$
	select
		eqs.*,
		eq.geo, eq.name,
		t1.phases as t1_phases, t2.phases as t2_phases,
		egm.gm_fk,
		param.timestamp, param.record_date, param.value_source,
		param.b, param.b0, param.r, param.r0, param.x, param.x0
	from main."Branch" eqs
	left join lateral (
		select ev.*
		from main."SnapBranchParameterEvent"($1) ev
		where ev.eq_fk = eqs.uuid
	) param on true
	left join main."EquipmentGroupMapping" egm on eqs.uuid = egm.eq_fk and egm.is_sink
	inner join main."Equipment" eq on eqs.uuid = eq.uuid
	inner join main."Terminal" t1 on eqs.uuid = t1.eq_fk and t1.side = 't1'
	inner join main."Terminal" t2 on eqs.uuid = t2.eq_fk and t2.side = 't2'
	where eqs.uuid in (SELECT eq_fk FROM main."SnapConnectivity"($1))
$$ language sql stable;
COMMENT ON VIEW "SnapBranch" IS $md$
A view to insert data into the table of `Branch` and all associated tables if we we want to insert new `Branch`.
$md$;
COMMENT ON COLUMN "SnapBranch".uuid IS $md$
The uuid of the `Branch` determined by this row.
$md$;
COMMENT ON COLUMN "SnapBranch".current_limit IS $md$
Nominal current of `Branch` (Symbol: `I_b_nom`,Unit: `A`)
$md$;
COMMENT ON COLUMN "SnapBranch".length IS $md$
Length of `Branch` (Symbol: `L_b`,Unit: `km`)
$md$;
COMMENT ON COLUMN "SnapBranch".is_underground IS $md$
Boolean that determines whether the `Branch` is underground or not; `True` if it is underground and `False` otherwise.

**Remark:** When this columns is null, it means that the `Branch` is a mixture of underground and over overground.
$md$;
COMMENT ON COLUMN "SnapBranch".geo IS $md$
Latitude and Longitude of the `Branch` location (Unit: `WGS84`).
$md$;
COMMENT ON COLUMN "SnapBranch".name IS $md$
Human readable name of the `Branch` determined by this row.
$md$;
COMMENT ON COLUMN "SnapBranch".t1_phases IS $md$
Represents the normal network phasing condition at `t1` side. `phases` is the type of this column, which is one of the following values: `ABC`, `ABCn`, `An`, `Bn`, `Cn`, `AB`, `BC`, `AC`.
$md$;
COMMENT ON COLUMN "SnapBranch".t2_phases IS $md$
Represents the normal network phasing condition at `t2` side. `phases` is the type of this column, which is one of the following values: `ABC`, `ABCn`, `An`, `Bn`, `Cn`, `AB`, `BC`, `AC`.
$md$;
COMMENT ON COLUMN "SnapBranch".gm_fk IS $md$
The uuid of the `GroupMapping` that represents the relationship among a number of `Branch` across abstraction.
$md$;
COMMENT ON COLUMN "SnapBranch".timestamp IS $md$
Time stamp of parameter change event (Symbol: `t`).
$md$;
COMMENT ON COLUMN "SnapBranch".record_date IS $md$
Record date of parameter change event.
$md$;
COMMENT ON COLUMN "SnapBranch".value_source IS $md$
Whether the parameter event is determined after calculation or it is based on nominal values; `eventsource` is the type of this column, which is one of the following: `autoRaw`, `manualRaw`, `digitaltwin`.
$md$;
COMMENT ON COLUMN "SnapBranch".r IS $md$
Positive sequence series resistance of the one unit of length of branch (Symbol: `R_b`, Unit: `Ohms per km`).
$md$;
COMMENT ON COLUMN "SnapBranch".r0 IS $md$
Zero sequence series resistance of the entire line (Symbol: `R0_b`, Unit: `Ohms per km`).
$md$;
COMMENT ON COLUMN "SnapBranch".x IS $md$
Positive sequence series reactance of the one unit of length of branch (Symbol: `X_b`, Unit: `Ohms per km`).
$md$;
COMMENT ON COLUMN "SnapBranch".x0 IS $md$
Zero sequence series reactance of the entire line section (Symbol: `X_b`, Unit: `Ohms per km`).
$md$;
COMMENT ON COLUMN "SnapBranch".b IS $md$
Positive sequence shunt (charging) susceptance, uniformly distributed, of the entire line section. This value represents the full charging over the one unit of length of the line. The value can be positive or negative (Symbol: `B_b`, Unit: `mho per km`).
$md$;
COMMENT ON COLUMN "SnapBranch".b0 IS $md$
Zero sequence shunt (charging) susceptance, uniformly distributed, of the entire line (Symbol: `B0_b`, Unit: `mho per km`).
$md$;

create view "SnapBusbarSection" as
	select
		eqs.*,
		eq.geo, eq.name,
		t.phases as phases,
		egm.gm_FK
	from main."BusbarSection" eqs
	left join main."EquipmentGroupMapping" egm on eqs.uuid = egm.eq_fk and egm.is_sink
	inner join main."Equipment" eq on eqs.uuid = eq.uuid
	inner join main."Terminal" t on eqs.uuid = t.eq_fk;
alter view "SnapBusbarSection" alter phases set default 'ABCn';
CREATE FUNCTION busbarSection_insert() RETURNS trigger AS $$
    begin
	    insert into main."Equipment" select NEW.uuid, 'busbarSection', NEW.geo, NEW.name;
	    insert into main."BusbarSection" select new.uuid, new.voltage_level, new.voltage_min, new.voltage_max;
	    insert into main."Terminal" select new.uuid, 't', new.phases;
	    insert into main."EquipmentGroupMapping"(eq_fk, gm_fk, is_sink) select new.uuid, new.gm_fk, true;
	    return null;
    END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER busbarSection_insert
    instead OF INSERT ON "SnapBusbarSection"
    FOR EACH ROW
    EXECUTE FUNCTION busbarSection_insert();
CREATE OR REPLACE FUNCTION "SnapBusbarSection"(t timestamp) RETURNS SETOF "SnapBusbarSection" as $$
	select seq.*
	from main."SnapBusbarSection" seq
	where seq.uuid in (SELECT eq_fk FROM main."SnapConnectivity"($1))
$$ language sql stable;
COMMENT ON VIEW "SnapBusbarSection" IS $md$
A view to insert data into the table of `BusbarSection` and all associated tables if we we want to insert new `BusbarSection`.
$md$;
COMMENT ON COLUMN "SnapBusbarSection".uuid IS $md$
The uuid of the `BusbarSection` determined by this row.
$md$;
COMMENT ON COLUMN "SnapBusbarSection".voltage_level IS $md$
Value of nominal voltage at busbar section (Symbol: `V_bb_nom`,Unit: `V`).
$md$;
COMMENT ON COLUMN "SnapBusbarSection".voltage_min IS $md$
Minimum acceptable voltage level of a busbar section (Symbol: `V_bb_min`, Unit: `V`).
$md$;
COMMENT ON COLUMN "SnapBusbarSection".voltage_max IS $md$
Maximum acceptable voltage level of a busbar section (Symbol: `V_bb_max`, Unit: `V`).
$md$;
COMMENT ON COLUMN "SnapBusbarSection".geo IS $md$
Latitude and Longitude of the `BusbarSection` location (Unit: `WGS84`).
$md$;
COMMENT ON COLUMN "SnapBusbarSection".name IS $md$
Human readable name of the `BusbarSection` determined by this row.
$md$;
COMMENT ON COLUMN "SnapBusbarSection".phases IS $md$
Represents the normal network phasing condition of `BusbarSection`. `phases` is the type of this column, which is one of the following values: `ABC`, `ABCn`, `An`, `Bn`, `Cn`, `AB`, `BC`, `AC`.
$md$;
COMMENT ON COLUMN "SnapBusbarSection".gm_fk IS $md$
The uuid of the `GroupMapping` that represents the relationship among a number of `BusbarSection` across abstraction.
$md$;

create view "SnapTransformer" as
	select
		eqs.*,
		tapT1.value as tap_t1, tapT1.timestamp as tap_t1_timestamp, tapT1.record_date as tap_t1_record_date, tapT1.value_source as tap_t1_value_source,
		tapT2.value as tap_t2, tapT2.timestamp as tap_t2_timestamp, tapT2.record_date as tap_t2_record_date, tapT2.value_source as tap_t2_value_source,
		tt1.vals as taps_t1, tt2.vals as taps_t2,
		eq.geo, eq.name,
		t1.phases as t1_phases, t2.phases as t2_phases,
		egm.gm_fk,
		param.timestamp as param_timestamp, param.record_date as param_record_date, param.value_source as param_value_source,
		param.b, param.b0, param.g, param.g0, param.r, param.r0, param.x, param.x0
	from main."Transformer" eqs
	left join (
		select eq_fk, array_agg(value) as vals
		from main."Tap"
		where is_tap_t1 = false
		group by eq_fk
	) tt1 on tt1.eq_fk = eqs.uuid
	left join (
		select eq_fk, array_agg(value) as vals
		from main."Tap"
		where is_tap_t1 = true
		group by eq_fk
	) tt2 on tt2.eq_fk = eqs.uuid
	-- TODO: keep left join? avoid issue if for any reason we don't have an event...
	left join main."SnapTapEvent"('infinity') tapT1 on tapT1.eq_fk = eqs.uuid and tapT1.is_tap_t1 = true
	left join main."SnapTapEvent"('infinity') tapT2 on tapT2.eq_fk = eqs.uuid and tapT2.is_tap_t1 = false
	left join main."SnapTransformerParameterEvent"('infinity') param on param.eq_fk = eqs.uuid
	left join main."EquipmentGroupMapping" egm on eqs.uuid = egm.eq_fk and egm.is_sink
	inner join main."Equipment" eq on eqs.uuid = eq.uuid
	inner join main."Terminal" t1 on eqs.uuid = t1.eq_fk and t1.side = 't1'
	inner join main."Terminal" t2 on eqs.uuid = t2.eq_fk and t2.side = 't2';
alter view "SnapTransformer" alter b set default 0;
alter view "SnapTransformer" alter b0 set default 0;
alter view "SnapTransformer" alter g set default 0;
alter view "SnapTransformer" alter g0 set default 0;
alter view "SnapTransformer" alter r0 set default 0;
alter view "SnapTransformer" alter x0 set default 0;
alter view "SnapTransformer" alter t1_phases set default 'ABCn';
alter view "SnapTransformer" alter t2_phases set default 'ABCn';
alter view "SnapTransformer" alter tap_t1_value_source set default 'manualRaw';
alter view "SnapTransformer" alter tap_t2_value_source set default 'manualRaw';
alter view "SnapTransformer" alter param_value_source set default 'manualRaw';
CREATE FUNCTION transformer_insert() RETURNS trigger AS $$
    begin
	    insert into main."Equipment" select NEW.uuid, 'transformer', NEW.geo, NEW.name;
	    insert into main."Transformer" select new.uuid, new.vector_group, new.rated_s;
	   	insert into main."Tap" (eq_fk, is_tap_t1, value) select new.uuid, true, unnest(new.taps_t1);
	   	insert into main."Tap" (eq_fk, is_tap_t1, value) select new.uuid, false, unnest(new.taps_t2);
	    insert into main."TapEvent"(timestamp, record_date, tap_fk, value_source, eq_fk, is_tap_t1, value)
	   		select
	   			coalesce(new.tap_t1_timestamp, new.tap_t2_timestamp, new.param_timestamp), coalesce(new.tap_t1_record_date, new.tap_t2_record_date, new.param_record_date),
	   			tap.uuid, 'manualRaw',
	   			tap.eq_fk, tap.is_tap_t1, tap.value
	   		from main."Tap" tap
	   		where tap.value = new.tap_t1 and tap.is_tap_t1;
	    if not found then
	    	raise exception 'not t1 tap found for value %, should be one of %', new.tap_t1, new.taps_t1;
	    end if;
	    insert into main."TapEvent"(timestamp, record_date, tap_fk, value_source, eq_fk, is_tap_t1, value)
	   		select
	   			coalesce(new.tap_t2_timestamp, new.tap_t1_timestamp, new.param_timestamp), coalesce(new.tap_t2_record_date, new.tap_t1_record_date, new.param_record_date),
	   			tap.uuid, 'manualRaw',
	   			tap.eq_fk, tap.is_tap_t1, tap.value
	   		from main."Tap" tap
	   		where tap.value = new.tap_t2 and not tap.is_tap_t1;
	    if not found then
	    	raise exception 'not t2 t ap found for value %, should be one of %', new.tap_t2, new.taps_t2;
	    end if;
	    insert into main."Terminal" select new.uuid, 't1', new.t1_phases;
	    insert into main."Terminal" select new.uuid, 't2', new.t2_phases;
	    insert into main."EquipmentGroupMapping"(eq_fk, gm_fk, is_sink) select new.uuid, new.gm_fk, true;
	    insert into main."TransformerParameterEvent"(timestamp, record_date, eq_fk, value_source, b, b0, g, g0, r, r0, x, x0)
	    	select coalesce(new.param_timestamp, new.tap_t1_timestamp, new.tap_t2_timestamp), coalesce(new.param_record_date, new.tap_t1_record_date, new.tap_t2_record_date), new.uuid, new.param_value_source, new.b, new.b0, new.g, new.g0, new.r, new.r0, new.x, new.x0;
	    return null;
    END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER transformer_insert
    instead OF INSERT ON "SnapTransformer"
    FOR EACH ROW
    EXECUTE FUNCTION transformer_insert();
CREATE OR REPLACE FUNCTION "SnapTransformer"(t timestamp) RETURNS SETOF "SnapTransformer" as $$
	select
		eqs.*,
		tapT1.value as tap_t1, tapT1.timestamp as tap_t1_timestamp, tapT1.record_date as tap_t1_record_date, tapT1.value_source as tap_t1_value_source,
		tapT2.value as tap_t2, tapT2.timestamp as tap_t2_timestamp, tapT2.record_date as tap_t2_record_date, tapT2.value_source as tap_t2_value_source,
		tt1.vals as taps_t1, tt2.vals as taps_t2,
		eq.geo, eq.name,
		t1.phases as t1_phases, t2.phases as t2_phases,
		egm.gm_fk,
		param.timestamp as param_timestamp, param.record_date as param_record_date, param.value_source as param_value_source,
		param.b, param.b0, param.g, param.g0, param.r, param.r0, param.x, param.x0
	from main."Transformer" eqs
	left join (
		select eq_fk, array_agg(value) as vals
		from main."Tap"
		where is_tap_t1 = true
		group by eq_fk
	) tt1 on tt1.eq_fk = eqs.uuid
	left join (
		select eq_fk, array_agg(value) as vals
		from main."Tap"
		where is_tap_t1 = false
		group by eq_fk
	) tt2 on tt2.eq_fk = eqs.uuid
	-- TODO: keep left join? avoid issue if for any reason we don't have an event...
	left join main."SnapTapEvent"($1) tapT1 on tapT1.eq_fk = eqs.uuid and tapT1.is_tap_t1 = true
	left join main."SnapTapEvent"($1) tapT2 on tapT2.eq_fk = eqs.uuid and tapT2.is_tap_t1 = false
	left join main."SnapTransformerParameterEvent"($1) param on param.eq_fk = eqs.uuid
	left join main."EquipmentGroupMapping" egm on eqs.uuid = egm.eq_fk and egm.is_sink
	inner join main."Equipment" eq on eqs.uuid = eq.uuid
	inner join main."Terminal" t1 on eqs.uuid = t1.eq_fk and t1.side = 't1'
	inner join main."Terminal" t2 on eqs.uuid = t2.eq_fk and t2.side = 't2'
	where eqs.uuid in (SELECT eq_fk FROM main."SnapConnectivity"($1))
$$ language sql stable;
COMMENT ON VIEW "SnapTransformer" IS $md$
A view to insert data into the table of `Transformer` and all associated tables if we we want to insert new `Transformer`.
$md$;
COMMENT ON COLUMN "SnapTransformer".uuid IS $md$
The uuid of the `Transformer` determined by this row.
$md$;
COMMENT ON COLUMN "SnapTransformer".vector_group IS $md$
Kind of connection. `vectorgroup` is the of this column, which is one of the following values: `Dy1`, `Dy5`, `Dy11`, `Yy0`, `Yz1`, `Yz5`, `Yz11`, `Ynd1`.
$md$;
COMMENT ON COLUMN "SnapTransformer".rated_s IS $md$
Normal apparent power rating. The attribute shall be a positive value. For a two-winding transformer the values for the high and low voltage sides shall be identical (Symbol: `S_trf_nom`, Unit: `kVA`).
$md$;
COMMENT ON COLUMN "SnapTransformer".tap_t1 IS $md$
Record date of Tap changer Events of tap `t1` (higher voltage side).
$md$;
COMMENT ON COLUMN "SnapTransformer".tap_t1_timestamp IS $md$
Time stamp of parameter change event of tap `t1` (higher voltage side, Symbol: `t`).
$md$;
COMMENT ON COLUMN "SnapTransformer".tap_t1_record_date IS $md$
Record date of parameter change event of tap `t1` (higher voltage side).
$md$;
COMMENT ON COLUMN "SnapTransformer".tap_t1_value_source IS $md$
Whether the tap event is determined after estimation or it is logged by scada for tap `t1` (higher voltage side); `eventsource` is the type of this column, which is one of the following: `autoRaw`, `manualRaw`, `digitaltwin`.
$md$;
COMMENT ON COLUMN "SnapTransformer".tap_t2 IS $md$
Record date of Tap changer Events of tap `t2` (lower voltage side).
$md$;
COMMENT ON COLUMN "SnapTransformer".tap_t2_timestamp IS $md$
Time stamp of parameter change event of tap `t2` (lower voltage side, Symbol: `t`).
$md$;
COMMENT ON COLUMN "SnapTransformer".tap_t2_record_date IS $md$
Record date of parameter change event of tap `t2` (lower voltage side).
$md$;
COMMENT ON COLUMN "SnapTransformer".tap_t2_value_source IS $md$
Whether the tap event is determined after estimation or it is logged by scada for tap `t2` (lower voltage side); `eventsource` is the type of this column, which is one of the following: `autoRaw`, `manualRaw`, `digitaltwin`.
$md$;
COMMENT ON COLUMN "SnapTransformer".taps_t1 IS $md$
Possible tap values for the tap `t1` of the transformer.
$md$;
COMMENT ON COLUMN "SnapTransformer".taps_t2 IS $md$
Possible tap values for the tap `t2` of the transformer.
$md$;
COMMENT ON COLUMN "SnapTransformer".geo IS $md$
Latitude and Longitude of the `Transformer` location (Unit: `WGS84`).
$md$;
COMMENT ON COLUMN "SnapTransformer".name IS $md$
Human readable name of the `Transformer` determined by this row.
$md$;
COMMENT ON COLUMN "SnapTransformer".t1_phases IS $md$
Represents the normal network phasing condition at `t1` side. `phases` is the type of this column, which is one of the following values: `ABC`, `ABCn`, `An`, `Bn`, `Cn`, `AB`, `BC`, `AC`.
$md$;
COMMENT ON COLUMN "SnapTransformer".t2_phases IS $md$
Represents the normal network phasing condition at `t2` side. `phases` is the type of this column, which is one of the following values: `ABC`, `ABCn`, `An`, `Bn`, `Cn`, `AB`, `BC`, `AC`.
$md$;
COMMENT ON COLUMN "SnapTransformer".gm_fk IS $md$
The uuid of the `GroupMapping` that represents the relationship among a number of `Transformer` across abstraction.
$md$;
COMMENT ON COLUMN "SnapTransformer".param_timestamp IS $md$
Time stamp of parameter change event (Symbol: `t`).
$md$;
COMMENT ON COLUMN "SnapTransformer".param_record_date IS $md$
Record date of parameter change event.
$md$;
COMMENT ON COLUMN "SnapTransformer".param_value_source IS $md$
Whether the parameter event is determined after calculation or it is based on nominal values; `eventsource` is the type of this column, which is one of the following: `autoRaw`, `manualRaw`, `digitaltwin`.
$md$;
COMMENT ON COLUMN "SnapTransformer".b IS $md$
Magnetizing branch susceptance (B mag) at fundamental frequency at the lower voltage side. The value can be positive or negative (Symbol: `B_trf`, Unit: `mho`).
$md$;
COMMENT ON COLUMN "SnapTransformer".b0 IS $md$
Zero sequence magnetizing branch susceptance at the lower voltage side (Symbol: `B0_trf`, Unit: `mho`).
$md$;
COMMENT ON COLUMN "SnapTransformer".g IS $md$
Magnetizing branch conductance at the lower voltage side of transformer (Symbol: `G_trf`, Unit: `mho`).
$md$;
COMMENT ON COLUMN "SnapTransformer".g0 IS $md$
Zero sequence magnetizing branch conductance (star-model) at the lower voltage side (Symbol: `G0_trf`, Unit: `mho`).
$md$;
COMMENT ON COLUMN "SnapTransformer".r IS $md$
Resistance (star-model) of the transformer at the lower voltage side. The attribute shall be equal or greater than zero for non-equivalent transformers (Symbol: `R_trf`, Unit: `Ohms`).
$md$;
COMMENT ON COLUMN "SnapTransformer".r0 IS $md$
Zero sequence series resistance (star-model) at the lower voltage side (Symbol: `R0_trf`, Unit: `Ohms`).
$md$;
COMMENT ON COLUMN "SnapTransformer".x IS $md$
Positive sequence series reactance (star-model) at fundamental frequency at the lower voltage side (Symbol: `X_trf`, Unit: `Ohms`).
$md$;
COMMENT ON COLUMN "SnapTransformer".x0 IS $md$
Zero sequence series reactance at the lower voltage side (Symbol: `X0_trf`, Unit: `Ohms`).
$md$;

create view "SnapSwitch" as
	select
		eqs.*,
		eq.geo, eq.name,
		t1.phases as t1_phases, t2.phases as t2_phases,
		egm.gm_fk,
		se.timestamp, se.record_date, se.value_source,
		se.open
	from main."Switch" eqs
	left join lateral (
		select ev.*
		from main."SnapSwitchEvent"('infinity') ev
		where ev.eq_fk = eqs.uuid
	) se on true
	left join main."EquipmentGroupMapping" egm on eqs.uuid = egm.eq_fk and egm.is_sink
	inner join main."Equipment" eq on eqs.uuid = eq.uuid
	inner join main."Terminal" t1 on eqs.uuid = t1.eq_fk and t1.side = 't1'
	inner join main."Terminal" t2 on eqs.uuid = t2.eq_fk and t2.side = 't2';
alter view "SnapSwitch" alter t1_phases set default 'ABCn';
alter view "SnapSwitch" alter t2_phases set default 'ABCn';
alter view "SnapSwitch" alter value_source set default 'manualRaw';
CREATE FUNCTION switch_insert() RETURNS trigger AS $$
    begin
	    insert into main."Equipment" select NEW.uuid, 'switch', NEW.geo, NEW.name;
	    insert into main."Switch" select new.uuid, new.normal_open, new.controllable;
	    insert into main."Terminal" select new.uuid, 't1', new.t1_phases;
	    insert into main."Terminal" select new.uuid, 't2', new.t2_phases;
	    insert into main."SwitchEvent"(timestamp, record_date, value_source, eq_fk, open)
	   		select new.timestamp, new.record_date, 'manualRaw', new.uuid, coalesce(new.open, new.normal_open);
	    insert into main."EquipmentGroupMapping"(eq_fk, gm_fk, is_sink) select new.uuid, new.gm_fk, true;
	    return null;
    END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER switch_insert
    instead OF INSERT ON "SnapSwitch"
    FOR EACH ROW
    EXECUTE FUNCTION switch_insert();
CREATE OR REPLACE FUNCTION "SnapSwitch"(t timestamp) RETURNS SETOF "SnapSwitch" as $$
	select
		eqs.*,
		eq.geo, eq.name,
		t1.phases as t1_phases, t2.phases as t2_phases,
		egm.gm_fk,
		se.timestamp, se.record_date, se.value_source,
		se.open
	from main."Switch" eqs
	left join lateral (
		select ev.*
		from main."SnapSwitchEvent"($1) ev
		where ev.eq_fk = eqs.uuid
	) se on true
	left join main."EquipmentGroupMapping" egm on eqs.uuid = egm.eq_fk and egm.is_sink
	inner join main."Equipment" eq on eqs.uuid = eq.uuid
	inner join main."Terminal" t1 on eqs.uuid = t1.eq_fk and t1.side = 't1'
	inner join main."Terminal" t2 on eqs.uuid = t2.eq_fk and t2.side = 't2'
	where eqs.uuid in (SELECT eq_fk FROM main."SnapConnectivity"($1))
$$ language sql stable;
COMMENT ON VIEW "SnapSwitch" IS $md$
A view to insert data into the table of `Switch` and all associated tables if we we want to insert new `Switch`.
$md$;
COMMENT ON COLUMN "SnapSwitch".uuid IS $md$
The uuid of the switch determined by this row.
$md$;
COMMENT ON COLUMN "SnapSwitch".normal_open IS $md$
Normal state of the switch (Symbol: `u0_s`); `False`: close, `True`: open.
$md$;
COMMENT ON COLUMN "SnapSwitch".controllable IS $md$
Type of switch. `controllable` is the type of this column, which is one of the following values: `manualOffLoad`, `manualOnLoad`, `autoOffLoad`, `autoOnLoad`, `no`.
**Remark:** Switch is `manualOffLoad`, Breaker is `autoOnLoad` or `manualOnLoad`, Sectionalizer is `autoOffLoad` or `manualOffLoad`, Fuse is `no`.
$md$;
COMMENT ON COLUMN "SnapSwitch".geo IS $md$
Latitude and Longitude of the `Switch` location (Unit: `WGS84`).
$md$;
COMMENT ON COLUMN "SnapSwitch".name IS $md$
Human readable name of the `Switch` determined by this row.
$md$;
COMMENT ON COLUMN "SnapSwitch".t1_phases IS $md$
Represents the normal network phasing condition at `t1` side. `phases` is the type of this column, which is one of the following values: `ABC`, `ABCn`, `An`, `Bn`, `Cn`, `AB`, `BC`, `AC`.
$md$;
COMMENT ON COLUMN "SnapSwitch".t2_phases IS $md$
Represents the normal network phasing condition at `t2` side. `phases` is the type of this column, which is one of the following values: `ABC`, `ABCn`, `An`, `Bn`, `Cn`, `AB`, `BC`, `AC`.
$md$;
COMMENT ON COLUMN "SnapSwitch".gm_fk IS $md$
The uuid of the `GroupMapping` that represents the relationship among a number of `Switch` across abstraction.
$md$;
COMMENT ON COLUMN "SnapSwitch".timestamp IS $md$
Time stamp of switch change event (Symbol: `t`).
$md$;
COMMENT ON COLUMN "SnapSwitch".record_date IS $md$
Record date of switch change event.
$md$;
COMMENT ON COLUMN "SnapSwitch".value_source IS $md$
Whether the switch event is determined after estimation or it is logged by scada; `eventsource` is the type of this column, which is one of the following: `autoRaw`, `manualRaw`, `digitaltwin`.
$md$;
COMMENT ON COLUMN "SnapSwitch".open IS $md$
The new status of switches after the change. Only for switches that changed; It is `True` if the status changed to Open and `False` otherwise (Symbol: `u_sw`).
$md$;

create view "SnapEnergyConsumer" as
	select
		eqs.*,
		eq.geo, eq.name,
		t.phases as phases,
		egm.gm_fk
	from "EnergyConsumer" eqs
	left join "EquipmentGroupMapping" egm on eqs.uuid = egm.eq_fk and egm.is_sink
	inner join "Equipment" eq on eqs.uuid = eq.uuid
	inner join "Terminal" t on eqs.uuid = t.eq_fk;
alter view "SnapEnergyConsumer" alter phases set default 'ABCn';
CREATE FUNCTION energyConsumer_insert() RETURNS trigger AS $$
    begin
	    insert into "Equipment" select NEW.uuid, 'energyConsumer', NEW.geo, NEW.name;
	    insert into "EnergyConsumer" select new.uuid, new.rated_s, new.profile_type;
	    insert into "Terminal" select new.uuid, 't', new.phases;
	    insert into "EquipmentGroupMapping"(eq_fk, gm_fk, is_sink) select new.uuid, new.gm_fk, true;
	    return null;
    END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER energyConsumer_insert
    instead OF INSERT ON "SnapEnergyConsumer"
    FOR EACH ROW
    EXECUTE FUNCTION energyConsumer_insert();
CREATE OR REPLACE FUNCTION "SnapEnergyConsumer"(t timestamp) RETURNS SETOF "SnapEnergyConsumer" as $$
	select seq.*
	from main."SnapEnergyConsumer" seq
	where seq.uuid in (SELECT eq_fk FROM main."SnapConnectivity"($1))
$$ language sql stable;
COMMENT ON VIEW "SnapEnergyConsumer" IS $md$
A view to insert data into the table of `EnergyConsumer` and all associated tables if we we want to insert new `EnergyConsumer`.
$md$;
COMMENT ON COLUMN "SnapEnergyConsumer".uuid IS $md$
The uuid of the `EnergyConsumer` determined by this row.
$md$;
COMMENT ON COLUMN "SnapEnergyConsumer".rated_s IS $md$
Nominal apparent power of `EnergyConsumer` (Symbol: `S_ec_nom`, Unit: `kVA`).
$md$;
COMMENT ON COLUMN "SnapEnergyConsumer".profile_type IS $md$
Profile type of the `EnergyConsumer`; `profiletype` is the type of this column, which is one of the following values: `residential`, `commercial`, `industrial`.
$md$;
COMMENT ON COLUMN "SnapEnergyConsumer".geo IS $md$
Latitude and Longitude of the `EnergyConsumer` location (Unit: `WGS84`).
$md$;
COMMENT ON COLUMN "SnapEnergyConsumer".name IS $md$
Human readable name of the `EnergyConsumer` determined by this row.
$md$;
COMMENT ON COLUMN "SnapEnergyConsumer".phases IS $md$
Represents the normal network phasing condition of `EnergyConsumer`. `phases` is the type of this column, which is one of the following values: `ABC`, `ABCn`, `An`, `Bn`, `Cn`, `AB`, `BC`, `AC`.
$md$;
COMMENT ON COLUMN "SnapEnergyConsumer".gm_fk IS $md$
The uuid of the `GroupMapping` that represents the relationship among a number of `EnergyConsumer` across abstraction.
$md$;

create view "SnapSynchronousGenerationUnit" as
	select
		eqs.*,
		eq.geo, eq.name,
		t.phases as phases,
		egm.gm_fk
	from "SynchronousGenerationUnit" eqs
	left join "EquipmentGroupMapping" egm on eqs.uuid = egm.eq_fk and egm.is_sink
	inner join "Equipment" eq on eqs.uuid = eq.uuid
	inner join "Terminal" t on eqs.uuid = t.eq_fk;
alter view "SnapSynchronousGenerationUnit" alter phases set default 'ABCn';
CREATE FUNCTION synchronousGenerationUnit_insert() RETURNS trigger AS $$
    begin
	    insert into "Equipment" select NEW.uuid, 'synchronousGenerationUnit', NEW.geo, NEW.name;
	    insert into "SynchronousGenerationUnit" select new.uuid, new.max_operating_p, new.min_operating_p, new.rated_s;
	    insert into "Terminal" select new.uuid, 't', new.phases;
	    insert into "EquipmentGroupMapping"(eq_fk, gm_fk, is_sink) select new.uuid, new.gm_fk, true;
	    return null;
    END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER synchronousGenerationUnit_insert
    instead OF INSERT ON "SnapSynchronousGenerationUnit"
    FOR EACH ROW
    EXECUTE FUNCTION synchronousGenerationUnit_insert();
CREATE OR REPLACE FUNCTION "SnapSynchronousGenerationUnit"(t timestamp) RETURNS SETOF "SnapSynchronousGenerationUnit" as $$
	select seq.*
	from main."SnapSynchronousGenerationUnit" seq
	where seq.uuid in (SELECT eq_fk FROM main."SnapConnectivity"($1))
$$ language sql stable;
COMMENT ON VIEW "SnapSynchronousGenerationUnit" IS $md$
A view to insert data into the table of `SynchronousGenerationUnit` and all associated tables if we we want to insert new `SynchronousGenerationUnit`.
$md$;
COMMENT ON COLUMN "SnapSynchronousGenerationUnit".uuid IS $md$
The uuid of the `SynchronousGenerationUnit` determined by this row.
$md$;
COMMENT ON COLUMN "SnapSynchronousGenerationUnit".rated_s IS $md$
Maximum apparent power of the generation unit (Symbol: `S_dg_nom`, Unit: `kVA`).
$md$;
COMMENT ON COLUMN "SnapSynchronousGenerationUnit".min_operating_p IS $md$
Minimum active power of generating unit (Symbol: `P_dg_min`, Unit: `kW`).
$md$;
COMMENT ON COLUMN "SnapSynchronousGenerationUnit".max_operating_p IS $md$
Maximum active power of generating unit (Symbol: `P_dg_max`, Unit: `kW`).
$md$;
COMMENT ON COLUMN "SnapSynchronousGenerationUnit".geo IS $md$
Latitude and Longitude of the `SynchronousGenerationUnit` location (Unit: `WGS84`).
$md$;
COMMENT ON COLUMN "SnapSynchronousGenerationUnit".name IS $md$
Human readable name of the `SynchronousGenerationUnit` determined by this row.
$md$;
COMMENT ON COLUMN "SnapSynchronousGenerationUnit".phases IS $md$
Represents the normal network phasing condition of `SynchronousGenerationUnit`. `phases` is the type of this column, which is one of the following values: `ABC`, `ABCn`, `An`, `Bn`, `Cn`, `AB`, `BC`, `AC`.
$md$;
COMMENT ON COLUMN "SnapSynchronousGenerationUnit".gm_fk IS $md$
The uuid of the `GroupMapping` that represents the relationship among a number of `SynchronousGenerationUnit` across abstraction.
$md$;

create view "SnapBess" as
	select
		eqs.*,
		eq.geo, eq.name,
		t.phases as phases,
		egm.gm_fk
	from "Bess" eqs
	left join "EquipmentGroupMapping" egm on eqs.uuid = egm.eq_fk and egm.is_sink
	inner join "Equipment" eq on eqs.uuid = eq.uuid
	inner join "Terminal" t on eqs.uuid = t.eq_fk;
alter view "SnapBess" alter charging_eff set default '1';
alter view "SnapBess" alter discharging_eff set default '1';
alter view "SnapBess" alter phases set default 'ABCn';
CREATE FUNCTION bess_insert() RETURNS trigger AS $$
    begin
	    insert into "Equipment" select NEW.uuid, 'bess', NEW.geo, NEW.name;
	    insert into "Bess" select new.uuid, new.charging_eff, new.discharging_eff, new.max_charging_p, new.max_discharging_p, new.min_charging_p, new.min_discharging_p, new.rated_e, new.rated_s;
	    insert into "Terminal" select new.uuid, 't', new.phases;
	    insert into "EquipmentGroupMapping"(eq_fk, gm_fk, is_sink) select new.uuid, new.gm_fk, true;
	    return null;
    END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER bess_insert
    instead OF INSERT ON "SnapBess"
    FOR EACH ROW
    EXECUTE FUNCTION bess_insert();
CREATE OR REPLACE FUNCTION "SnapBess"(t timestamp) RETURNS SETOF "SnapBess" as $$
	select seq.*
	from main."SnapBess" seq
	where seq.uuid in (SELECT eq_fk FROM main."SnapConnectivity"($1))
$$ language sql stable;
COMMENT ON VIEW "SnapBess" IS $md$
A view to insert data into the table of `BESS` and all associated tables if we we want to insert new `BESS`.
$md$;
COMMENT ON COLUMN "SnapBess".uuid IS $md$
The uuid of the `BESS` determined by this row.
$md$;
COMMENT ON COLUMN "SnapBess".charging_eff IS $md$
Charging efficiency in percentage (Symbol: `Eta_bess_ch`, Unit: `%`).
$md$;
COMMENT ON COLUMN "SnapBess".discharging_eff IS $md$
Discharging efficiency in percentage (Symbol: `Eta_bess_dch`, Unit: `%`).
$md$;
COMMENT ON COLUMN "SnapBess".rated_s IS $md$
maximum apparent power of BESS inverter (Symbol: `S_bess_nom`, Unit: `kVA`).
$md$;
COMMENT ON COLUMN "SnapBess".rated_e IS $md$
Nominal capacity (Symbol: `E_bess_nom`, Unit: `kW`).
$md$;
COMMENT ON COLUMN "SnapBess".min_charging_p IS $md$
Minimum charging power (Symbol: `P_bess_ch_min`, Unit: `kW`).
$md$;
COMMENT ON COLUMN "SnapBess".max_charging_p IS $md$
Maximum charging power (Symbol: `P_bess_ch_max`, Unit: `kW`).
$md$;
COMMENT ON COLUMN "SnapBess".min_discharging_p IS $md$
Minimum discharging power (Symbol: `P_bess_dch_min`, Unit: `kW`).
$md$;
COMMENT ON COLUMN "SnapBess".max_discharging_p IS $md$
Maximum discharging power (Symbol: `P_bess_dch_max`, Unit: `kW`).
$md$;
COMMENT ON COLUMN "SnapBess".geo IS $md$
Latitude and Longitude of the `BESS` location (Unit: `WGS84`).
$md$;
COMMENT ON COLUMN "SnapBess".name IS $md$
Human readable name of the `BESS` determined by this row.
$md$;
COMMENT ON COLUMN "SnapBess".phases IS $md$
Represents the normal network phasing condition of `BESS`. `phases` is the type of this column, which is one of the following values: `ABC`, `ABCn`, `An`, `Bn`, `Cn`, `AB`, `BC`, `AC`.
$md$;
COMMENT ON COLUMN "SnapBess".gm_fk IS $md$
The uuid of the `GroupMapping` that represents the relationship among a number of `BESS` across abstraction.
$md$;

create view "SnapExternalNetwork" as
	select
		eqs.*,
		eq.geo, eq.name,
		t.phases as phases,
		egm.gm_fk
	from "ExternalNetwork" eqs
	left join "EquipmentGroupMapping" egm on eqs.uuid = egm.eq_fk and egm.is_sink
	inner join "Equipment" eq on eqs.uuid = eq.uuid
	inner join "Terminal" t on eqs.uuid = t.eq_fk;
alter view "SnapExternalNetwork" alter r_eq set default 0;
alter view "SnapExternalNetwork" alter x_eq set default 0;
alter view "SnapExternalNetwork" alter phases set default 'ABCn';
CREATE FUNCTION externalNetwork_insert() RETURNS trigger AS $$
    begin
	    insert into "Equipment" select NEW.uuid, 'externalNetwork', NEW.geo, NEW.name;
	    insert into "ExternalNetwork" select new.uuid, new.r_eq, new.x_eq;
	    insert into "Terminal" select new.uuid, 't', new.phases;
	    insert into "EquipmentGroupMapping"(eq_fk, gm_fk, is_sink) select new.uuid, new.gm_fk, true;
	    return null;
    END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER externalNetwork_insert
    instead OF INSERT ON "SnapExternalNetwork"
    FOR EACH ROW
    EXECUTE FUNCTION externalNetwork_insert();
CREATE OR REPLACE FUNCTION "SnapExternalNetwork"(t timestamp) RETURNS SETOF "SnapExternalNetwork" as $$
	select seq.*
	from main."SnapExternalNetwork" seq
	where seq.uuid in (SELECT eq_fk FROM main."SnapConnectivity"($1))
$$ language sql stable;
COMMENT ON VIEW "SnapExternalNetwork" IS $md$
A view to insert data into the table of `ExternalNetwork` and all associated tables if we we want to insert new `ExternalNetwork`.
$md$;
COMMENT ON COLUMN "SnapExternalNetwork".uuid IS $md$
The uuid of the `ExternalNetwork` determined by this row.
$md$;
COMMENT ON COLUMN "SnapExternalNetwork".r_eq IS $md$
The equivalent resistance of External Network to consider multiple upstream networks (Symbol: `R_ex_eq`, Unit: `Ohms`).
$md$;
COMMENT ON COLUMN "SnapExternalNetwork".x_eq IS $md$
The equivalent inductance of External Network to consider multiple upstream networks (Symbol: `X_eq_eq`, Unit: `Ohms`).
$md$;
COMMENT ON COLUMN "SnapExternalNetwork".geo IS $md$
Latitude and Longitude of the `ExternalNetwork` location (Unit: `WGS84`).
$md$;
COMMENT ON COLUMN "SnapExternalNetwork".name IS $md$
Human readable name of the `ExternalNetwork` determined by this row.
$md$;
COMMENT ON COLUMN "SnapExternalNetwork".phases IS $md$
Represents the normal network phasing condition of `ExternalNetwork`. `phases` is the type of this column, which is one of the following values: `ABC`, `ABCn`, `An`, `Bn`, `Cn`, `AB`, `BC`, `AC`.
$md$;
COMMENT ON COLUMN "SnapExternalNetwork".gm_fk IS $md$
The uuid of the `GroupMapping` that represents the relationship among a number of `ExternalNetwork` across abstraction.
$md$;

create view "SnapPv" as
	select
		eqs.*,
		eq.geo, eq.name,
		t.phases as phases,
		egm.gm_fk
	from "Pv" eqs
	left join "EquipmentGroupMapping" egm on eqs.uuid = egm.eq_fk and egm.is_sink
	inner join "Equipment" eq on eqs.uuid = eq.uuid
	inner join "Terminal" t on eqs.uuid = t.eq_fk;
alter view "SnapPv" alter phases set default 'ABCn';
alter view "SnapPv" alter cos_phi_limit set default 1;
CREATE FUNCTION pv_insert() RETURNS trigger AS $$
    begin
	    insert into "Equipment" select NEW.uuid, 'pv', NEW.geo, NEW.name;
	    insert into "Pv" select new.uuid, new.cos_phi_limit, new.rated_s;
	    insert into "Terminal" select new.uuid, 't', new.phases;
	    insert into "EquipmentGroupMapping"(eq_fk, gm_fk, is_sink) select new.uuid, new.gm_fk, true;
	    return null;
    END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER pv_insert
    instead OF INSERT ON "SnapPv"
    FOR EACH ROW
    EXECUTE FUNCTION pv_insert();
CREATE OR REPLACE FUNCTION "SnapPv"(t timestamp) RETURNS SETOF "SnapPv" as $$
	select seq.*
	from main."SnapPv" seq
	where seq.uuid in (SELECT eq_fk FROM main."SnapConnectivity"($1))
$$ language sql stable;
COMMENT ON VIEW "SnapPv" IS $md$
A view to insert data into the table of `Pv` and all associated tables if we we want to insert new `Pv`.
$md$;
COMMENT ON COLUMN "SnapPv".uuid IS $md$
The uuid of the `Pv` determined by this row.
$md$;
COMMENT ON COLUMN "SnapPv".cos_phi_limit IS $md$
Power factor limit of the photovoltaic system (Symbol: `Pf_pv_limit`).
$md$;
COMMENT ON COLUMN "SnapPv".rated_s IS $md$
Maximum apparent power of PV inverter (Symbol: `S_pv_nom`, Unit: `kVA`).
$md$;
COMMENT ON COLUMN "SnapPv".geo IS $md$
Latitude and Longitude of the `Pv` location (Unit: `WGS84`).
$md$;
COMMENT ON COLUMN "SnapPv".name IS $md$
Human readable name of the `Pv` determined by this row.
$md$;
COMMENT ON COLUMN "SnapPv".phases IS $md$
Represents the normal network phasing condition of `Pv`. `phases` is the type of this column, which is one of the following values: `ABC`, `ABCn`, `An`, `Bn`, `Cn`, `AB`, `BC`, `AC`.
$md$;
COMMENT ON COLUMN "SnapPv".gm_fk IS $md$
The uuid of the `GroupMapping` that represents the relationship among a number of `Pv` across abstraction.
$md$;
