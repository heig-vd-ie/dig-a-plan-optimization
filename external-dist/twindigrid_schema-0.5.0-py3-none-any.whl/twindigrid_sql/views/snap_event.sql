CREATE OR REPLACE FUNCTION "SnapHeartbeat"(t timestamp) RETURNS SETOF "Heartbeat" as $$
	SELECT *
    FROM main."Heartbeat"
    WHERE start_date <= $1
    ORDER BY start_date DESC
    LIMIT 1
$$ language sql stable;

CREATE OR REPLACE FUNCTION "SnapBranchParameterEvent"(t timestamp) RETURNS SETOF "BranchParameterEvent" as $$
	select distinct on (ev.eq_fk) ev.*
    from main."BranchParameterEvent" ev
    where ev.record_date <= $1
    order by
        ev.eq_fk,
        ev.value_source_priority asc,
        ev.record_date desc
$$ language sql stable;

CREATE OR REPLACE FUNCTION "SnapTransformerParameterEvent"(t timestamp) RETURNS SETOF "TransformerParameterEvent" as $$
	select distinct on (ev.eq_fk) ev.*
    from main."TransformerParameterEvent" ev
    where ev.record_date <= $1
    order by
        ev.eq_fk,
        ev.value_source_priority asc,
        ev.record_date desc
$$ language sql stable;

CREATE OR REPLACE FUNCTION "SnapTapEvent"(t timestamp) RETURNS SETOF "TapEvent" as $$
	select distinct on (ev.eq_fk, ev.is_tap_t1) ev.*
    from main."TapEvent" ev
    where ev.record_date <= $1
    order by
        ev.eq_fk,
        ev.is_tap_t1,
        ev.value_source_priority asc,
        ev.record_date desc
$$ language sql stable;

CREATE OR REPLACE FUNCTION "SnapSwitchEvent"(t timestamp) RETURNS SETOF "SwitchEvent" as $$
	select distinct on (ev.eq_fk) ev.*
    from main."SwitchEvent" ev
    where ev.record_date <= $1
    order by
        ev.eq_fk,
        ev.value_source_priority asc,
        ev.record_date desc
$$ language sql stable;
