CREATE TABLE "Abstraction" (
	uuid uuid NOT NULL PRIMARY KEY,
	name varchar NOT NULL,
	parent_fk uuid REFERENCES "Abstraction"(uuid)-- to know from which abstraction to inherit the connectivity
);
CREATE INDEX ON "Abstraction" (parent_fk) INCLUDE (uuid);
COMMENT ON TABLE "Abstraction" IS $md$

It contains the abstraction layer and inheritance.
In following figures, we present two examples. The first one is where a number of series `Branch` and `BusbarSection` aggregated to one `Branch`. The second one is where a zero length `Branch` is removed and two `BusbarSection` at both ends will be aggregated to one `BusbarSection`.

<p align="center">
<img src="/assets/schema/abstraction_terminalMapping.svg" alt="Figure with an example of a terminal mapping" width="500" />
</p>
<p align="center" style="font-size:90%"><i>
First example of abstraction.
</i></p>
---
<p align="center">
<img src="/assets/schema/abstraction_cnMapping.svg" alt="Figure with an example of a connectivity node mapping" width="500" />
</p>
<p align="center" style="font-size:90%"><i>
Second example of abstraction.
</i></p>
---
<strong>Remark:</strong> The object `Abstraction` is defined to individuate among `Equipment`, `Terminal`, `ConnectivityNode`, and `TopologicalNode` in the `physical` and `abstract` models. Note that it is possible one `Equipment` or `Terminal` is in both layers.
$md$;
COMMENT ON COLUMN "Abstraction".uuid IS $md$
The uuid of the abstraction determined by this row.
$md$;
COMMENT ON COLUMN "Abstraction".name IS $md$
Human readable name of the abstraction determined by this row.
$md$;
COMMENT ON COLUMN "Abstraction".parent_fk IS $md$
The uuid of the parent abstraction. It indicates that the abstraction determined by this row inherits by default the equipment and connectivity of its parent abstraction.

<strong>Remark:</strong> When this columns is null, the abstraction layer is a base `physical` layer.
$md$;

-- Also stores a single group mapping for each root ("physical") abstraction (using same id as the abstraction). This allows retrieving the base abstraction of an equipment.
-- CONSTRAINT: equipment MUST always keep the same base abstraction.
create table "GroupMapping"(
	uuid uuid primary key,
	-- abstraction of sink group
	-- do not store abstraction of source group as equipment could be from multiple abstraction layer
	-- CONSTRAINT: source equipment MUST BE from a parent abstraction layer
	-- equipment not based in root abstraction MUST BE sink of a group mapping
	abstraction_fk uuid not null references "Abstraction"(uuid),
	-- can't store in connectivity because could have multiple mapping in a equipment lifetime
	-- CONSTRAINT: composed equipment should not be uninstalled
	-- TODO: allow groupMapping to be installed multiple time?
	record_install_date timestamp NOT NULL,
	record_uninstall_date timestamp CHECK(record_uninstall_date > record_install_date or record_uninstall_date is null)
	-- TODO: if required for performance reason add an hash column based on an ordered list of source equipment
);
COMMENT ON TABLE "GroupMapping" IS $md$

It contains the group mapping that allow mapping of `Equipment`, `Terminal` and `ConnectivityNode` across abstraction.
It is also used to indicate the abstraction layer that the equipment has been created. Therefore, all the `Equipment`, `Terminal` and `ConnectivityNode` in the root abstraction layers have a single group.
In following figures, we present two examples. The first one is where a number of series `Branch` and `BusbarSection` aggregated to one `Branch`. The second one is where a zero length `Branch` is removed and two `BusbarSection` at both ends will be aggregated to one `BusbarSection`.

<p align="center">
<img src="/assets/schema/abstraction_terminalMapping.svg" alt="Figure with an example of a terminal mapping" width="500" />
</p>
<p align="center" style="font-size:90%"><i>
First example of GroupMapping.
</i></p>
---
<p align="center">
<img src="/assets/schema/abstraction_cnMapping.svg" alt="Figure with an example of a connectivity node mapping" width="500" />
</p>
<p align="center" style="font-size:90%"><i>
Second example of GroupMapping.
</i></p>
---
<strong>Remark:</strong>  The object `GroupMapping` is added to keep the dependency among abstract and physical `Equipment`, `Terminal`, and `ConnectivityNode`. With this table, we can easily derive that each abstract `Equipment` is resulted from which physical one.
$md$;
COMMENT ON COLUMN "GroupMapping".uuid IS $md$
The uuid of the group.
Has the same uuid as the abstraction when it's a root abstraction.
Otherwise, the uuid is derived from the target `Equipment`, `Terminal` or `ConnectivityNode`.
$md$;
COMMENT ON COLUMN "GroupMapping".abstraction_fk IS $md$
The uuid of the abstraction layer that `Equipment`, `Terminal` or `ConnectivityNode` has been created.
$md$;
COMMENT ON COLUMN "GroupMapping".record_install_date IS $md$
Record installation date of the `Equipment`, `Terminal` or `ConnectivityNode`, for example when the new abstract equipment is installed based on a number of the root abstraction equipment.
$md$;
COMMENT ON COLUMN "GroupMapping".record_uninstall_date IS $md$
Record uninstallation date of the `Equipment`, `Terminal` or `ConnectivityNode` in the group, for example when one of the root abstraction equipment is uninstalled and then the abstract equipment must be no longer connected to the network.
$md$;

create table "EquipmentGroupMapping"(
	eq_fk uuid not null references "Equipment"(uuid),
	gm_fk uuid not null references "GroupMapping"(uuid),
	is_sink bool not null,
	primary key(eq_fk, gm_fk)
);
CREATE INDEX "EquipmentGroupMapping_sink_eq_idx" ON "EquipmentGroupMapping"(is_sink, eq_fk) INCLUDE (gm_fk);
COMMENT ON TABLE "EquipmentGroupMapping" IS $md$
Contains the group mapping that allow mapping of `Equipment` across abstraction.
$md$;
COMMENT ON COLUMN "EquipmentGroupMapping".eq_fk IS $md$
The uuid of the `Equipment` that is in this group mapping.
$md$;
COMMENT ON COLUMN "EquipmentGroupMapping".gm_fk IS $md$
The uuid of the `GroupMapping` that represents the relationship among a number of `Equipment` across abstraction.
$md$;
COMMENT ON COLUMN "EquipmentGroupMapping".is_sink IS $md$
Relation of equipment and group is determined with this attribute; `True` when `Equipment` is the sink and `False` when `Equipment` is source.
$md$;

create table "TerminalMapping"(
	gm_fk uuid not null references "GroupMapping"(uuid),
	source_eq_fk uuid not null references "Equipment"(uuid),
	source_side snap.terminalside NOT NULL,
	sink_eq_fk uuid not null references "Equipment"(uuid),
	sink_side snap.terminalside NOT NULL,
	primary key (source_eq_fk, source_side, gm_fk),
	foreign key (source_eq_fk, source_side) references "Terminal"(eq_fk, side),
	foreign key (sink_eq_fk, sink_side) references "Terminal"(eq_fk, side)
);
COMMENT ON TABLE "TerminalMapping" IS $md$
Contains the group mapping that allow mapping of `Terminal` across abstraction.

For a given group mapping, a source terminal can have only one sink terminal. If a modification to the grid changes the terminal mapping, then a new group mapping should be created.
$md$;
COMMENT ON COLUMN "TerminalMapping".gm_fk IS $md$
The uuid of the `GroupMapping` that represents the relationship among a number of `Terminal` across abstraction.
$md$;
COMMENT ON COLUMN "TerminalMapping".source_eq_fk IS $md$
The uuid of the `Equipment` that its terminal is source of this group mapping.
$md$;
COMMENT ON COLUMN "TerminalMapping".source_side IS $md$
Side of the terminal that is source of this group mapping. Either `t1`, `t2`, or `t`.
$md$;
COMMENT ON COLUMN "TerminalMapping".sink_eq_fk IS $md$
The uuid of the `Equipment` that its terminal is sink of this group mapping.
$md$;
COMMENT ON COLUMN "TerminalMapping".sink_side IS $md$
Side of the terminal that is sink of this group mapping. Either `t1`, `t2`, or `t`.
$md$;

create table "CnMapping"(
	gm_fk uuid not null references "GroupMapping"(uuid),
	source_cn_fk uuid not null,
	sink_cn_fk uuid not null,
	primary key(source_cn_fk, sink_cn_fk)
);
COMMENT ON TABLE "CnMapping" IS $md$
Contains the group mapping that allow mapping of `ConnectivityNode` across abstraction.
$md$;
COMMENT ON COLUMN "CnMapping".gm_fk IS $md$
The uuid of the `GroupMapping` which represents the relationship among a number of `ConnectivityNode` across abstraction.
$md$;
COMMENT ON COLUMN "CnMapping".source_cn_fk IS $md$
The uuid of the `ConnectivityNode` that is source of this group mapping.
$md$;
COMMENT ON COLUMN "CnMapping".sink_cn_fk IS $md$
The uuid of the `ConnectivityNode` that is sink of this group mapping.
$md$;
