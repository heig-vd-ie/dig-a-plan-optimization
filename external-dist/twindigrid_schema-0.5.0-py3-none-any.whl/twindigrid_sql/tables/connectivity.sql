create table "Connectivity" (
	eq_fk uuid NOT null references "Equipment"(uuid),
	side snap.terminalside NOT NULL,
	-- generate an uuid for terminal to allow distinct on a single column
	terminal_uuid uuid generated always as (uuid_generate_v5(eq_fk, case when side = 't' then 0 when side = 't1' then 1 when side = 't2' then 2 end::text)) stored,
	concrete_type snap.equipmenttype NOT NULL,  -- redundant but avoid needing to always join with Equipment table
	abstraction_fk uuid not null references "Abstraction"(uuid),
	cn_fk uuid null, -- to simplify insertion, do not reference connectivityNode table (at least for the moment)
					-- can be null if a terminal is no longer connected for a given abstraction
	-- event time
	install_date timestamp NOT NULL,
	-- require an uninstallationDate because range can be superposed across abstraction
	uninstall_date timestamp CHECK(uninstall_date > install_date or uninstall_date is null),
	-- record time (required to know what's new, and to insure integrity as we don't correct the past)
	record_install_date timestamp NOT NULL CHECK(install_date <= record_install_date),
	record_uninstall_date timestamp CHECK(uninstall_date <= record_uninstall_date or record_uninstall_date is null),
	-- abstractionFK should be in primary key, because the same equipment be in multiple abstraction (with null cnFK)
	primary key (eq_fk, side, abstraction_fk, record_install_date),
	foreign key (eq_fk, side) references "Terminal"(eq_fk, side)
);
COMMENT ON TABLE "Connectivity" IS $md$
Record of connection information of `Terminal` and `ConnectivityNode` across all abstraction.
$md$;
COMMENT ON COLUMN "Connectivity".eq_fk IS $md$
The uuid of the `Equipment` that its terminal is connected in this row.
$md$;
COMMENT ON COLUMN "Connectivity".side IS $md$
Side of the `Equipment` (`Terminal`) that is connected in this row. Either `t1`, `t2`, or `t`.
$md$;
COMMENT ON COLUMN "Connectivity".terminal_uuid IS $md$
The uuid of the terminal that is connected in this row. It includes the `eq_fk` and side field
$md$;
COMMENT ON COLUMN "Connectivity".concrete_type IS $md$
It is used to determine the concrete equipment that is connected in this row; `equipmenttype` is the type of the equipment, which is one of the following values: `bess`, `branch`, `busbarSection`, `energyConsumer`, `externalNetwork`, `pv`, `switch`, `transformer`, `synchronousGenerationUnit`, `measurementDevice`.$md$;
COMMENT ON COLUMN "Connectivity".abstraction_fk IS $md$
The uuid of the abstraction layer that `Equipment` that its terminal is connected in this row.
$md$;
COMMENT ON COLUMN "Connectivity".cn_fk IS $md$
The uuid of the `ConnectivityNode` that the `Terminal` is connected to.
$md$;
COMMENT ON COLUMN "Connectivity".install_date IS $md$
Actual installation date of this connectivity.
$md$;
COMMENT ON COLUMN "Connectivity".uninstall_date IS $md$
Actual uninstallation date of this connectivity.
$md$;
COMMENT ON COLUMN "Connectivity".record_install_date IS $md$
Record installation date of this connectivity.
$md$;
COMMENT ON COLUMN "Connectivity".record_uninstall_date IS $md$
Record uninstall date of this connectivity.
$md$;

-- CHECK: no need to store abstraction as the topology should be the same for all abstraction
-- CHECK: store topology for CN with no switch?
-- TODO: function to generate or retrieve tnFK based on composed cnFK
-- TODO: maybe split topology (with date) from topologyCN
-- topologicalNode connects connectivity node together if they are separated by a closed switch
create table "Topology" (
	cn_fk uuid NOT null,
	tn_fk uuid not null,
	record_install_date timestamp NOT NULL,
	record_uninstall_date timestamp CHECK(record_uninstall_date > record_install_date or record_uninstall_date is null)
);
COMMENT ON TABLE "Topology" IS $md$
Record of topological connection information of `Terminal` and `TopologyNode` across all abstraction.
$md$;
COMMENT ON COLUMN "Topology".cn_fk IS $md$
The uuid of the `ConnectivityNode` that is connected to a topological connection this row.
$md$;
COMMENT ON COLUMN "Topology".tn_fk IS $md$
The uuid of the `TopologyNode` that the `ConnectivityNode` is connected to.
$md$;
COMMENT ON COLUMN "Topology".record_install_date IS $md$
Record installation date of this topological connection.
$md$;
COMMENT ON COLUMN "Topology".record_uninstall_date IS $md$
Record uninstall date of this topological connection.
$md$;

create table "ConnectedGroup" (
	uuid uuid primary key,
	name varchar,
	timestamp timestamp not null,
	-- if is_disconnected is false then the group is a mainGrid
	is_disconnected bool not null
);
COMMENT ON TABLE "ConnectedGroup" IS $md$
Area divided off from other areas and not connected to other groups. It may be part of the electrical network.
$md$;
COMMENT ON COLUMN "ConnectedGroup".uuid IS $md$
The uuid of the `ConnectedGroup` determined by this row.
$md$;
COMMENT ON COLUMN "ConnectedGroup".name IS $md$
Human readable name of the associated group determined by this row.
$md$;
COMMENT ON COLUMN "ConnectedGroup".timestamp IS $md$
Timestamp of the creation of the associated group determined by this row.
$md$;
COMMENT ON COLUMN "ConnectedGroup".is_disconnected IS $md$
If the associated group is disconnected from the main grid then `is_disconnected` is `False` otherwise `True`.
$md$;

create table "EquipmentConnectedGroup" (
	connected_group_fk uuid not null references "ConnectedGroup"(uuid),
	eq_fk uuid not null references "Equipment"(uuid),
	record_install_date timestamp not null,
	record_uninstall_date timestamp
);
COMMENT ON TABLE "EquipmentConnectedGroup" IS $md$
Relation of `Equipment` and `ConnectedGroup` over time.
$md$;
COMMENT ON COLUMN "EquipmentConnectedGroup".connected_group_fk IS $md$
The uuid of `ConnectedGroup` that the `Equipment` is connected to.
$md$;
COMMENT ON COLUMN "EquipmentConnectedGroup".eq_fk IS $md$
The uuid of the `Equipment`.
$md$;
COMMENT ON COLUMN "EquipmentConnectedGroup".record_install_date IS $md$
Record installation date of `Equipment` to the `ConnectedGroup`.
$md$;
COMMENT ON COLUMN "EquipmentConnectedGroup".record_uninstall_date IS $md$
Record uninstall date of `Equipment` to the `ConnectedGroup`.
$md$;
