CREATE TABLE "MeasurementSource" (
	uuid uuid primary key,
	name varchar NULL,
	metadata jsonb  -- may be used to store details about the measurement source, specially useful if it's ML model or forecasting
);
COMMENT ON TABLE "MeasurementSource" IS $md$
Table of all measurement sources.
$md$;
COMMENT ON COLUMN "MeasurementSource".uuid IS $md$
The uuid of the `MeasurementSource`.
$md$;
COMMENT ON COLUMN "MeasurementSource".name IS $md$
Human readable name of the `MeasurementSource`.
$md$;
COMMENT ON COLUMN "MeasurementSource".metadata IS $md$
It is used to store details about the `MeasurementSource`, specially useful if it is ML model or forecasting.
$md$;

CREATE TABLE "MeasurementDevice" (
	uuid uuid primary key references "Equipment"(uuid),
	accuracy_active_power float8 not null,
	accuracy_current float8 not null,
	accuracy_reactive_power float8 not null,
	accuracy_voltage float8 not null,
	rated_current float8 not null,
	aggregation_period float8 not null,
	value_source_fk uuid not null references "MeasurementSource"(uuid)
);
COMMENT ON TABLE "MeasurementDevice" IS $md$
Table of all measurement devices that are exist in the network, either physical or abstract ones.
$md$;
COMMENT ON COLUMN "MeasurementDevice".uuid IS $md$
The uuid of `MeasurementDevice`.
$md$;
COMMENT ON COLUMN "MeasurementDevice".accuracy_active_power IS $md$
The limit, expressed as a percentage of the sensor maximum, that accuracy would not less than when the sensor is used under reference conditions (Unit: `%`).
$md$;
COMMENT ON COLUMN "MeasurementDevice".accuracy_current IS $md$
The limit, expressed as a percentage of the sensor maximum, that accuracy would not less than when the sensor is used under reference conditions (Unit: `%`).
$md$;
COMMENT ON COLUMN "MeasurementDevice".accuracy_reactive_power IS $md$
The limit, expressed as a percentage of the sensor maximum, that accuracy would not less than when the sensor is used under reference conditions (Unit: `%`).
$md$;
COMMENT ON COLUMN "MeasurementDevice".accuracy_voltage IS $md$
The limit, expressed as a percentage of the sensor maximum, that accuracy would not less than when the sensor is used under reference conditions (Unit: `%`).
$md$;
COMMENT ON COLUMN "MeasurementDevice".aggregation_period IS $md$
Aggregation period of `MeasurementDevice`, e.g., 600 seconds or 60 seconds (Unit: `seconds`).
$md$;
COMMENT ON COLUMN "MeasurementDevice".rated_current IS $md$
Maximum current that measurement device can measure and the accuracies of current, active power, and reactive power are based on that (Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementDevice".value_source_fk IS $md$
The uuid of measurement source that this `MeasurementDevice` is associated with.
$md$;

-- CONSTRAINT: all terminal of a measurementDevice MUST be at the same location
CREATE TABLE "MeasurementTerminal" (
	uuid uuid primary key,
	measurement_device_fk uuid not null references "MeasurementDevice"(uuid),
	eq_fk uuid not null references "Equipment"(uuid),
	side snap.terminalside not null,
	-- TODO: add installation and uninstallation dates (with record)
	FOREIGN KEY (eq_fk, side) REFERENCES "Terminal"(eq_fk, side)
);
COMMENT ON TABLE "MeasurementTerminal" IS $md$
It captures the connection of `MeasurementDevice` and the corresponding `Terminal`.
<strong>Remark:</strong>  `MeasurementTerminal` is defined because of two reasons: (i) considering the case that a `MeasurementDevice` measures multiple terminals; and (ii) to easily distinguish between measured and non-measurement Terminals (because most of terminals are not measured).
$md$;
COMMENT ON COLUMN "MeasurementTerminal".uuid IS $md$
The uuid of the `MeasurementTerminal`.
$md$;
COMMENT ON COLUMN "MeasurementTerminal".measurement_device_fk IS $md$
The uuid of `MeasurementDevice` that is associated with this measurement.
$md$;
COMMENT ON COLUMN "MeasurementTerminal".eq_fk IS $md$
The uuid of the `Equipment` that its terminal is measured.
$md$;
COMMENT ON COLUMN "MeasurementTerminal".side IS $md$
Side of the `Equipment` (`Terminal`) that is measured by the `MeasurementDevice`.
$md$;

-- Do not split table per measurement unit, because often we need multiple unit at the same time
-- TODO: transform to hypertable
CREATE TABLE "MeasurementValue" (
	measurement_terminal_fk uuid not null references "MeasurementTerminal"(uuid),
    timestamp timestamp NOT NULL,
	-- allow alignment with heartbeat, allow forecasting of multiple values in the future
	record_date timestamp not null,
    avg_active_power_a float8 NULL,
	avg_active_power_b float8 NULL,
	avg_active_power_c float8 NULL,
	std_active_power_a float8 NULL,
	std_active_power_b float8 NULL,
	std_active_power_c float8 NULL,
	med_active_power_a float8 NULL,
	med_active_power_b float8 NULL,
	med_active_power_c float8 NULL,
	lq_active_power_a float8 NULL,
	lq_active_power_b float8 NULL,
	lq_active_power_c float8 NULL,
	uq_active_power_a float8 NULL,
	uq_active_power_b float8 NULL,
	uq_active_power_c float8 NULL,
	min_active_power_a float8 NULL,
	min_active_power_b float8 NULL,
	min_active_power_c float8 NULL,
	max_active_power_a float8 NULL,
	max_active_power_b float8 NULL,
	max_active_power_c float8 NULL,
	avg_current_a float8 NULL,
	avg_current_b float8 NULL,
	avg_current_c float8 NULL,
	std_current_a float8 NULL,
	std_current_b float8 NULL,
	std_current_c float8 NULL,
	med_current_a float8 NULL,
	med_current_b float8 NULL,
	med_current_c float8 NULL,
	lq_current_a float8 NULL,
	lq_current_b float8 NULL,
	lq_current_c float8 NULL,
	uq_current_a float8 NULL,
	uq_current_b float8 NULL,
	uq_current_c float8 NULL,
	min_current_a float8 NULL,
	min_current_b float8 NULL,
	min_current_c float8 NULL,
	max_current_a float8 NULL,
	max_current_b float8 NULL,
	max_current_c float8 NULL,
	avg_reactive_power_a float8 NULL,
	avg_reactive_power_b float8 NULL,
	avg_reactive_power_c float8 NULL,
	std_reactive_power_a float8 NULL,
	std_reactive_power_b float8 NULL,
	std_reactive_power_c float8 NULL,
	med_reactive_power_a float8 NULL,
	med_reactive_power_b float8 NULL,
	med_reactive_power_c float8 NULL,
	lq_reactive_power_a float8 NULL,
	lq_reactive_power_b float8 NULL,
	lq_reactive_power_c float8 NULL,
	uq_reactive_power_a float8 NULL,
	uq_reactive_power_b float8 NULL,
	uq_reactive_power_c float8 NULL,
	min_reactive_power_a float8 NULL,
	min_reactive_power_b float8 NULL,
	min_reactive_power_c float8 NULL,
	max_reactive_power_a float8 NULL,
	max_reactive_power_b float8 NULL,
	max_reactive_power_c float8 NULL,
	avg_voltage_a float8 NULL,
	avg_voltage_b float8 NULL,
	avg_voltage_c float8 NULL,
	std_voltage_a float8 NULL,
	std_voltage_b float8 NULL,
	std_voltage_c float8 NULL,
	med_voltage_a float8 NULL,
	med_voltage_b float8 NULL,
	med_voltage_c float8 NULL,
	lq_voltage_a float8 NULL,
	lq_voltage_b float8 NULL,
	lq_voltage_c float8 NULL,
	uq_voltage_a float8 NULL,
	uq_voltage_b float8 NULL,
	uq_voltage_c float8 NULL,
	min_voltage_a float8 NULL,
	min_voltage_b float8 NULL,
	min_voltage_c float8 NULL,
	max_voltage_a float8 NULL,
	max_voltage_b float8 NULL,
	max_voltage_c float8 NULL
);
COMMENT ON TABLE "MeasurementValue" IS $md$
The object of time series associated to a measurement device (i.e., Analog values of GridEye measurements, PMUs, forecasted values, smart meters, and etc.).
$md$;
COMMENT ON COLUMN "MeasurementValue".measurement_terminal_fk IS $md$
The uuid of associated measurement terminal.
$md$;
COMMENT ON COLUMN "MeasurementValue".timestamp IS $md$
Time stamp for the measurement value (Symbol: `t`).
$md$;
COMMENT ON COLUMN "MeasurementValue".record_date IS $md$
Record date for the measurement value.
$md$;
COMMENT ON COLUMN "MeasurementValue".avg_active_power_a IS $md$
Average magnitude of active power phase A (Symbol: `pA`, Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".avg_active_power_b IS $md$
Average magnitude of active power phase B (Symbol: `pB`, Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".avg_active_power_c IS $md$
Average magnitude of active power phase C (Symbol: `pC`, Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".std_active_power_a IS $md$
Standard deviation magnitude of active power phase A (Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".std_active_power_b IS $md$
Standard deviation magnitude of active power phase B (Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".std_active_power_c IS $md$
Standard deviation magnitude of active power phase C (Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".med_active_power_a IS $md$
Median magnitude of active power phase A (Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".med_active_power_b IS $md$
Median magnitude of active power phase B (Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".med_active_power_c IS $md$
Median magnitude of active power phase C (Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".lq_active_power_a IS $md$
0.05 quantile magnitude of active power phase A (Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".lq_active_power_b IS $md$
0.05 quantile  magnitude of active power phase B (Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".lq_active_power_c IS $md$
0.05 quantile  magnitude of active power phase C (Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".uq_active_power_a IS $md$
0.95 quantile magnitude of active power phase A (Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".uq_active_power_b IS $md$
0.95 quantile magnitude of active power phase B (Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".uq_active_power_c IS $md$
0.95 quantile magnitude of active power phase C (Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".min_active_power_a IS $md$
Minimum magnitude of active power phase A (Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".min_active_power_b IS $md$
Minimum magnitude of active power phase B (Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".min_active_power_c IS $md$
Minimum magnitude of active power phase C (Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".max_active_power_a IS $md$
Maximum magnitude of active power phase A (Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".max_active_power_b IS $md$
Maximum magnitude of active power phase B (Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".max_active_power_c IS $md$
Maximum magnitude of active power phase C (Unit: `kW`).
$md$;
COMMENT ON COLUMN "MeasurementValue".avg_current_a IS $md$
Average magnitude of current phase A (Symbol: `iA`, Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".avg_current_b IS $md$
Average magnitude of current phase B (Symbol: `iB`, Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".avg_current_c IS $md$
Average magnitude of current phase C (Symbol: `iC`, Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".std_current_a IS $md$
Standard deviation magnitude of current phase A (Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".std_current_b IS $md$
Standard deviation magnitude of current phase B (Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".std_current_c IS $md$
Standard deviation magnitude of current phase C (Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".med_current_a IS $md$
Median magnitude of current phase A (Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".med_current_b IS $md$
Median magnitude of current phase B (Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".med_current_c IS $md$
Median magnitude of current phase C (Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".lq_current_a IS $md$
0.05 quantile magnitude of current phase A (Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".lq_current_b IS $md$
0.05 quantile magnitude of current phase B (Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".lq_current_c IS $md$
0.05 quantile magnitude of current phase C (Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".uq_current_a IS $md$
0.95 quantile magnitude of current phase A (Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".uq_current_b IS $md$
0.95 quantile magnitude of current phase B (Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".uq_current_c IS $md$
0.95 quantile magnitude of current phase C (Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".min_current_a IS $md$
Minimum magnitude of current phase A (Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".min_current_b IS $md$
Minimum magnitude of current phase B (Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".min_current_c IS $md$
Minimum magnitude of current phase C (Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".max_current_a IS $md$
Maximum magnitude of current phase A (Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".max_current_b IS $md$
Maximum magnitude of current phase B (Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".max_current_c IS $md$
Maximum magnitude of current phase C (Unit: `A`).
$md$;
COMMENT ON COLUMN "MeasurementValue".avg_reactive_power_a IS $md$
Average magnitude of reactive power phase A (Symbol: `qA`, Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".avg_reactive_power_b IS $md$
Average magnitude of reactive power phase B (Symbol: `qB`, Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".avg_reactive_power_c IS $md$
Average magnitude of reactive power phase C (Symbol: `qC`, Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".std_reactive_power_a IS $md$
Standard deviation magnitude of reactive power phase A (Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".std_reactive_power_b IS $md$
Standard deviation magnitude of reactive power phase B (Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".std_reactive_power_c IS $md$
Standard deviation magnitude of reactive power phase C (Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".med_reactive_power_a IS $md$
Median magnitude of reactive power phase A (Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".med_reactive_power_b IS $md$
Median magnitude of reactive power phase B (Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".med_reactive_power_c IS $md$
Median magnitude of reactive power phase C (Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".lq_reactive_power_a IS $md$
0.05 quantile magnitude of reactive power phase A (Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".lq_reactive_power_b IS $md$
0.05 quantile magnitude of reactive power phase B (Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".lq_reactive_power_c IS $md$
0.05 quantile magnitude of reactive power phase C (Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".uq_reactive_power_a IS $md$
0.95 quantile magnitude of reactive power phase A (Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".uq_reactive_power_b IS $md$
0.95 quantile magnitude of reactive power phase B (Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".uq_reactive_power_c IS $md$
0.95 quantile magnitude of reactive power phase C (Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".min_reactive_power_a IS $md$
Minimum magnitude of reactive power phase A (Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".min_reactive_power_b IS $md$
Minimum magnitude of reactive power phase B (Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".min_reactive_power_c IS $md$
Minimum magnitude of reactive power phase C (Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".max_reactive_power_a IS $md$
Maximum magnitude of reactive power phase A (Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".max_reactive_power_b IS $md$
Maximum magnitude of reactive power phase B (Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".max_reactive_power_c IS $md$
Maximum magnitude of reactive power phase C (Unit: `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementValue".avg_voltage_a IS $md$
Average magnitude of voltage phase A (Symbol: `vA`, Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".avg_voltage_b IS $md$
Average magnitude of voltage phase B (Symbol: `vB`, Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".avg_voltage_c IS $md$
Average magnitude of voltage phase C (Symbol: `vC`, Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".std_voltage_a IS $md$
Standard deviation magnitude of voltage phase A (Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".std_voltage_b IS $md$
Standard deviation magnitude of voltage phase B (Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".std_voltage_c IS $md$
Standard deviation magnitude of voltage phase C (Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".med_voltage_a IS $md$
Median magnitude of voltage phase A (Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".med_voltage_b IS $md$
Median magnitude of voltage phase B (Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".med_voltage_c IS $md$
Median magnitude of voltage phase C (Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".lq_voltage_a IS $md$
0.05 quantile magnitude of voltage phase A (Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".lq_voltage_b IS $md$
0.05 quantile magnitude of voltage phase B (Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".lq_voltage_c IS $md$
0.05 quantile magnitude of voltage phase C (Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".uq_voltage_a IS $md$
0.95 quantile magnitude of voltage phase A (Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".uq_voltage_b IS $md$
0.95 quantile magnitude of voltage phase B (Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".uq_voltage_c IS $md$
0.95 quantile magnitude of voltage phase C (Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".min_voltage_a IS $md$
Minimum magnitude of voltage phase A (Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".min_voltage_b IS $md$
Minimum magnitude of voltage phase B (Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".min_voltage_c IS $md$
Minimum magnitude of voltage phase C (Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".max_voltage_a IS $md$
Maximum magnitude of voltage phase A (Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".max_voltage_b IS $md$
Maximum magnitude of voltage phase B (Unit: `V`).
$md$;
COMMENT ON COLUMN "MeasurementValue".max_voltage_c IS $md$
Maximum magnitude of voltage phase C (Unit: `V`).
$md$;


CREATE TABLE "MeasurementEvent" (
	timestamp timestamp NOT NULL,
	record_date timestamp NOT NULL,
	end_date timestamp NULL,
	record_end_date timestamp NULL,
	value float8 NULL,
	"type" snap.eventtype NULL,
	measurement_terminal_fk uuid NOT null references "MeasurementTerminal"(uuid),
	phase snap.phase not NULL
);
COMMENT ON TABLE "MeasurementEvent" IS $md$
The object of events associated to a `MeasurementDevice`.
$md$;
COMMENT ON COLUMN "MeasurementEvent".timestamp IS $md$
Time stamp for the event (Symbol: `t`).
$md$;
COMMENT ON COLUMN "MeasurementEvent".end_date IS $md$
End date for the event (Symbol: `t_end`).
$md$;
COMMENT ON COLUMN "MeasurementEvent".value IS $md$
Value of concerned parameter during the event (Unit: either `V`, `A`, `kW`, or `kVAR`).
$md$;
COMMENT ON COLUMN "MeasurementEvent".type IS $md$
Type of event; eventtype is the type of this column, which is one of the following values: `noVoltage`, `underVoltage`, `overVoltage`, `overCurrent`.
$md$;
COMMENT ON COLUMN "MeasurementEvent".measurement_terminal_fk IS $md$
The uuid of associated measurement terminal.
$md$;
COMMENT ON COLUMN "MeasurementEvent".phase IS $md$
Phase of event; `phase` is the type of this column, which is one of the following values: `A`, `B`, `C`.
$md$;
