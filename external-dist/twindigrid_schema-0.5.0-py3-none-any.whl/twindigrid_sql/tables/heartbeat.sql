-- also stores date of launch of the digital twin
-- no heartbeat should overlap (this is why removed endDate)
-- ends when next heartbeat is defined
create table "Heartbeat" (
	start_date timestamp not null,
	freq interval not null
);
-- TODO: function to retrieve the next/last heartbeat for a given time t
	-- maybe store last/next heartbeat
	-- what to do if t on heartbeat, return itself for next and last for last?
-- TODO: store latency / processing date
-- TODO: how to deal with timeout? (2x freq?)
COMMENT ON Table "Heartbeat" is $md$
Heartbeat of running digital twin algorithms.
$md$;
COMMENT ON COLUMN "Heartbeat".start_date IS $md$
Start date of running digital twin algorithms.
$md$;
COMMENT ON COLUMN "Heartbeat".freq IS $md$
Frequency of running digital twin algorithms (Unit: `minutes`).
$md$;
