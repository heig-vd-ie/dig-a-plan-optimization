create table "TransformerParameterEvent" (
	timestamp timestamp not null,
	record_date timestamp not null,
	eq_fk uuid not null references "Transformer"(uuid),
	value_source snap.eventsource not null,
	r float8 not null,
	r0 float8 not null default 0,
	x float8 not null,
	x0 float8 not null default 0,
	b float8 not null default 0,
	b0 float8 not null default 0,
	g float8 not null default 0,
	g0 float8 not null default 0,
	value_source_priority int generated always as (case when value_source = 'digitaltwin' then 1 else 2 end) stored
);
CREATE INDEX "TransformerParameterEvent_eq_priority_time_idx" ON "TransformerParameterEvent"(eq_fk, value_source_priority ASC, record_date DESC);

COMMENT ON TABLE "TransformerParameterEvent" IS $md$
Parameter events capture all changes in the parameters transformers due to aging or new calculation.
$md$;
COMMENT ON COLUMN "TransformerParameterEvent".timestamp IS $md$
Time stamp of parameter change event (Symbol: `t`).
$md$;
COMMENT ON COLUMN "TransformerParameterEvent".record_date IS $md$
Record date of parameter change event.
$md$;
COMMENT ON COLUMN "TransformerParameterEvent".eq_fk IS $md$
Uuid of associated transformer.
$md$;
COMMENT ON COLUMN "TransformerParameterEvent".value_source IS $md$
Whether the parameter event is determined after calculation or it is based on nominal values; `eventsource` is the type of this column, which is one of the following: `autoRaw`, `manualRaw`, `digitaltwin`.
$md$;
COMMENT ON COLUMN "TransformerParameterEvent".b IS $md$
Magnetizing branch susceptance (B mag) at fundamental frequency at the lower voltage side. The value can be positive or negative (Symbol: `B_trf`, Unit: `Siemens`).
$md$;
COMMENT ON COLUMN "TransformerParameterEvent".b0 IS $md$
Zero sequence magnetizing branch susceptance at the lower voltage side (Symbol: `B0_trf`, Unit: `Siemens`).
$md$;
COMMENT ON COLUMN "TransformerParameterEvent".g IS $md$
Magnetizing branch conductance at the lower voltage side of transformer (Symbol: `G_trf`, Unit: `Siemens`).
$md$;
COMMENT ON COLUMN "TransformerParameterEvent".g0 IS $md$
Zero sequence magnetizing branch conductance (star-model) at the lower voltage side (Symbol: `G0_trf`, Unit: `Siemens`).
$md$;
COMMENT ON COLUMN "TransformerParameterEvent".r IS $md$
Resistance (star-model) of the transformer at the lower voltage side. The attribute shall be equal or greater than zero for non-equivalent transformers (Symbol: `R_trf`, Unit: `Ohms`).
$md$;
COMMENT ON COLUMN "TransformerParameterEvent".r0 IS $md$
Zero sequence series resistance (star-model) at the lower voltage side (Symbol: `R0_trf`, Unit: `Ohms`).
$md$;
COMMENT ON COLUMN "TransformerParameterEvent".x IS $md$
Positive sequence series reactance (star-model) at fundamental frequency at the lower voltage side (Symbol: `X_trf`, Unit: `Ohms`).
$md$;
COMMENT ON COLUMN "TransformerParameterEvent".x0 IS $md$
Zero sequence series reactance at the lower voltage side (Symbol: `X0_trf`, Unit: `Ohms`).
$md$;
COMMENT ON COLUMN "TransformerParameterEvent".value_source_priority IS $md$
Calculated field to indicate the priority of the value source. Lower is greater priority. Used to find the latest most relevant event.
$md$;

create table "BranchParameterEvent" (
	timestamp timestamp not null,
	record_date timestamp not null,
	eq_fk uuid not null references "Branch"(uuid),
	value_source snap.eventsource not null,
	r float8 not null,
	r0 float8 not null default 0,
	x float8 not null,
	x0 float8 not null default 0,
	b float8 not null default 0,
	b0 float8 not null default 0,
	value_source_priority int generated always as (case when value_source = 'digitaltwin' then 1 else 2 end) stored
);
CREATE INDEX "BranchParameterEvent_eq_priority_time_idx" ON "BranchParameterEvent"(eq_fk, value_source_priority ASC, record_date DESC);
COMMENT ON TABLE "BranchParameterEvent" IS $md$
Parameter events capture all changes in the parameters branches due to aging or new calculation.
$md$;
COMMENT ON COLUMN "BranchParameterEvent".timestamp IS $md$
Time stamp of parameter change event (Symbol: `t`).
$md$;
COMMENT ON COLUMN "BranchParameterEvent".record_date IS $md$
Record date of parameter change event.
$md$;
COMMENT ON COLUMN "BranchParameterEvent".eq_fk IS $md$
The uuid of associated branch.
$md$;
COMMENT ON COLUMN "BranchParameterEvent".value_source IS $md$
Whether the parameter event is determined after calculation or it is based on nominal values; `eventsource` is the type of this column, which is one of the following: `autoRaw`, `manualRaw`, `digitaltwin`.
$md$;
COMMENT ON COLUMN "BranchParameterEvent".r IS $md$
Positive sequence series resistance of the one unit of length of branch (Symbol: `R_b`, Unit: `Ohms_per_km`).
$md$;
COMMENT ON COLUMN "BranchParameterEvent".r0 IS $md$
Zero sequence series resistance of the entire line (Symbol: `R0_b`, Unit: `Ohms_per_km`).
$md$;
COMMENT ON COLUMN "BranchParameterEvent".x IS $md$
Positive sequence series reactance of the one unit of length of branch (Symbol: `X_b`, Unit: `Ohms_per_km`).
$md$;
COMMENT ON COLUMN "BranchParameterEvent".x0 IS $md$
Zero sequence series reactance of the entire line section (Symbol: `X_b`, Unit: `Ohms_per_km`).
$md$;
COMMENT ON COLUMN "BranchParameterEvent".b IS $md$
Positive sequence shunt (charging) susceptance, uniformly distributed, of the entire line section. This value represents the full charging over the one unit of length of the line. The value can be positive or negative (Symbol: `B_b`, Unit: `Siemens_per_km`).
$md$;
COMMENT ON COLUMN "BranchParameterEvent".b0 IS $md$
Zero sequence shunt (charging) susceptance, uniformly distributed, of the entire line (Symbol: `B0_b`, Unit: `Siemens_per_km`).
$md$;
COMMENT ON COLUMN "BranchParameterEvent".value_source_priority IS $md$
Calculated field to indicate the priority of the value source. Lower is greater priority. Used to find the latest most relevant event.
$md$;

create table "SwitchEvent" (
	timestamp timestamp not null,
	record_date timestamp not null,
	eq_fk uuid not null references "Switch"(uuid),
	value_source snap.eventsource not null,
	open bool not null,
	value_source_priority int generated always as (case when value_source = 'digitaltwin' then 1 else 2 end) stored
);
CREATE INDEX "SwitchEvent_eq_priority_time_idx" ON "SwitchEvent"(eq_fk, value_source_priority ASC, record_date DESC);
COMMENT ON TABLE "SwitchEvent" IS $md$
Grid events capture changes in the grid model, i.e., the change in status of switches.
$md$;
COMMENT ON COLUMN "SwitchEvent".timestamp IS $md$
Time stamp of switch change event (Symbol: `t`).
$md$;
COMMENT ON COLUMN "SwitchEvent".record_date IS $md$
Record date of switch change event.
$md$;
COMMENT ON COLUMN "SwitchEvent".eq_fk IS $md$
The uuid of the switch at which the event is recorded.
$md$;
COMMENT ON COLUMN "SwitchEvent".value_source IS $md$
Whether the switch event is determined after estimation or it is logged by scada; `eventsource` is the type of this column, which is one of the following: `autoRaw`, `manualRaw`, `digitaltwin`.
$md$;
COMMENT ON COLUMN "SwitchEvent".open IS $md$
The new status of switches after the change. Only for switches that changed; It is `True` if the status changed to Open and `False` otherwise (Symbol: `u_sw`).
$md$;
COMMENT ON COLUMN "SwitchEvent".value_source_priority IS $md$
Calculated field to indicate the priority of the value source. Lower is greater priority. Used to find the latest most relevant event.
$md$;

create table "TapEvent" (
	timestamp timestamp not null,
	record_date timestamp not null,
	tap_fk uuid not null references "Tap"(uuid),
	value_source snap.eventsource not null,
	-- CONSTRAINT: eqFK, value and isTapT1 same as tapFK
	-- denormalized for quicker access
	eq_fk uuid not null references "Transformer" (uuid) on delete cascade,
	value float8 not null,
	is_tap_t1 bool not null,
	value_source_priority int generated always as (case when value_source = 'digitaltwin' then 1 else 2 end) stored
);
CREATE INDEX "TapEvent_eq_t1_priority_time_idx" ON "TapEvent"(eq_fk, is_tap_t1, value_source_priority ASC, record_date DESC);
COMMENT ON TABLE "TapEvent" IS $md$
Grid events capture changes in the grid model, i.e., the change in status of tap of transformers.
$md$;
COMMENT ON COLUMN "TapEvent".timestamp IS $md$
Time stamp of Tap changer Events (Symbol: `t`).
$md$;
COMMENT ON COLUMN "TapEvent".record_date IS $md$
Record date of Tap changer Events.
$md$;
COMMENT ON COLUMN "TapEvent".tap_fk IS $md$
The uuid of the tap at which the tap-changer event is recorded.
$md$;
COMMENT ON COLUMN "TapEvent".value_source IS $md$
Whether the tap event is determined after estimation or it is logged by scada; `eventsource` is the type of this column, which is one of the following: `autoRaw`, `manualRaw`, `digitaltwin`.
$md$;
COMMENT ON COLUMN "TapEvent".eq_fk IS $md$
The uuid of the transformer at which the event is recorded; Note that this value is redundant to facilitate the access to foreign key of the transformer.
$md$;
COMMENT ON COLUMN "TapEvent".value IS $md$
The value of the tap event; Note that this value is redundant to facilitate the access to the new value of the tap event (Unit: `V`).
$md$;
COMMENT ON COLUMN "TapEvent".is_tap_t1 IS $md$
Boolean determining the tap side in the transformer; `True`: it is `t1` side equivalent ot higher voltage side and `False`: it is `t2` or lower voltage side; Note that this value is redundant to facilitate the access to the side of transformer.
$md$;
COMMENT ON COLUMN "TapEvent".value_source_priority IS $md$
Calculated field to indicate the priority of the value source. Lower is greater priority. Used to find the latest most relevant event.
$md$;
