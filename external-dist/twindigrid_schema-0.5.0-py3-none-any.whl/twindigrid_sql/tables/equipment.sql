CREATE TABLE "Equipment" (
	uuid uuid NOT NULL PRIMARY KEY,
	concrete_type snap.equipmenttype NOT NULL,
	-- TODO: use postgis Geography type
	geo json CHECK(concrete_type != 'busbarSection' OR geo IS NOT NULL), -- only BusbarSection requires a geo attribute
	name varchar CHECK(concrete_type = 'measurementDevice' OR name IS NOT NULL) -- only MeasurementDevice has an optional name
);
comment on table "Equipment" is $md$
Represent a physical or abstract equipment that can be `installed` multiple times. The parts of a power system that are physical devices, electronic or mechanical.

The common attributes (`name`, `concrete_type`, `geo`, `uuid`) of different child tables are listed as columns in the parent table of `Equipment`.
For example, `Switch` is a child table of `Equipment` and contains the attributes `name`, `concrete_type`, `geo`, `uuid`, and specific attributes of the switches.

<strong>Remark:</strong> Uuid of `Equipment` keep the record of its installation in different locations. An `Equipment` has an `Uuid` over its lifetime. If an `Equipment` is replaced from location A to B (based on uninstall and install dates), the new rows in table of `Connectivity` will be inserted. The grid topology and model at each time instance can be determined only using the information of installed `Equipment`.
$md$;
COMMENT ON COLUMN "Equipment".uuid IS $md$
Uuid of the equipment determined by this row.
$md$;
comment on column "Equipment".concrete_type is $md$
It is used to determine the concrete equipment; `equipmenttype` is the type of the equipment, which is one of the following values: `bess`, `branch`, `busbarSection`, `energyConsumer`, `externalNetwork`, `pv`, `switch`, `transformer`, `synchronousGenerationUnit`, `measurementDevice`.
$md$;
COMMENT ON COLUMN "Equipment".geo IS $md$
Latitude and Longitude of the equipment location (Unit: `WGS84`).
$md$;
COMMENT ON COLUMN "Equipment".name IS $md$
Human readable name of the equipment determined by this row.
$md$;

CREATE TABLE "Terminal" (
	eq_fk uuid NOT NULL REFERENCES "Equipment"(uuid) on delete cascade,
	side snap.terminalside NOT NULL,
	phases snap.phases NOT NULL DEFAULT 'ABCn', -- same at both side for branch and switch (but not for transformer)
	PRIMARY KEY (eq_fk, side)
);
COMMENT ON TABLE "Terminal" IS $md$
An AC electrical connection point to a piece of conducting equipment.

Each `Equipment` can have one or two terminals and the `Equipment` are connected to each other by terminals connected to the same `ConnectivityNode`.
We have the following reasons for using the `Terminal` and `ConnectivityNode` model instead of the nodal connection between equipment:
1. It is close to the model used in IEC CIM (Common Information Model) family of standards and CGMES (Common Grid Model Exchange Specification).
2. We can simply define the exact location of a `MeasurementDevice` using this schema. Then, the direction of current, active, and reactive power will be determined.

To simplify the definition of the `Terminal`, we define each `Terminal` using the combination of `eq_fk` and `side`, in which `side` is one of the following values:
1. `t` for equipment with one terminal,
2. `t1` for higher voltage side of transformer and one of the branch/switch terminals,
3. `t2` for lower voltage side of transformer and one of the branch/switch terminals.
$md$;
COMMENT ON COLUMN "Terminal".eq_fk IS $md$
Uuid of the equipment of the terminal determined by this row.
$md$;
COMMENT ON COLUMN "Terminal".side IS $md$
Side of the `Equipment` for this terminal. `terminalside` is type of the terminal, which is either `t1`, `t2`, or `t`.
1. `t` for equipment with one terminal,
2. `t1` for higher voltage side of transformer and one of the branch/switch terminals,
3. `t2` for lower voltage side of transformer and one of the branch/switch terminals.
$md$;
COMMENT ON COLUMN "Terminal".phases IS $md$
Represents the phases of the terminal. `phases` is the type of this column, which is one of the following values: `ABC`, `ABCn`, `An`, `Bn`, `Cn`, `AB`, `BC`, `AC`.
$md$;

CREATE TABLE "Branch" (
	uuid uuid NOT NULL PRIMARY KEY REFERENCES "Equipment" (uuid) on delete cascade,
	current_limit float8 not null,
	length float8 not null,
	is_underground bool default null
);
COMMENT ON TABLE "Branch" IS $md$
Overhead or underground cables/lines that connects the equipment of a grid in a geographical region.
$md$;
COMMENT ON COLUMN "Branch".uuid IS $md$
The uuid of the `Branch` determined by this row.
$md$;
COMMENT ON COLUMN "Branch".current_limit IS $md$
Nominal current of `Branch` (Symbol: `I_b_nom`, Unit: `A`)
$md$;
COMMENT ON COLUMN "Branch".length IS $md$
Length of `Branch` (Symbol: `L_b`, Unit: `km`)
$md$;
COMMENT ON COLUMN "Branch".is_underground IS $md$
Boolean that determines whether the `Branch` is underground or not; `True` if it is underground and `False` otherwise.

**Remark:** When this columns is null, it means that the `Branch` is a mixture of underground and over overground.
$md$;

CREATE TABLE "Switch" (
	uuid uuid NOT NULL PRIMARY KEY REFERENCES "Equipment" (uuid) on delete cascade,
	normal_open bool NOT NULL DEFAULT FALSE,
	controllable snap.controllable NOT NULL
);
COMMENT ON TABLE "Switch" IS $md$
Switches, breakers, or disconnectors. A generic device designed to close, or open, or both, one or more electric circuits. All switches are two terminal devices including grounding switches.
$md$;
COMMENT ON COLUMN "Switch".uuid IS $md$
The uuid of the switch determined by this row.
$md$;
COMMENT ON COLUMN "Switch".normal_open IS $md$
Normal state of the switch (Symbol: `u0_s`); `False`: close, `True`: open.
$md$;
COMMENT ON COLUMN "Switch".controllable IS $md$
Type of switch. `controllable` is the type of this column, which is one of the following values: `manualOffLoad`, `manualOnLoad`, `autoOffLoad`, `autoOnLoad`, `no`.
<strong>Remark:</strong> Switch is `manualOffLoad`, Breaker is `autoOnLoad` or `manualOnLoad`, Sectionalizer is `autoOffLoad` or `manualOffLoad`, Fuse is `no`.
$md$;

CREATE TABLE "Transformer" (
	uuid uuid NOT NULL PRIMARY KEY REFERENCES "Equipment" (uuid) on delete cascade,
	vector_group snap.vectorgroup not NULL,
	rated_s float8 not NULL
);
COMMENT ON TABLE "Transformer" IS $md$
An electrical device consisting of two windings, with or without a magnetic core, for introducing mutual coupling between electric circuits. Transformers can be used to control voltage and phase shift (active power flow). A power transformer may be composed of separate transformer tanks that need not be identical. A power transformer can be modeled with or without tanks and is intended for use in both balanced and unbalanced representations. A power transformer typically has two terminals, but may have one (grounding), three or more terminals.
<strong>Remark:</strong> The higher voltage terminal of a transformer is on side `t1`.
$md$;
COMMENT ON COLUMN "Transformer".uuid IS $md$
The uuid of the transformer determined by this row.
$md$;
COMMENT ON COLUMN "Transformer".vector_group IS $md$
Kind of connection. `vectorgroup` is the of this column, which is one of the following values: `Dy1`, `Dy5`, `Dy11`, `Yy0`, `Yz1`, `Yz5`, `Yz11`, `Ynd1`, `Ynd5`.
$md$;
COMMENT ON COLUMN "Transformer".rated_s IS $md$
Normal apparent power rating. The attribute shall be a positive value. For a two-winding transformer the values for the high and low voltage sides shall be identical (Symbol: `S_trf_nom`, Unit: `kVA`).
$md$;

create table "Tap" (
	uuid uuid primary key default uuid_generate_v4(),
	eq_fk uuid not null references "Transformer" (uuid) on delete cascade,
	value float8 not null,
	is_tap_t1 bool not null  -- is higher voltage vs lower voltage
);
CREATE INDEX "Tap_t1_eq_idx" ON "Tap"(is_tap_t1, eq_fk);
COMMENT ON TABLE "Tap" IS $md$
Possible tap values for the tap of the transformer.
$md$;
COMMENT ON COLUMN "Tap".uuid IS $md$
The uuid of the tap determined by this row.
$md$;
COMMENT ON COLUMN "Tap".eq_fk IS $md$
The uuid og the transformer determined by this row.
$md$;
COMMENT ON COLUMN "Tap".value IS $md$
Voltage level of tap position (Unit: `V`).
$md$;
COMMENT ON COLUMN "Tap".is_tap_t1 IS $md$
Boolean determining the tap side in the transformer; `True`: it is `t1` side equivalent ot higher voltage side and `False`: it is `t2` or lower voltage side.
$md$;

CREATE TABLE "BusbarSection" (
	uuid uuid NOT NULL PRIMARY KEY REFERENCES "Equipment" (uuid) on delete cascade,
	voltage_level float8 not NULL,
	voltage_min float8 not NULL,
	voltage_max float8 not NULL
);
COMMENT ON TABLE "BusbarSection" IS $md$
A conductor, or group of conductors, with negligible impedance, that serve to connect other conducting equipment within a single substation. Voltage measurements are typically obtained from VoltageTransformers that are connected to busbar sections. A bus bar section may have many physical terminals but for analysis is modelled with exactly one logical terminal.
$md$;
COMMENT ON COLUMN "BusbarSection".uuid IS $md$
The uuid of the busbar determined by this row.
$md$;
COMMENT ON COLUMN "BusbarSection".voltage_level IS $md$
Value of nominal voltage at busbar section (Symbol: `V_bb_nom`, Unit: `V`).
$md$;
COMMENT ON COLUMN "BusbarSection".voltage_min IS $md$
Minimum acceptable voltage level of a busbar section (Symbol: `V_bb_min`, Unit: `V`).
$md$;
COMMENT ON COLUMN "BusbarSection".voltage_max IS $md$
Maximum acceptable voltage level of a busbar section (Symbol: `V_bb_max`, Unit: `V`).
$md$;

create table "EnergyConsumer" (
	uuid uuid not null primary key references "Equipment" (uuid) on delete cascade,
	rated_s float8 not null,
	profile_type snap.profiletype not null
);
COMMENT ON TABLE "EnergyConsumer" IS $md$
Generic user of energy - a point of consumption on the power system model.
$md$;
COMMENT ON COLUMN "EnergyConsumer".uuid IS $md$
The uuid of the `EnergyConsumer` determined by this row.
$md$;
COMMENT ON COLUMN "EnergyConsumer".rated_s IS $md$
Nominal apparent power of `EnergyConsumer` (Symbol: `S_ec_nom`, Unit: `kVA`).
$md$;
COMMENT ON COLUMN "EnergyConsumer".profile_type IS $md$
Profile type of the `EnergyConsumer`; `profiletype` is the type of this column, which is one of the following values: `residential`, `commercial`, `industrial`.
$md$;

create table "SynchronousGenerationUnit" (
	uuid uuid NOT NULL PRIMARY KEY REFERENCES "Equipment" (uuid) on delete cascade,
	rated_s float8 not null,
	min_operating_p float8 not null default 0,
    max_operating_p float8 not null
);
COMMENT ON TABLE "SynchronousGenerationUnit" IS $md$
A single or set of synchronous machines for converting mechanical power into alternating-current power. For example, individual machines within a set may be defined for scheduling purposes while a single control signal is derived for the set. In this case there would be a generating unit for each member of the set and an additional generation unit to the set.
$md$;
COMMENT ON COLUMN "SynchronousGenerationUnit".uuid IS $md$
The uuid of the synchronous generation unit determined by this row.
$md$;
COMMENT ON COLUMN "SynchronousGenerationUnit".rated_s IS $md$
Maximum apparent power of the generation unit (Symbol: `S_dg_nom`, Unit: `kVA`).
$md$;
COMMENT ON COLUMN "SynchronousGenerationUnit".min_operating_p IS $md$
Minimum active power of generating unit (Symbol: `P_dg_min`, Unit: `kW`).
$md$;
COMMENT ON COLUMN "SynchronousGenerationUnit".max_operating_p IS $md$
Maximum active power of generating unit (Symbol: `P_dg_max`, Unit: `kW`).
$md$;

create table "Bess" (
	uuid uuid NOT NULL PRIMARY KEY REFERENCES "Equipment" (uuid) on delete cascade,
	charging_eff float8 not null default 1,
	discharging_eff float8 not null default 1,
	rated_s float8 not null,
	rated_e float8 not null,
	min_charging_p float8 not null default 0,
	max_charging_p float8 not null,
	min_discharging_p float8 not null default 0,
	max_discharging_p float8 not null
);
COMMENT ON TABLE "Bess" IS $md$
Battery energy storage systems (BESSs) components.
$md$;
COMMENT ON COLUMN "Bess".uuid IS $md$
The uuid of the battery energy storage system determined by this row.
$md$;
COMMENT ON COLUMN "Bess".charging_eff IS $md$
Charging efficiency in percentage (Symbol: `Eta_bess_ch`, Unit: `%`).
$md$;
COMMENT ON COLUMN "Bess".discharging_eff IS $md$
Discharging efficiency in percentage (Symbol: `Eta_bess_dch`, Unit: `%`).
$md$;
COMMENT ON COLUMN "Bess".rated_s IS $md$
maximum apparent power of BESS inverter (Symbol: `S_bess_nom`, Unit: `kVA`).
$md$;
COMMENT ON COLUMN "Bess".rated_e IS $md$
Nominal capacity (Symbol: `E_bess_nom`, Unit: `kW`).
$md$;
COMMENT ON COLUMN "Bess".min_charging_p IS $md$
Minimum charging power (Symbol: `P_bess_ch_min`, Unit: `kW`).
$md$;
COMMENT ON COLUMN "Bess".max_charging_p IS $md$
Maximum charging power (Symbol: `P_bess_ch_max`, Unit: `kW`).
$md$;
COMMENT ON COLUMN "Bess".min_discharging_p IS $md$
Minimum discharging power (Symbol: `P_bess_dch_min`, Unit: `kW`).
$md$;
COMMENT ON COLUMN "Bess".max_discharging_p IS $md$
Maximum discharging power (Symbol: `P_bess_dch_max`, Unit: `kW`).
$md$;

create table "ExternalNetwork" (
	uuid uuid NOT NULL PRIMARY KEY REFERENCES "Equipment" (uuid) on delete cascade,
	r_eq float8 not null default 0,
	x_eq float8 not null default 0
);
COMMENT ON TABLE "ExternalNetwork" IS $md$
This class represents external network and it is used for IEC 60909 calculations.
$md$;
COMMENT ON COLUMN "ExternalNetwork".uuid IS $md$
The uuid of the external network determined by this row.
$md$;
COMMENT ON COLUMN "ExternalNetwork".r_eq IS $md$
The equivalent resistance of External Network to consider multiple upstream networks (Symbol: `R_ex_eq`, Unit: `Ohms`).
$md$;
COMMENT ON COLUMN "ExternalNetwork".x_eq IS $md$
The equivalent inductance of External Network to consider multiple upstream networks (Symbol: `X_eq_eq`, Unit: `Ohms`).
$md$;

create table "Pv" (
	uuid uuid NOT NULL PRIMARY KEY REFERENCES "Equipment" (uuid) on delete cascade,
	cos_phi_limit float8 not null default 1,
	rated_s float8 not null
);
COMMENT ON TABLE "Pv" IS $md$
Photovoltaic system.
$md$;
COMMENT ON COLUMN "Pv".uuid IS $md$
The uuid of the photovoltaic system determined by this row.
$md$;
COMMENT ON COLUMN "Pv".cos_phi_limit IS $md$
Power factor limit of the photovoltaic system (Symbol: `Pf_pv_limit`).
$md$;
COMMENT ON COLUMN "Pv".rated_s IS $md$
Maximum apparent power of PV inverter (Symbol: `S_pv_nom`, Unit: `kVA`).
$md$;
