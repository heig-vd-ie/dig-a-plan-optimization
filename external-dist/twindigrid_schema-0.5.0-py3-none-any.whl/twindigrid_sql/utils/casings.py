from __future__ import annotations
from enum import Enum

from dataclasses import dataclass
from typing import Optional, Self

@dataclass
class Casing:
    words: list[str]

    @classmethod
    def from_snake(cls, value: str) -> Self:
        return Casing(value.lower().split("_"))

    def as_camel(self) -> str:
        return "".join(w.capitalize() if i > 0 else w for i, w in enumerate(self.words))

    def as_pascal(self) -> str:
        return "".join(w.capitalize() for w in self.words)

    def as_snake(self) -> str:
        return "_".join(w.capitalize() for w in self.words)

    def as_kebab(self) -> str:
        return "-".join(w.capitalize() for w in self.words)