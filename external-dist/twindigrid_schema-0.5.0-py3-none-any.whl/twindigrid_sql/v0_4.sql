-- Uses psql to execute
-- Using for example 'psql 'host=localhost port=5432 dbname=v0_4 user=postgres password=password' --file=v0_4.sql'
-- Using "psql -h localhost -p "55001" -d "postgres" -U "postgres" -f "D:\twindigrid\dataschema\src\twindigrid_sql\v0_4.sql" in windows
-- DROP SCHEMA IF EXISTS snap CASCADE;
CREATE SCHEMA snap;
SET search_path TO snap, public;
\ir snap/schema.sql
\ir snap/comments.sql

\ir ./schema.sql

SET search_path TO main, public;

-- equipment
\ir tables/equipment.sql

-- event
\ir tables/events.sql

-- abstraction
\ir tables/abstraction.sql

-- output datetime
\ir tables/heartbeat.sql

-- connectivity
\ir tables/connectivity.sql

-- measurements
\ir tables/measurement.sql

-- required insertions
\ir inserts/setup.sql

-- view and table function
\ir functions/time.sql
\ir views/abstraction.sql
\ir views/connectivity.sql
\ir views/snap_event.sql
\ir views/snap_equipment.sql
\ir views/snap_abstraction.sql
\ir views/snap_measurement.sql

-- \ir ../../examples/sql/ieee33.sql
-- \ir ../../examples/sql/insert.sql

SET search_path TO snap, public;
\ir snap/persist.sql

SET search_path TO main, public;
