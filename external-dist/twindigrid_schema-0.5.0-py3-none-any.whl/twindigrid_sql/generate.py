import os
import re
from typing import Literal
import sqlalchemy
from sqlalchemy import create_mock_engine, Engine, text, schema
import twindigrid_sql.ddl.schema as custom_schema
from twindigrid_sql.inserts.populate import populate
from twindigrid_sql.schema.metadata import metadata_obj
from twindigrid_sql.utils.logging import get_logger

logger = get_logger(__name__)

# Need to be imported so that metadata_obj is filled
import twindigrid_sql.schema

def mock_engine():
    def dump(sql, *multiparams, **params):
        print(sql.compile(dialect=engine.dialect))

    engine = create_mock_engine("postgresql+psycopg://", dump)
    return engine

def create_tables(engine: Engine):
    with engine.begin() as conn:
        schema_metas = twindigrid_sql.schema.metas
        logger.info(f"Create schemas")
        for s in schema_metas:
            conn.execute(schema.DropSchema(s.name, cascade=True, if_exists=True))
            conn.execute(custom_schema.CreateSchema(s.name, comment=s.comment))
        logger.info(f"Create extensions")
        for ext in twindigrid_sql.schema.extensions:
            safe_ext = ext.replace('"', '""')
            conn.execute(text(f'CREATE EXTENSION IF NOT EXISTS "{safe_ext}" WITH SCHEMA public;'))
    logger.info(f"Create tables and their dependencies")
    metadata_obj.create_all(engine, checkfirst=False)

def populate_entries(engine: Engine):
    with engine.begin() as conn:
        logger.info(f"Populate entries")
        populate(conn)

if __name__ == "__main__":
    ACTIONS: list[Literal["print", "create"]] = [
        'print',
        'create',
    ]

    for action in ACTIONS:
        match action:
            case 'print':
                logger.info("Start printing")
                metadata_obj.create_all(mock_engine(), checkfirst=False)
            case 'create':
                DB_URL = os.environ.get("DB_URL")
                engine = sqlalchemy.create_engine(DB_URL)
                logger.info(f"Start creating on db: {DB_URL}")
                create_tables(engine)
                populate_entries(engine)