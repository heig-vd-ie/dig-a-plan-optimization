from functools import partial
from sqlalchemy import MetaData
import sqlalchemy

from twindigrid_sql.ddl.meta import SchemaElementMeta

metadata_obj = MetaData()

def meta_from(module_name: str) -> SchemaElementMeta:
    return SchemaElementMeta.from_module(module_name, metadata_object=metadata_obj)

# Schema used to store enums (used both by postgres and duckdb)
ENUM_SCHEMA = "enum"

# Function use to create a database enum type based on a python enum
Enum = partial(sqlalchemy.Enum, metadata=metadata_obj, schema=ENUM_SCHEMA, values_callable=lambda x: [e.value for e in x])
