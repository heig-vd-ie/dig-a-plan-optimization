"""
ProcedureComment
"""

from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.schema import history
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.metadata import meta_from
from twindigrid_sql.schema import snap
from . import view_container_simple, view_resource, view_container_tree, view_container_attr

m = meta_from(__name__)

query, v, tf = snap.tablefunc_container.based_on(
    m,
    view_container_simple.v.table,
    view_resource.v.table,
    view_container_tree.v.table,
    view_container_attr.v.table,
)