"""
ViewComment
"""

from sqlalchemy import event, func, select

from twindigrid_sql.ddl.view import CreateView, View
from twindigrid_sql.dql.recursive_cte import recursive_cte
from ..history import table_container, table_connectivity_node, table_connectivity
from twindigrid_sql.schema.metadata import metadata_obj
from twindigrid_sql.schema.metadata import meta_from

m = meta_from(__name__)

ct = table_container.g.table
cn = table_connectivity_node.g.table
c = table_connectivity.g.table

container_direct_base_voltages = (
    select(ct.c.uuid, ct.c.parent_fk, cn.c.base_voltage_fk.label('base_voltage'))
    .distinct()
    .select_from(c.join(cn).join(ct))
).cte("container_direct_base_voltages")

mono_base_voltage = (
    select(
        container_direct_base_voltages.c.uuid, 
        container_direct_base_voltages.c.parent_fk, 
        func.min(container_direct_base_voltages.c.base_voltage).label('base_voltage'),
    )
    .group_by(
        container_direct_base_voltages.c.uuid, 
        container_direct_base_voltages.c.parent_fk, 
    ).having(func.count(container_direct_base_voltages.c.base_voltage.distinct()) == 1)
).alias("mono_base_voltage")

rec = recursive_cte(
    select(
        container_direct_base_voltages,
    ),
    'UNION',
    lambda rc_alias:
    select(
        rc_alias.c.uuid,
        rc_alias.c.parent_fk,
        mono_base_voltage.c.base_voltage,
    ).join_from(rc_alias, mono_base_voltage, onclause=rc_alias.c.uuid==mono_base_voltage.c.parent_fk),
    name="container_base_voltages_rec",
)

q = select(rec).distinct()

v = View(
    name=m.name, 
    schema=m.schema,
    query=q,
    comment=m.comment,
)

event.listen(metadata_obj, 'after_create', CreateView(v, True))
