"""
ViewComment
"""

from sqlalchemy import TEXT, and_, case, event, func, literal, select

from twindigrid_sql.ddl.view import CreateView, View
from . import view_voltage_layer
from ..history import table_resource, table_container
from twindigrid_sql.schema.metadata import metadata_obj
from twindigrid_sql.schema.metadata import meta_from

m = meta_from(__name__)

re = table_resource.g.table
vl = view_voltage_layer.v.table
ct = table_container.g.table

parent_re = re.alias("parent_re")

q = (
    select(re)
).union_all(
    select(
        vl.c.uuid, 
        parent_re.c.start_heartbeat,
        parent_re.c.end_heartbeat,
        parent_re.c.start,
        parent_re.c.end,
        parent_re.c.dso_code.concat("-V").concat(vl.c.base_voltage).label("dso_code"),
        literal("voltage_layer").label("concrete_class"),
        literal("V").concat(vl.c.base_voltage).label("name"),
        literal(None).label("metadata"),
        parent_re.c.owner,
    )
    .select_from(vl.join(ct.join(parent_re), onclause=vl.c.parent_fk==ct.c.uuid))
)

v = View(
    name=m.name, 
    schema=m.schema,
    query=q,
    comment=m.comment,
)

event.listen(metadata_obj, 'after_create', CreateView(v, True))
