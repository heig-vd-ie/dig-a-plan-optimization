"""
ProcedureComment
"""

from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.schema import history
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.metadata import meta_from
from twindigrid_sql.schema.snap import tablefunc_connectivity
from . import view_connectivity_simple

m = meta_from(__name__)

query, v, tf = tablefunc_connectivity.based_on(
    m,
    view_connectivity_simple.v.table,
)