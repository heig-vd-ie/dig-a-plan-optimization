"""
ViewComment
"""

from sqlalchemy import event, func, select

from twindigrid_sql.ddl.view import CreateView, View
from . import view_container_base_voltages
from twindigrid_sql.schema.metadata import metadata_obj
from twindigrid_sql.schema.metadata import meta_from

m = meta_from(__name__)


cbv = view_container_base_voltages.v.table

q = (
    select(cbv.c.uuid, cbv.c.parent_fk, func.array_agg(cbv.c.base_voltage.distinct()).label("base_voltages"))
    .group_by(cbv.c.uuid, cbv.c.parent_fk)
    .having(func.count(cbv.c.base_voltage.distinct()) > 1)
).union( 
    # Root containers have voltage layers even if it contains only a single base voltage
    # TODO: check if required (may be useful to align in layout)
    select(cbv.c.uuid, cbv.c.parent_fk, func.array_agg(cbv.c.base_voltage.distinct()).label("base_voltages"))
    .where(cbv.c.parent_fk.is_(None))
    .group_by(cbv.c.uuid, cbv.c.parent_fk)
)

v = View(
    name=m.name, 
    schema=m.schema,
    query=q,
    comment=m.comment,
)

event.listen(metadata_obj, 'after_create', CreateView(v, True))
