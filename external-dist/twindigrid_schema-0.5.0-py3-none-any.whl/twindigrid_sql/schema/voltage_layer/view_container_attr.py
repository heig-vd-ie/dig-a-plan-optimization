"""
ViewComment
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy import event
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.ddl.view import CreateView, View
from twindigrid_sql.dql.attr_extractor import attr_extractor_from
from twindigrid_sql.dql.recursive_cte import recursive_cte
from twindigrid_sql.schema.history import view_container_attr
from . import view_resource, view_voltage_layer
from twindigrid_sql.schema.metadata import metadata_obj
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams

m = meta_from(__name__)

v = view_container_attr.based_on(
    m, 
    view_resource.v.table, 
    view_container_attr.spec_extractors + [
        attr_extractor_from(view_voltage_layer.v.table, view_voltage_layer.v.table.c[('uuid',)]),
    ]
)
