"""
Possible measurement type values.
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams


class _Fields[T](NamedTuple):
    root_containers: T = """
    The id of the root containers that identify this layout.
    """
    created_at: T = """
    The time when the layout was saved.
    """
    positions: T = """
    The position of the nodes in the layout.
    """


m, f, c, i = meta_from(__name__).specify(TableMeta.inherits)(_Fields).explode()


def params(t: TableMeta) -> TableParams:
    return TableParams.of(
        m.Column(f.root_containers, ARRAY(UUID),
                 nullable=False),
        m.Column(f.created_at, TIMESTAMPTZ,
                 nullable=False),
        m.Column(f.positions, JSONB,
                 nullable=False),
    )


g = m.generate_ddl(params(m))
