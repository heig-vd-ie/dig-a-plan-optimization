"""
ProcedureComment
"""

from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.schema import history
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.metadata import meta_from
from twindigrid_sql.schema import snap
from . import view_resource, view_container_tree, tablefunc_connectivity, view_equipment_attr

m = meta_from(__name__)

query, v, tf = snap.tablefunc_equipment.based_on(
    m,
    history.table_terminal.g.table,
    history.table_equipment.g.table,
    view_resource.v.table,
    view_container_tree.v.table,
    tablefunc_connectivity.tf,
    view_equipment_attr.v.table,
)
