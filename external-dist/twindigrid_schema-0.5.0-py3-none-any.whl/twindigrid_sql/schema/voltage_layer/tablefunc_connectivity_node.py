"""
ProcedureComment
"""

from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.schema import history
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.metadata import meta_from
from twindigrid_sql.schema.snap import tablefunc_connectivity_node
from . import tablefunc_connectivity, view_container_tree

m = meta_from(__name__)

query, v, tf = tablefunc_connectivity_node.based_on(
    m,
    history.table_connectivity_node.g.table,
    view_container_tree.v.table,
    tablefunc_connectivity.tf,
)