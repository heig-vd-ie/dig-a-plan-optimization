"""
ViewComment
"""

from sqlalchemy import TEXT, and_, case, event, func, select

from twindigrid_sql.ddl.view import CreateView, View
from . import view_voltage_layer_parent
from ..history import table_connectivity, table_connectivity_node
from twindigrid_sql.schema.metadata import metadata_obj
from twindigrid_sql.schema.metadata import meta_from

m = meta_from(__name__)

c = table_connectivity.g.table
cn = table_connectivity_node.g.table
vlp = view_voltage_layer_parent.v.table

q = (
    select(
        *[col for col in c.columns if col.name != 'container_fk'], 
        case(
            (vlp.c.uuid.is_not(None), func.uuid_generate_v5(c.c.container_fk, cn.c.base_voltage_fk.cast(TEXT))),
            else_=c.c.container_fk
        ).label('container_fk'),
    )
    .select_from(
        c
        .join(cn, onclause=c.c.cn_fk==cn.c.uuid)
        .join(vlp, onclause=c.c.container_fk==vlp.c.uuid, isouter=True)
    )
)

v = View(
    name=m.name, 
    schema=m.schema,
    query=q,
    comment=m.comment,
)

event.listen(metadata_obj, 'after_create', CreateView(v, True))
