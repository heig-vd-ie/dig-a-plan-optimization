"""
ViewComment
"""

from sqlalchemy import TEXT, and_, case, event, func, select

from twindigrid_sql.ddl.view import CreateView, View
from . import view_voltage_layer, view_voltage_layer_parent, view_container_base_voltages
from ..history import table_container
from twindigrid_sql.schema.metadata import metadata_obj
from twindigrid_sql.schema.metadata import meta_from

m = meta_from(__name__)

ct = table_container.g.table
vl = view_voltage_layer.v.table
vlp = view_voltage_layer_parent.v.table
cbv = view_container_base_voltages.v.table

p = vlp.alias("p")
s = vlp.alias("s")

q = (
    select(vl.c.uuid, vl.c.parent_fk)
).union(
    select(
        ct.c.uuid, 
        case(
            (and_(p.c.uuid.is_not(None), s.c.uuid.is_(None)), func.uuid_generate_v5(ct.c.parent_fk, cbv.c.base_voltage.cast(TEXT))),
            else_=ct.c.parent_fk
        ).label('parent_fk'),
    )
    .distinct()
    .select_from(
        ct
        .join(cbv, onclause=ct.c.uuid==cbv.c.uuid, isouter=True)
        .join(p, onclause=ct.c.parent_fk==p.c.uuid, isouter=True)
        .join(s, onclause=ct.c.uuid==s.c.uuid, isouter=True)
    )
)

v = View(
    name=m.name, 
    schema=m.schema,
    query=q,
    comment=m.comment,
)

event.listen(metadata_obj, 'after_create', CreateView(v, True))
