"""
ViewComment
"""

from sqlalchemy import TEXT, event, func, select

from twindigrid_sql.ddl.view import CreateView, View
from . import view_voltage_layer_parent
from twindigrid_sql.schema.metadata import metadata_obj
from twindigrid_sql.schema.metadata import meta_from

m = meta_from(__name__)

vlp = view_voltage_layer_parent.v.table

uvlp = (
    select(vlp.c.uuid, func.unnest(vlp.c.base_voltages).label('base_voltage'))
).alias()

q = (
    select(func.uuid_generate_v5(uvlp.c.uuid, uvlp.c.base_voltage.cast(TEXT)).label("uuid"), uvlp.c.uuid.label("parent_fk"), uvlp.c.base_voltage)
)

v = View(
    name=m.name, 
    schema=m.schema,
    query=q,
    comment=m.comment,
)

event.listen(metadata_obj, 'after_create', CreateView(v, True))
