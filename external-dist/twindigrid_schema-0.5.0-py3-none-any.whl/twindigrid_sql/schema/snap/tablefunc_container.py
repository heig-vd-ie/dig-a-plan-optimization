"""
ProcedureComment
"""

from functools import reduce
from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy import event
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.ddl.meta_changes import GeneratedChangesTableDDL
from twindigrid_sql.ddl.view import CreateView, View
from twindigrid_sql.entries.container_class import CLIENT, SUBSTATION
from twindigrid_sql.schema import history
from twindigrid_sql.schema.metadata import metadata_obj
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.callable import CreateCallable, SqlBody, TableFunction, CallableArg, TextBody
from twindigrid_sql.dql.attr_extractor import AttrExtractor, AttrMerger

m = meta_from(__name__)


def based_on(meta, container, resource, container_tree, spec):
    def query(t=literal(None), a=literal(None)):
        q = (
            select(
                container.c.uuid,
                resource.c.dso_code,
                resource.c.name,
                resource.c.concrete_class,
                container.c.parent_fk,
                spec.c.attr,
                container_tree.c.path,
            )
            .select_from(container)
            .join(resource, resource.c.uuid == container.c.uuid)
            .join(spec, spec.c.uuid == container.c.uuid, isouter=True)
            .join(container_tree, container_tree.c.uuid == container.c.uuid)
        )

        return q


    v = View(
        name=meta.name, 
        schema=meta.schema,
        query=query(),
        comment=meta.comment,
    )

    event.listen(meta.metadata_object, 'after_create', CreateView(v, True))


    tf = TableFunction(
        name=f"{meta.name}", 
        schema=meta.schema,
        args=[
            arg_time := CallableArg(TIMESTAMPTZ, name='t'),
            arg_abstraction := CallableArg(UUID(), name='a'),
        ],
        volatility='STABLE',
        rettype=v,
        body=SqlBody([query(arg_time.col, arg_abstraction.col)]), 
    )

    event.listen(meta.metadata_object, 'after_create', CreateCallable(tf, True))
    
    return query, v, tf

query, v, tf = based_on(
    m,
    history.table_container.g.table,
    history.table_resource.g.table,
    history.view_container_tree.v.table,
    history.view_container_attr.v.table,
)
