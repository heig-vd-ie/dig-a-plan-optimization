"""
ProcedureComment
"""

from functools import reduce
from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy import event
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.ddl.meta_changes import GeneratedChangesTableDDL
from twindigrid_sql.ddl.view import CreateView, View
from twindigrid_sql.entries.equipment_class import BRANCH, ENERGY_CONSUMER, EXTERNAL_NETWORK, GENERATING_UNIT, SWITCH
from twindigrid_sql.schema import history
from twindigrid_sql.schema.metadata import metadata_obj
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.callable import CreateCallable, SqlBody, TableFunction, CallableArg, TextBody
from twindigrid_sql.dql.attr_extractor import AttrExtractor, AttrMerger
from . import tablefunc_connectivity

m = meta_from(__name__)


def based_on(meta, terminal, equipment, resource, container_tree, func_connectivity, spec):

    def query(t=literal(None), a=literal(None)):
        cn = func_connectivity.func(t, a)

        # Add sides number from terminal
        terminals_summary = (
            select(terminal.c.eq_fk, func.count(terminal.c.side).label("sides"), literal('terminals').label("concrete_class"))
            .group_by(terminal.c.eq_fk)
        )
        terminals_attr = AttrExtractor(
            query=terminals_summary, 
            name='terminals',
            join_columns=[terminals_summary.c.eq_fk],
            json_columns=[terminals_summary.c.sides],
        )

        eq_container = (
            select(
                cn.c.eq_fk.label('uuid'),
                func.nullif(
                    func.subpath(func.lca(func.array_agg(func.coalesce(container_tree.c.ancestors, 'root.self'))), -1), 
                    'root'
                ).cast(TEXT).cast(UUID()).label("container_fk"),
            )
            .join(container_tree, container_tree.c.uuid == cn.c.container_fk, isouter=True)
            .group_by(cn.c.eq_fk)
        ).alias('eq_container')

        q = (
            select(
                equipment.c.uuid,
                resource.c.dso_code,
                resource.c.name,
                resource.c.concrete_class,
                case(
                    (resource.c.concrete_class == EXTERNAL_NETWORK, None),
                    else_ = eq_container.c.container_fk,
                ).label('container_fk'),
                spec.c.attr.concat(terminals_attr.select.c.attr).label('attr'),
            )
            .select_from(equipment)
            .join(resource, resource.c.uuid == equipment.c.uuid)
            .join(eq_container, eq_container.c.uuid == equipment.c.uuid, isouter=True)
            .join(terminals_attr.select, terminals_attr.select.c.eq_fk == equipment.c.uuid, isouter=True)
            .join(spec, spec.c.uuid == equipment.c.uuid, isouter=True)
        )

        return q


    v = View(
        name=meta.name, 
        schema=meta.schema,
        query=query(),
        comment=meta.comment,
    )

    event.listen(meta.metadata_object, 'after_create', CreateView(v, True))


    tf = TableFunction(
        name=f"{meta.name}", 
        schema=meta.schema,
        args=[
            arg_time := CallableArg(TIMESTAMPTZ, name='t'),
            arg_abstraction := CallableArg(UUID(), name='a'),
        ],
        volatility='STABLE',
        rettype=v,
        body=SqlBody([query(arg_time.col, arg_abstraction.col)]), 
    )

    event.listen(meta.metadata_object, 'after_create', CreateCallable(tf, True))
    
    return query, v, tf

query, v, tf = based_on(
    m,
    history.table_terminal.g.table,
    history.table_equipment.g.table,
    history.table_resource.g.table,
    history.view_container_tree.v.table,
    tablefunc_connectivity.tf,
    history.view_equipment_attr.v.table,
)
