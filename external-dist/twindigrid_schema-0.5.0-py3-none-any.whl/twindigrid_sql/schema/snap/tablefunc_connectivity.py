"""
ProcedureComment
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy import event
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.ddl.meta_changes import GeneratedChangesTableDDL
from twindigrid_sql.ddl.view import CreateView, View
from twindigrid_sql.schema import history
from twindigrid_sql.schema.metadata import metadata_obj
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.callable import CreateCallable, SqlBody, TableFunction, CallableArg, TextBody

m = meta_from(__name__)


def based_on(meta, connectivity):
    def query(t=literal(None), a=literal(None)):
        q = (
            select(
                connectivity.c.uuid,
                connectivity.c.eq_fk,
                connectivity.c.cn_fk,
                connectivity.c.side,
                connectivity.c.eq_class,
                connectivity.c.container_fk,
                connectivity.c.indirect,
            )
        )

        return q


    v = View(
        name=meta.name, 
        schema=meta.schema,
        query=query(),
        comment=meta.comment,
    )

    event.listen(meta.metadata_object, 'after_create', CreateView(v, True))


    tf = TableFunction(
        name=f"{meta.name}", 
        schema=meta.schema,
        args=[
            arg_time := CallableArg(TIMESTAMPTZ, name='t'),
            arg_abstraction := CallableArg(UUID(), name='a'),
        ],
        volatility='STABLE',
        rettype=v,
        body=SqlBody([query(arg_time.col, arg_abstraction.col)]), 
    )

    event.listen(meta.metadata_object, 'after_create', CreateCallable(tf, True))
    
    return query, v, tf

query, v, tf = based_on(
    m,
    history.table_connectivity.g.table,
)