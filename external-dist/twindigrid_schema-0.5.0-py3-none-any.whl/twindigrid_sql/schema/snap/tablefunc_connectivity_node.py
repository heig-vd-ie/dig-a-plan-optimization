"""
ProcedureComment
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy import event
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.ddl.meta_changes import GeneratedChangesTableDDL
from twindigrid_sql.ddl.view import CreateView, View
from twindigrid_sql.entries.equipment_class import BUSBAR_SECTION
from twindigrid_sql.schema import history
from twindigrid_sql.schema.metadata import metadata_obj
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.callable import CreateCallable, SqlBody, TableFunction, CallableArg, TextBody
from . import tablefunc_connectivity

m = meta_from(__name__)

def based_on(meta, connectivity_node, container_tree, func_connectivity):
    def query(t=literal(None), a=literal(None)):
        cn = func_connectivity.func(t, a)

        cn_container = (
            select(
                cn.c.cn_fk.label('uuid'),
                func.nullif(
                    func.subpath(func.lca(func.array_agg(func.coalesce(container_tree.c.ancestors, 'root.self'))), -1),
                    'root'
                ).cast(TEXT).cast(UUID()).label("container_fk"),
            )
            .join(container_tree, container_tree.c.uuid == cn.c.container_fk, isouter=True)
            .group_by(cn.c.cn_fk)
        ).alias('eq_container')

        connector = (
            select(cn.c.cn_fk, cn.c.eq_fk.label('connector_fk'))
            .where(cn.c.eq_class == BUSBAR_SECTION)
        ).alias("connector")

        eqs = (
            select(cn.c.cn_fk, func.count(cn.c.eq_fk.distinct()).label('eq_count'))
            .group_by(cn.c.cn_fk)
        ).alias("connected_eq")

        q = (
            select(
                connectivity_node.c.uuid,
                connectivity_node.c.base_voltage_fk,
                cn_container.c.container_fk,
                connector.c.connector_fk,
                eqs.c.eq_count,
            )
            .join(cn_container, cn_container.c.uuid == connectivity_node.c.uuid, isouter=True)
            .join(connector, connector.c.cn_fk == connectivity_node.c.uuid, isouter=True)
            .join(eqs, eqs.c.cn_fk == connectivity_node.c.uuid, isouter=True)
        )

        return q


    v = View(
        name=meta.name, 
        schema=meta.schema,
        query=query(),
        comment=meta.comment,
    )

    event.listen(meta.metadata_object, 'after_create', CreateView(v, True))


    tf = TableFunction(
        name=f"{meta.name}", 
        schema=meta.schema,
        args=[
            arg_time := CallableArg(TIMESTAMPTZ, name='t'),
            arg_abstraction := CallableArg(UUID(), name='a'),
        ],
        volatility='STABLE',
        rettype=v,
        body=SqlBody([query(arg_time.col, arg_abstraction.col)]), 
    )

    event.listen(meta.metadata_object, 'after_create', CreateCallable(tf, True))

    return query, v, tf

query, v, tf = based_on(
    m,
    history.table_connectivity_node.g.table,
    history.view_container_tree.v.table,
    tablefunc_connectivity.tf,
)