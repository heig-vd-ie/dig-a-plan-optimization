"""
Contains the enum shared by all schemas.
"""
import enum

from twindigrid_sql.schema.metadata import Enum


class Diff(enum.Enum):
    CREATED = "+"
    UPDATED = "!"
    DELETED = "-"


class ResourceClassGroup(enum.Enum):
    CONTAINER = "container"
    EQUIPMENT = "equipment"


class Owner(enum.Enum):
    PRIVATE = "private"
    DSO = "dso"
    TSO = "tso"


class TerminalSide(enum.Enum):
    T1 = 't1'
    T2 = 't2'
    T3 = 't3'


class TerminalPhases(enum.Enum):
    ABC = 'ABC'
    ABCn = 'ABCn'
    An = 'An'
    Bn = 'Bn'
    Cn = 'Cn'
    AB = 'AB'
    BC = 'BC'
    CA = 'CA'
    ONE_PHASE = '1_phase'

class SwitchType(enum.Enum):
    FUSE = "fuse"
    SECTIONALISER = "sectionaliser"
    BREAKER = "breaker"
    DISCONNECTING_CIRCUIT_BREAKER = "disconnecting_circuit_breaker"
    LOAD_BREAK_SWITCH = "load_break_switch"
    FUSE_EQUIPED_LOAD_BREAK_SWITCH = "fuse_equiped_load_break_switch"
    LOCKED_SWITCH = "locked_switch"

class CommandType(enum.Enum):
    UNKNOWN = "unknown"
    MANUAL = "manual"
    REMOTE = "remote"


class ConnectionKind(enum.Enum):
    D = "D"
    Y = "Y"
    YN = "Yn"
    Z = "Z"


class ProfileType(enum.Enum):
    TELECOMMUNIATION = "telecommunication"
    STREET_LIGHTING = "street_lighting"
    CONSTRUCTION_SITE = "construction_site"
    GREAT_DISRUPTOR = "great_disruptor"
    GENERAL_BUILDING_SERVICES = "general_building_services"  # Light, lift, ... of a building
    RESIDENTIAL = "residential"
    COMMERCIAL = "commercial"
    INDUSTRIAL = "industrial"
    PUBLIC = "public"
    HEATING_SYSTEM = "heating_system"
    AIR_CONDITIONING = "air_conditioning"
    AUXILIARY_HEATING = "auxiliary_heating"
    BOILER = "boiler"
    HEAT_PUMP = "heat_pump"
    EV_CHARGER = "ev_charger"  # Electrical vehicle charger
    MOTOR = "motor"  # Electrical vehicle charger
    UNKNOWN = "unknown"


class GeneratingUnitType(enum.Enum):
    CHP = "chp"  # Combined Heat and Power
    HYDRO = "hydro"
    WIND = "wind"
    BIOMASS = "biomass"
    GAZ = "gaz"
    PV = "pv"
    UNKNOWN = "unknown"


class VoltageType(enum.Enum):
    LV = "LV"
    MV = "MV"
    HV = "HV"
    EHV = "EHV"


class SubstationType(enum.Enum):
    LV_LV = "LV_LV"
    MV_LV = "MV_LV"
    HV_MV = "HV_MV"
    COUPLING_CABINET = "coupling_cabinet"
    DISTRIBUTION_PANEL = "distribution_panel"


class MeasurementPhase(enum.Enum):
    ABC = 'ABC'
    AB = 'AB'
    BC = 'BC'
    CA = 'CA'
    A = 'A'
    B = 'B'
    C = 'C'
    AN = 'An'
    BN = 'Bn'
    CN = 'Cn'
    N = 'n'
    NG = 'ng'
    G = 'g'


class MeasurementClass(enum.Enum):
    POINT = "measurement_point"
    SPAN = "measurement_span"


class MeasurementColumn(enum.Enum):
    INT = "int_value"
    DOUBLE = "double_value"
    STR = "str_value"
