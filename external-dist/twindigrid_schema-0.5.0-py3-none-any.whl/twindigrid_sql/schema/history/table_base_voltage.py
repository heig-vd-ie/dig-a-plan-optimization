"""
Indicates the nominal voltage of a terminal.

This can be highly redundant but it can ease queries by a lot.
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams


class _Fields[T](NamedTuple):
    nominal_voltage: T = """The nominal voltage value. In V."""
    type: T = """Whever this nominal voltage is considered low, medium or high voltage (LV, MV or HV respectively)."""
    low_voltage_limit: T = """
    The minimum voltage. In V.
    """
    high_voltage_limit: T = """
    The maximum voltage. In V.
    """

m, f, c, i = meta_from(__name__).specify(TableMeta.inherits)(_Fields).explode()

def params(t: TableMeta) -> TableParams:
    return TableParams.of(
        m.Column(f.nominal_voltage, Integer,
            primary_key=True,
            autoincrement=False),
        m.Column(f.type, Enum(VoltageType),
            nullable=False),
        m.Column(f.low_voltage_limit, Integer,
            nullable=False),
        m.Column(f.high_voltage_limit, Integer,
            nullable=False),
    )

g = m.generate_ddl(params(m))
