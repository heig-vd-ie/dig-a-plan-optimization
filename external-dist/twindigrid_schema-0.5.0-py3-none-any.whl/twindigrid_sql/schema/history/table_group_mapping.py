"""
It contains the group mapping that allow mapping of `Equipment`, `Terminal` and `ConnectivityNode` across abstraction.
It is also used to indicate the abstraction layer that the equipment has been created. Therefore, all the `Equipment`, `Terminal` and `ConnectivityNode` in the root abstraction layers have a single group.
In following figures, we present two examples. The first one is where a number of series `Branch` and `BusbarSection` aggregated to one `Branch`. The second one is where a zero length `Branch` is removed and two `BusbarSection` at both ends will be aggregated to one `BusbarSection`.

<p align="center">
<img src="/assets/schema/abstraction_terminalMapping.svg" alt="Figure with an example of a terminal mapping" width="500" />
</p>
<p align="center" style="font-size:90%"><i>
First example of GroupMapping.
</i></p>
---
<p align="center">
<img src="/assets/schema/abstraction_cnMapping.svg" alt="Figure with an example of a connectivity node mapping" width="500" />
</p>
<p align="center" style="font-size:90%"><i>
Second example of GroupMapping.
</i></p>
---
<strong>Remark:</strong>  The object `GroupMapping` is added to keep the dependency among abstract and physical `Equipment`, `Terminal`, and `ConnectivityNode`. With this table, we can easily derive that each abstract `Equipment` is resulted from which physical one.   

Has the same uuid as the abstraction when it's a root abstraction.
Otherwise, the uuid is derived from the target `Equipment`, `Terminal` or `ConnectivityNode`.
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.history import mixin_period, table_abstraction
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams


class _Fields[T](NamedTuple):
    abstraction_fk: T = """
    The name of the abstraction layer that the `Equipment`, `Terminal` or `ConnectivityNode` has been created for.

    It's the abstraction of the sink group. We do not store abstraction of source group as equipment could be from multiple abstraction layer
    """


m, f, c, i = meta_from(__name__).specify(TableMeta.inherits)(_Fields).explode()

def params(t: TableMeta) -> TableParams:
    return mixin_period.params(t) + TableParams.of(
        m.Column(f.abstraction_fk, String,
            ForeignKey(table_abstraction.m.qt(table_abstraction.f.name)),
            nullable=False),
    )

g = m.generate_ddl(params(m))