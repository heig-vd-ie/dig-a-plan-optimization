"""
### Data classification:
---
The available data can be classified into the following categories, sub-categories, and sub-subcategories modeled by set of tables:

* Grid model:
Grid model information usually comes from **GIS** (Geographical Information System), **AIS** (Asset Information System), or **NIS** (Network Information System).
    * Equipment models:
        + `Equipment`, `Bess`, `Branch`, `EnergyConsumer`, `BusbarSection`, `ExternalNetwork`, `Pv`, `Switch`, `SynchronousGenerationUnit`, `Transformer`, `Tap`.
    *  Connectivity model:
        + `Terminal`, `ConnectivityNode`, `Connectivity`, `TopologyNode`, `Topology`, `ConnectedGroup`, `EquipmentConnectedGroup`.
    * Abstractions model:
        + `Abstraction`, `GroupMapping`, `EquipmentGroupMapping`, `TerminalMapping`, `CnMapping`.

* Electrical quantities measurements:
The electrical quantities can be any kind of grid measurements (e.g., **GridEye** data) and end-customer metering data (e.g., **smart metering** data).
    * Measurements model:
        + `MeasurementSource`, `MeasurementDevice`, `MeasurementTerminal`, `MeasurementValue`.
    * Events model:
        + `MeasurementEvent`, `SwitchEvent`, `TapEvent`, `BranchParameterEvent`, `TransformerParameterEvent`.
    * Heartbeat model:
        + `Heartbeat`.
---

### Views classification:
---
The available data can be inserted using the following view structure. For example, if we want to insert a new `Branch`, we use the `SnapBranch` to put new rows in all associated tables.

* Equipment models:
    * `SnapBess`, `SnapBranch`, `SnapBusbarSection`, `SnapEnergyConsumer`, `SnapExternalNetwork`, `SnapPv`, `SnapSwitch`, `SnapSynchronousGenerationUnit`, `SnapTransformer`.

* Connectivity model:
    * `SnapConnectivity`, `SnapTopology`, `ConnectivityEvent`, `TerminalTopology`.

* Abstractions model:
    * `AbstractionDepth`, `EquipmentBaseAbstraction`.

* Measurements model:
    * `SnapMeasurementDevice`.
---

### Naming convention rules:
---
1. The naming would be the same for the classes and attributes that exist within **CGMES** (Common Grid Model Exchange Specification).
2. The table name follows `PascalCase` (it begins with an uppercase letter), such as `ConnectivityNode`.
3. The attribute follows `snake_case` (it begins with a lowercase letter and each word is separated by an underscore).
4. The name of intermediary tables includes the names of both connected tables, e.g., `EquipmentGroupMapping`.
---

### Integrity constraints:
---
1. If the `value_source` of a `MeasurementDevice` is `estimated` or `forecasted`, then the `Abstraction` of that `MeasurementDevice` must be `abstract`.
2. If the `value_source` of a `MeasurementDevice` is `scada`, `smartMeter`, `gridEye`, `conventionalMeter`, or `aggregatedMeter`, then the `Abstraction` of that `MeasurementDevice` must be `physical`.
3. The `install_date` of each `Connectivity` must be before the `uninstall_date`.
4. The `record_install_date` of each `Connectivity` must be before the `record_uninstall_date`.
5. The `record_install_date` and `record_uninstall_date` of each `Connectivity` must be after the `install_date` and `uninstall_date`, respectively.
6. The geo attribute of `BusbarSection` is obligatory; however, the `geo` attributes of other equipment are optional.
7. If there are two `BusbarSection` not separated by any `Branch`, both must have same `geo`.
8. If there is a `geo` for a `Branch`, it should be a linestring from `t1` to `t2` without any repetition of the point in the linestring.
---

<p align="center">
<img src="https://www.depsys.com/assets/img/depsys_Identity-202008.png" alt="DEPsys logo" height="120"> <img src="https://heig-vd.ch/docs/default-source/doc-global-newsletter/2020-slim.svg" alt="HEIG-VD logo" height="80">
</p>
"""

# Static
from . import table_resource_class \
    , table_resource \
    , table_equipment \
    , table_terminal \
    , table_transformer \
    , table_transformer_end \
    , table_tap \
    , table_tap_event \
    , table_branch \
    , table_switch \
    , table_busbar_section \
    , table_energy_consumer \
    , table_generating_unit \
    , table_bess \
    , table_external_network \

# Dynamic
from . import table_heartbeat \
    , table_tap_event \
    , table_transformer_parameter_event \
    , table_branch_parameter_event \
    , table_geo_event \
    , table_switch_event \

# Topology
from . import table_connectivity \
    , table_connectivity_node \
    , table_base_voltage \
    , table_container \
    , table_substation \
    , table_client \

# Abstraction
from . import table_abstraction \
    , table_group_mapping \
    , table_equipment_mapping \
    , table_terminal_mapping \
    , table_cn_mapping \

# Measurement
from . import table_measurement \
    , table_source \
    , table_measurement_type \
    , table_unit_symbol \
    , table_operation_type \
    , table_measurement_point \
    , table_measurement_span \

# View
from . import view_equipment_attr \
            , view_container_attr \
            , view_container_tree \
            
# End
