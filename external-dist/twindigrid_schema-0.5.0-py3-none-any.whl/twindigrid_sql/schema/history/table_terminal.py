"""
An AC electrical connection point to a piece of conducting equipment.

Each `Equipment` can have one or two terminals and the `Equipment` are connected to each other by terminals connected to the same `ConnectivityNode`.
We have the following reasons for using the `Terminal` and `ConnectivityNode` model instead of the nodal connection between equipment:
1. It is close to the model used in IEC CIM (Common Information Model) family of standards and CGMES (Common Grid Model Exchange Specification).
2. We can simply define the exact location of a `MeasurementDevice` using this schema. Then, the direction of current, active, and reactive power will be determined.

To simplify the definition of the `Terminal`, we define each `Terminal` using the combination of `eq_fk` and `side`, in which `side` is one of the following values:
1. `t` for equipment with one terminal,
2. `t1` for higher voltage side of transformer and one of the branch/switch terminals,
3. `t2` for lower voltage side of transformer and one of the branch/switch terminals.
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.history import table_equipment
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams


class _Fields[T](NamedTuple):
    eq_fk: T = """Uuid of the equipment of the terminal determined by this row."""
    side: T = """
    Side of the `Equipment` for this terminal. `terminalside` is type of the terminal, which is either `t1`, `t2`, or `t`.
    1. `t` for equipment with one terminal,
    2. `t1` for higher voltage side of transformer and one of the branch/switch terminals,
    3. `t2` for lower voltage side of transformer and one of the branch/switch terminals.
    """
    phases: T = """Represents the phases of the terminal. `phases` is the type of this column, which is one of the following values: `ABC`, `ABCn`, `An`, `Bn`, `Cn`, `AB`, `BC`, `AC`."""

m, f, c, i = meta_from(__name__).specify(TableMeta.inherits)(_Fields).explode()

def params(t: TableMeta) -> TableParams:
    return TableParams.of(
        m.Column(f.eq_fk, UUID,
            ForeignKey(table_equipment.m.qt(table_equipment.f.uuid), ondelete='CASCADE'),
            primary_key=True),
        m.Column(f.side, Enum(TerminalSide),
            primary_key=True),
        m.Column(f.phases, Enum(TerminalPhases),
            server_default=literal(TerminalPhases.ABCn.value),
            nullable=False),
    )

g = m.generate_ddl(params(m))
