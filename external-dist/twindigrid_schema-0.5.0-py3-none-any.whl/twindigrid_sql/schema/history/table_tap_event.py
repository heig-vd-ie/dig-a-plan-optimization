"""
Grid events capture changes in the grid model, i.e., the change in status of tap of transformers.
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.history import mixin_equipment_event, table_tap, table_transformer
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams


class _Fields[T](NamedTuple):
    value: T = """Voltage level of tap position (Unit: `V`)."""
    side: T = """The tap side in the transformer."""

m, f, c, i = meta_from(__name__).specify(TableMeta.inherits)(_Fields).explode()

def params(t: TableMeta) -> TableParams:
    parent = mixin_equipment_event
    return parent.params(m, table_transformer.m) + TableParams.of(
        m.Column(f.value, Float,
            nullable=False),
        m.Column(f.side, Enum(TerminalSide),
            nullable=False),
        ForeignKeyConstraint(
            [parent.f.eq_fk, f.value, f.side],
            table_tap.m.qts([table_tap.f.eq_fk, table_tap.f.value, table_tap.f.side])
        ),
    )

g = m.generate_ddl(params(m))
