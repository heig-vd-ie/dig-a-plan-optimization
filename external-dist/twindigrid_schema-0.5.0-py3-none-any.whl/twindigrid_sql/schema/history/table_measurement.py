"""
A Measurement represents any measured, calculated or non-measured non-calculated quantity.

There are various specialisation of a measurement:

Span
: An span is a measurement that provide a single value over a period of time.
: The linked values are in the `measurement_span` table.

Point
: A point is a measurement that provide a single value for a single measured value at single point in time.
: The linked values are in the `measurement_point` table.

<details><summary>Implementation choices</summary>
The different specialisation (and their fields) are integrated in a single table. This allows to simplify the link with the measurement values.
</details>
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.ddl.constraints import CheckNotNullIf, CheckNotNullIfEquals
from twindigrid_sql.ddl.meta import TableMeta
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.history import mixin_period, table_measurement_type, table_operation_type, table_resource, table_source, table_terminal, table_unit_symbol
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams


class _Fields[T](NamedTuple):
    uuid: T = """
    Uuid of the measurement.
    """
    concrete_type: T = f"""
    The concrete type of this measurement, e.g. Aggregation, Point, etc.
    """
    resource_fk: T = """
    The power system resource (if it exists) that contains the measurement.
    """
    terminal_side: T = f"""
    If the measurement is linked to a terminal, indicates the terminal of the equipment defined by resource_fk.
    """
    phase: T = """
    Indicates to which phases the measurement applies and avoids the need to use `measurement_type` to also encode phase information (which would explode the types). 
    """
    measurement_type: T = """
    Specifies the type of measurement. For example, this specifies if the measurement represents 
    an indoor temperature, outdoor temperature, bus voltage, line flow, etc.

    A separate table contains all possible values.
    """
    unit_multiplier: T = """
    The unit multiplier of the measured quantity.

    A unit multiplier is specified as an exponent of 10. For exemple, if an associated `measurement_value` 
    has a value of 12345, the unit_symbol is 'V' and the unit_multiplier is -2, then the exact measurement
    is 12345 * 10^(-2) V = 123.45 V.
    """
    unit_symbol: T = """
    The unit of measure of the measured quantity in its short form, e.g `V` instead of `volt` or `kg*m²*C⁻¹*s⁻²`.

    A separate table contains all possible values.
    """
    column_type: T = """
    The column which contains the value in `measurement_value`. If null, then there are no associated measurement values.
    """
    source_fk: T = """
    A reference to the type of source that updates the `measurement`'s values, e.g. SCADA, SmartMeter, Manual, DigitalTwinAlgorithm, etc.
    """
    sensor_accuracy: T = """
    The limit, expressed as a percentage of the sensor maximum, that errors will not exceed when the sensor is used under reference conditions.
    """
    name: T = """
    The name is any free human readable and possibly non unique text naming this measurement.
    """
    description: T = """
    The description is a free human readable text describing or naming the measurement. It may be non unique and may not correlate to a naming hierarchy.
    """
    metadata: T = """
    JSON document containing various metadata pertaining to this measurment.
    """

    #
    # Field of aggregation specialisation.
    #
    op_type: T = """
    Indicates which type of operation (if any) it is, e.g. MIN, MAX, AVG, MEDIAN, SUM, etc.

    A separate table contains all possible values.
    """
    over_measurement_fk: T = """
    If this measurement is a computation, link to the computed measurement. The computed measurement may not have any linked measurement values.

    This allows linking measurements together and also to have multiple computation.
    """
    default_period: T = """
    If this measurement is an aggregation, the aggregation period in seconds.

    An associated `measurement_value` at time `t` aggregates measures over time `t - aggregation_period` and `t`.
    """


class _Constraints[T](NamedTuple):
    span_field_default_period: T = """
    The default period is required if measurement is a span.
    """

m, f, c, i = meta_from(__name__).specify(TableMeta.inherits)(_Fields, _Constraints).explode()

def params(t: TableMeta) -> TableParams:
    is_span = (f.concrete_type, MeasurementClass.SPAN.value)
    return mixin_period.params(t) + TableParams.of(
        m.Column(f.concrete_type, Enum(MeasurementClass),
            nullable=False),
        m.Column(f.resource_fk, UUID,
            ForeignKey(table_resource.m.qt(table_resource.f.uuid)),
            nullable=True),
        m.Column(f.terminal_side, Enum(TerminalSide),
            nullable=True),
        ForeignKeyConstraint(
            [f.resource_fk, f.terminal_side],
            table_terminal.m.qts([table_terminal.f.eq_fk, table_terminal.f.side]),
        ),
        m.Column(f.phase, Enum(MeasurementPhase),
            nullable=False),
        m.Column(f.measurement_type, String,
            ForeignKey(table_measurement_type.m.qt(table_measurement_type.f.name)),
            nullable=False),
        m.Column(f.unit_multiplier, Integer,
            server_default=literal(0),
            nullable=False),
        m.Column(f.unit_symbol, String,
            ForeignKey(table_unit_symbol.m.qt(table_unit_symbol.f.name)),
            nullable=False),
        m.Column(f.column_type, Enum(MeasurementColumn),
            nullable=True),
        m.Column(f.source_fk, String,
            ForeignKey(table_source.m.qt(table_source.f.name)),
            nullable=False),
        m.Column(f.sensor_accuracy, Float,
            nullable=True),
        m.Column(f.name, String,
            nullable=True),
        m.Column(f.description, String,
            nullable=True),
        m.Column(f.metadata, JSONB,
            nullable=True),
        m.Column(f.op_type, String,
            # TODO: find a way to have foreign key for each section (.AVG.SUM)
            # ForeignKey(table_operation_type.m.qt(table_operation_type.f.name)),
            nullable=True),
        m.Column(f.over_measurement_fk, UUID,
            ForeignKey(m.qt(f.uuid)),
            nullable=True),
        m.Column(f.default_period, Integer,
            nullable=True),
        m.CheckConstraint(c.span_field_default_period, 
            CheckNotNullIfEquals(f.default_period, *is_span)),
    )

g = m.generate_ddl(params(m))