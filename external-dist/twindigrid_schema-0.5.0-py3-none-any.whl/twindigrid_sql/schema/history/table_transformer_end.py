"""
An electrical device consisting of two windings, with or without a magnetic core, for introducing mutual coupling between electric circuits. Transformers can be used to control voltage and phase shift (active power flow). A power transformer may be composed of separate transformer tanks that need not be identical. A power transformer can be modeled with or without tanks and is intended for use in both balanced and unbalanced representations. A power transformer typically has two terminals, but may have one (grounding), three or more terminals.
<strong>Remark:</strong> The higher voltage terminal of a transformer is on side `t1`.
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.history import mixin_equipment_specialisation, table_equipment, table_terminal, table_transformer
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams


class _Fields[T](NamedTuple):
    eq_fk: T = """Uuid of the transformer which has this end."""
    side: T = """The terminal associated to this transformer end."""
    ck: T = """Connection kind."""
    phase_angle: T = """Phase angle."""
    nominal_voltage: T = """Nominal voltage. In V."""

m, f, c, i = meta_from(__name__).specify(TableMeta.inherits)(_Fields).explode()

def params(t: TableMeta) -> TableParams:
    return TableParams.of(
        m.Column(f.eq_fk, UUID,
            ForeignKey(table_transformer.m.qt(mixin_equipment_specialisation.f.uuid), ondelete='CASCADE'),
            primary_key=True),
        m.Column(f.side, Enum(TerminalSide),
            primary_key=True),
        ForeignKeyConstraint(
            [f.eq_fk, f.side],
            table_terminal.m.qts([table_terminal.f.eq_fk, table_terminal.f.side]),
        ),
        m.Column(f.ck, Enum(ConnectionKind),
            nullable=False),
        m.Column(f.phase_angle, Integer,
            CheckConstraint("phase_angle in (0,1,2,3,4,5,6,7,8,9,10,11)"),
            nullable=False),
        m.Column(f.nominal_voltage, Integer,
            nullable=False),
    )

g = m.generate_ddl(params(m))
