"""
Represent a physical or abstract equipment that can be `installed` multiple times. The parts of a power system that are physical devices, electronic or mechanical.

The common attributes (`name`, `concrete_type`, `geo`, `uuid`) of different child tables are listed as columns in the parent table of `Equipment`.
For example, `Switch` is a child table of `Equipment` and contains the attributes `name`, `concrete_type`, `geo`, `uuid`, and specific attributes of the switches.

<strong>Remark:</strong> Uuid of `Equipment` keep the record of its installation in different locations. An `Equipment` has an `Uuid` over its lifetime. If an `Equipment` is replaced from location A to B (based on uninstall and install dates), the new rows in table of `Connectivity` will be inserted. The grid topology and model at each time instance can be determined only using the information of installed `Equipment`.
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import UUID, JSONB, TIMESTAMP

from twindigrid_sql.schema.history import table_resource
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams


class _Fields[T](NamedTuple):
    uuid: T = """
    Uuid of the equipment determined by this row.
    """


m, f, c, i = meta_from(__name__).specify(TableMeta.inherits)(_Fields).explode()

def params(t: TableMeta) -> TableParams:
    return TableParams.of(
        m.Column(f.uuid, UUID,
            ForeignKey(table_resource.m.qt(table_resource.f.uuid), ondelete='CASCADE'),
            primary_key=True),
    )

g = m.generate_ddl(params(m))
