"""
Overhead or underground cables/lines that connects the equipment of a grid in a geographical region.
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.history import mixin_equipment_specialisation, table_equipment
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams


class _Fields[T](NamedTuple):
    section: T = """
    Section of`Branch` (Symbol: `S`, Unit: `mm2`)
    """
    current_limit: T = """
    Nominal current of `Branch` (Symbol: `I_b_nom`, Unit: `A`)
    """
    length: T = """
    Length of `Branch` (Symbol: `L_b`, Unit: `km`)
    """
    is_underground: T = """
    Boolean that determines whether the `Branch` is underground or not; `True` if it is underground and `False` otherwise.

    **Remark:** When this columns is null, it means that the `Branch` is a mixture of underground and over overground.
    """

m, f, c, i = meta_from(__name__).specify(TableMeta.inherits)(_Fields).explode()

def params(t: TableMeta) -> TableParams:
    return mixin_equipment_specialisation.params(t) + TableParams.of(
        m.Column(f.section, Float,
            nullable=True),
        m.Column(f.current_limit, Float,
            nullable=False),
        m.Column(f.length, Float,
            nullable=False),
        m.Column(f.is_underground, Boolean,
            nullable=True),
    )

g = m.generate_ddl(params(m))
