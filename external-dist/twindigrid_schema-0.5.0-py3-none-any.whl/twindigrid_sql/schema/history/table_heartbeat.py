"""
Logs all the heartbeats performed.
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams

class _Fields[T](NamedTuple):
    heartbeat: T = """
    Instant when the heartbeat (and all associated data) was processed
    """

m, f, c, i = meta_from(__name__).specify(TableMeta.inherits)(_Fields).explode()

def params(t: TableMeta) -> TableParams:
    return TableParams.of(
        m.Column(f.heartbeat, TIMESTAMPTZ,
            primary_key=True),
    )

g = m.generate_ddl(params(m))
