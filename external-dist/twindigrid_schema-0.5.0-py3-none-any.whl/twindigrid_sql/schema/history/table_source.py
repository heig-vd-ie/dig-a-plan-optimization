"""
Source of a measurement or an equipment event.
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.history import table_abstraction
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams


class _Fields[T](NamedTuple):
    name: T = """
    The name of the source.
    """
    description: T = """
    The description of the source
    """
    abstraction_fk: T = """
    The name of the abstraction layer to which this source belongs.
    """

m, f, c, i = meta_from(__name__).specify(TableMeta.inherits)(_Fields).explode()

def params(t: TableMeta) -> TableParams:
    return TableParams.of(
        m.Column(f.name, String, 
            primary_key=True),
        m.Column(f.description, String, 
            nullable=True),
        m.Column(f.abstraction_fk, String,
            ForeignKey(table_abstraction.m.qt(table_abstraction.f.name)),
            nullable=False),
    )

g = m.generate_ddl(params(m))