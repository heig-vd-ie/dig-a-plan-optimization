"""
Grid events capture changes in the grid model, i.e., the geo path of branches.
"""

from typing import NamedTuple
from geoalchemy2 import Geography
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.history import mixin_resource_event, table_resource
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams


class _Fields[T](NamedTuple):
    geo: T = """
    Linestring that indicates the path of a branch
    """

m, f, c, i = meta_from(__name__).specify(TableMeta.inherits)(_Fields).explode()

def params(t: TableMeta) -> TableParams:
    parent = mixin_resource_event
    return parent.params(m) + TableParams.of(
        m.Column(f.geo, Geography,
            nullable=False),
    )

g = m.generate_ddl(params(m))
