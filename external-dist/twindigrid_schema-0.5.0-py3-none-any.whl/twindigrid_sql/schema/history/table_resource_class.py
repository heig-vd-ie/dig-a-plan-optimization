"""
Possible measurement type values.
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.ddl.constraints import CheckNotNullOnlyIfEquals
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams


class _Fields[T](NamedTuple):
    name: T = """
    The name of the resource class.
    """
    description: T = """
    The description of the resource class.
    """
    group: T = """
    The group of the resource class. Whether it is an EQUIPMENT or a CONTAINER.
    """
    valid_sides: T = """
    The valid sides for terminals of an equipment. The terminals of an equipment of the class uses a subset of the sides.
    """
    metadata_schema: T = """
    The JSON Schema for the metadata of the associated resource.
    """

class _Constraints[T](NamedTuple):
    required_sides_only_for_equipment: T = """
    The valid sides are required if group is an equipment.
    """

m, f, c, i = meta_from(__name__).specify(TableMeta.inherits)(_Fields, _Constraints).explode()

def params(t: TableMeta) -> TableParams:
    return TableParams.of(
        m.Column(f.name, String, 
            primary_key=True),
        m.Column(f.group, Enum(ResourceClassGroup),
            nullable=False),
        m.Column(f.valid_sides, ARRAY(Enum(TerminalSide)),
            nullable=True),
        m.Column(f.description, String, 
            nullable=True),
        m.Column(f.metadata_schema, JSONB, 
            nullable=True),
        m.CheckConstraint(c.required_sides_only_for_equipment, 
            CheckNotNullOnlyIfEquals(f.valid_sides, f.group, ResourceClassGroup.EQUIPMENT.value)),
    )

g = m.generate_ddl(params(m))