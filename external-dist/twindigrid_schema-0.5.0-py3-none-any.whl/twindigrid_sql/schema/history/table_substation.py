"""
Substation which contains equipements either directly of via it's voltage level and bay.
"""

from typing import NamedTuple
from geoalchemy2 import Geography
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.ddl.constraints import CheckNotNullIfEquals
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.history import mixin_container_specialisation
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams


class _Fields[T](NamedTuple):
    type: T = """
    The type of the substation.
    """
    address: T = """
    The postal address if applicable.

    Required if the substation is a `distribution_panel`.
    """
    building_id: T = """
    The building id.

    Required if the substation is a `distribution_panel`.

    If prefixed by `CH-` the number corresponds to the federal building id ([EGID](https://www.bfs.admin.ch/bfs/fr/home/registres/registre-personnes/harmonisation-registres/egid-ewid.html)).
    If prefixed by `GE-` the number corresponds to the Geneva building id.
    """


class _Constraints[T](NamedTuple):
    required_address_for_distribution_panel: T = """
    The address is required if substation is a distribution panel.
    """
    required_egid_for_distribution_panel: T = """
    The egid is required if substation is a distribution panel.
    """

m, f, c, i = meta_from(__name__).specify(TableMeta.inherits)(_Fields, _Constraints).explode()

def params(t: TableMeta) -> TableParams:
    return mixin_container_specialisation.params(t) + TableParams.of(
        m.Column(f.type, Enum(SubstationType),
            nullable=False),
        m.Column(f.address, String,
            nullable=True),
        m.Column(f.building_id, String,
            nullable=True),
        m.CheckConstraint(c.required_address_for_distribution_panel, 
            CheckNotNullIfEquals(f.address, f.type, SubstationType.DISTRIBUTION_PANEL.value)),
        m.CheckConstraint(c.required_egid_for_distribution_panel, 
            CheckNotNullIfEquals(f.building_id, f.type, SubstationType.DISTRIBUTION_PANEL.value)),
    )

g = m.generate_ddl(params(m))
