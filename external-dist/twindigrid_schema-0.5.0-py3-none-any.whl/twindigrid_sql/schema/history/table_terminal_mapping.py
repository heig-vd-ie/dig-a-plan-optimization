"""
Contains the group mapping that allow mapping of `Terminal` across abstraction.

For a given group mapping, a source terminal can have only one sink terminal. If a modification to the grid changes the terminal mapping, then a new group mapping should be created.
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.history import mixin_period, table_group_mapping, table_terminal
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams


class _Fields[T](NamedTuple):
    gm_fk: T = """
    The uuid of the `GroupMapping` that represents the relationship among a number of `Terminal` across abstraction.
    """
    source_eq_fk: T = """
    The uuid of the `Equipment` that its terminal is source of this group mapping.
    """
    source_side: T = """
    Side of the terminal that is source of this group mapping. Either `t1`, `t2`, or `t`.
    """
    sink_eq_fk: T = """
    The uuid of the `Equipment` that its terminal is sink of this group mapping.
    """
    sink_side: T = """
    Side of the terminal that is sink of this group mapping. Either `t1`, `t2`, or `t`.
    """

m, f, c, i = meta_from(__name__).specify(TableMeta.inherits)(_Fields).explode()

def params(t: TableMeta) -> TableParams:
    return TableParams.of(
        m.Column(f.gm_fk, UUID, 
            ForeignKey(table_group_mapping.m.qt(mixin_period.f.uuid)),
            primary_key=True),
        m.Column(f.source_eq_fk, UUID,
            primary_key=True),
        m.Column(f.source_side, Enum(TerminalSide),
            primary_key=True),
        ForeignKeyConstraint(
            [f.source_eq_fk, f.source_side],
            table_terminal.m.qts([table_terminal.f.eq_fk, table_terminal.f.side])),
        m.Column(f.sink_eq_fk, UUID,
            nullable=False),
        m.Column(f.sink_side, Enum(TerminalSide),
            nullable=False),
        ForeignKeyConstraint(
            [f.sink_eq_fk, f.sink_side],
            table_terminal.m.qts([table_terminal.f.eq_fk, table_terminal.f.side])),
    )

g = m.generate_ddl(params(m))