"""
TableComment
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.history import mixin_period, table_heartbeat
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams
from sqlalchemy.sql import expression as expr



class _Fields[T](NamedTuple):
    start: T = """The instant it started."""
    end: T = """The instant it ended."""


class _Constraints[T](NamedTuple):
    time_causality: T = """
    The installation must precede the uninstallation.
    """
    time_before_heartbeat: T = """
    The event time should precede the heartbeat time.
    """


m, f, c, i = meta_from(__name__).specify(TableMeta.inherits)(_Fields, _Constraints).explode()

def params(t: TableMeta) -> TableParams:
    return mixin_period.params(t) + TableParams.of(
        m.Column(f.start, TIMESTAMPTZ,
            nullable=True),
        m.Column(f.end, TIMESTAMPTZ,
            nullable=True),
        m.CheckConstraint(c.time_causality, 
            expr.or_(
                Column(f.end) > Column(f.start),
                Column(f.end) == expr.null(),
            )),
        m.CheckConstraint(c.time_before_heartbeat,
            expr.and_(
                Column(f.start) <= Column(mixin_period.f.start_heartbeat),
                Column(f.end) <= Column(mixin_period.f.end_heartbeat),
            )),
    )
