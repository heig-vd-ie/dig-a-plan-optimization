"""
Measurement value at a point in time.
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.history import mixin_event, mixin_measurement_value
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams


m, f, c, i = meta_from(__name__).specify(TableMeta.inherits)().explode()

def params(t: TableMeta) -> TableParams:
    return mixin_event.params(t) + mixin_measurement_value.params(t)

g = m.generate_ddl(params(m))
