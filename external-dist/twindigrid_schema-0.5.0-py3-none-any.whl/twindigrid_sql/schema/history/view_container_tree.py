"""
ViewComment
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy import event
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.ddl.view import CreateView, View
from twindigrid_sql.dql.recursive_cte import recursive_cte
from . import table_container
from twindigrid_sql.schema.metadata import metadata_obj
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams

m = meta_from(__name__)


def based_on(meta, container):
    cont_alias = container.alias()
    rec = recursive_cte(
        select(
            container.c.uuid, 
            array([container.c.uuid]).label('path'),
            func.text2ltree("root").concat(container.c.uuid.cast(TEXT)).label("ancestors"),
        )
        .where(container.c.parent_fk.is_(None)),
        'UNION ALL',
        lambda rc_alias:
        select(
            cont_alias.c.uuid, 
            rc_alias.c.path.concat(cont_alias.c.uuid),
            rc_alias.c.ancestors.concat(cont_alias.c.uuid.cast(TEXT)).label("ancestors"),
        )
        .where(rc_alias.c.uuid == cont_alias.c.parent_fk),
        name="container_tree_rec",
    )

    q = select(rec.c.uuid, rec.c.ancestors.concat('self').label("ancestors"), rec.c.path)

    v = View(
        name=meta.name, 
        schema=meta.schema,
        query=q,
        comment=meta.comment,
    )

    event.listen(meta.metadata_object, 'after_create', CreateView(v, True))

    return v

v = based_on(m, table_container.g.table)
