"""
Parameter events capture all changes in the parameters equipment due to aging or new calculation.
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.history import mixin_parameter_event, table_branch
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams


m, f, c, i = meta_from(__name__).specify(TableMeta.inherits)().explode()

def params(t: TableMeta) -> TableParams:
    return mixin_parameter_event.params(t, table_branch.m)

g = m.generate_ddl(params(m))
