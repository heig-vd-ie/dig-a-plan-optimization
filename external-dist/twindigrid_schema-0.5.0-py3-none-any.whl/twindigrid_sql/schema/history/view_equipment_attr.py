"""
ViewComment
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy import event
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.ddl.view import CreateView, View
from twindigrid_sql.dql.attr_extractor import AttrExtractor, AttrMerger, attr_extractor_from_table
from . import table_bess, table_branch, table_busbar_section, table_energy_consumer, table_external_network, table_generating_unit, table_resource, table_switch, table_tap, table_transformer, table_transformer_end
from twindigrid_sql.schema.metadata import metadata_obj
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams

m = meta_from(__name__)


def attr_extractor_from_transformer() -> AttrExtractor:
    table = table_transformer.g.table
    ends = table_transformer_end.g.table
    tap = table_tap.g.table

    # Add the possible tap values to the transformer_end
    ends_with_tap = (
        select(ends, func.array_agg(tap.c.value).label("taps"))
        .select_from(ends.join(tap, and_(*[c == tap.c[c.name] for c in ends.primary_key.columns]), isouter=True))
        .group_by(*ends.primary_key.columns)
    ).alias("ends_with_taps")

    ends_attr = AttrExtractor(
        query=ends_with_tap,
        name=ends_with_tap.name,
        join_columns=[ends_with_tap.corresponding_column(c) for c in ends.primary_key.columns],
        json_columns=[
            *[ends_with_tap.corresponding_column(c) for c in ends.columns if not ends.primary_key.columns.contains_column(c)],
            ends_with_tap.c.taps,
        ],
    )

    transformer_with_ends = (
        select(table, func.jsonb_object_agg(ends_attr.select.c.side, ends_attr.select.c.attr).label("ends"))
        .select_from(table.join(ends_attr.select, ends_attr.select.c.eq_fk == table.c.uuid, isouter=True))
        .group_by(*table.primary_key.columns)
    ).alias("transformer_with_ends")

    return AttrExtractor(
        query=transformer_with_ends,
        name=table.name,
        join_columns=[transformer_with_ends.corresponding_column(c) for c in table.primary_key.columns],
        json_columns=[
            *[transformer_with_ends.corresponding_column(c) for c in table.columns if not table.primary_key.columns.contains_column(c)],
            transformer_with_ends.c.ends,
        ],
    )


def based_on(meta, resource, spec_extractors):

    q = AttrMerger(
            parent_table=resource,
            pk_cols=[resource.c.uuid],
            class_col=resource.c.concrete_class,
            spec_data=spec_extractors,
        ).select()

    v = View(
        name=meta.name, 
        schema=meta.schema,
        query=q,
        comment=meta.comment,
    )

    event.listen(meta.metadata_object, 'after_create', CreateView(v, True))

    return v

spec_extractors = [
    attr_extractor_from_table(table_bess.g.table),
    attr_extractor_from_table(table_switch.g.table),
    attr_extractor_from_table(table_external_network.g.table),
    attr_extractor_from_transformer(),
    attr_extractor_from_table(table_energy_consumer.g.table),
    attr_extractor_from_table(table_branch.g.table),
    attr_extractor_from_table(table_busbar_section.g.table),
    attr_extractor_from_table(table_generating_unit.g.table),
]

v = based_on(m, table_resource.g.table, spec_extractors)
