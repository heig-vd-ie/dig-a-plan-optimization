"""
Switches, breakers, or disconnectors. A generic device designed to close, or open, or both, one or more electric circuits. All switches are two terminal devices including grounding switches.
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.history import mixin_equipment_specialisation, table_equipment
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams


class _Fields[T](NamedTuple):
    normal_open: T = """
    Normal state of the switch (Symbol: `u0_s`); `False`: close, `True`: open.
    """
    type: T = """
    Type of switch.
    """
    command: T = """
    Whether the switch is manually or remotely controllable.
    """

m, f, c, i = meta_from(__name__).specify(TableMeta.inherits)(_Fields).explode()

def params(t: TableMeta) -> TableParams:
    return mixin_equipment_specialisation.params(t) + TableParams.of(
        m.Column(f.normal_open, Boolean,
            server_default=literal(False),
            nullable=False),
        m.Column(f.type, Enum(SwitchType),
            nullable=False),
        m.Column(f.command, Enum(CommandType),
            nullable=False),
    )

g = m.generate_ddl(params(m))
