"""
Connectivity nodes are points where terminals of conducting equipment are connected together with zero impedance.
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.history import table_base_voltage, table_container
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams


class _Fields[T](NamedTuple):
    uuid: T = """
    The uuid of this connectivity node.
    """
    base_voltage_fk: T = """
    The value of base voltage for this connectivity node.

    Mostly computed value because most connectivity node are inside a voltage level,
    however some may be directly in a substation and still have a base voltage.
    """


m, f, c, i = meta_from(__name__).specify(TableMeta.inherits)(_Fields).explode()

def params(t: TableMeta) -> TableParams:
    return TableParams.of(
        m.Column(f.uuid, UUID, 
            primary_key=True),
        m.Column(f.base_voltage_fk, Integer,
            ForeignKey(table_base_voltage.m.qt(table_base_voltage.f.nominal_voltage)),
            nullable=True),
    )

g = m.generate_ddl(params(m))