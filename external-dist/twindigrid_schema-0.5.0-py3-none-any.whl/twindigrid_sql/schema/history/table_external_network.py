"""
This class represents external network and it is used for IEC 60909 calculations.
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.history import mixin_equipment_specialisation, table_equipment
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams


class _Fields[T](NamedTuple):
    r_eq: T = """
    The equivalent resistance of External Network to consider multiple upstream networks (Symbol: `R_ex_eq`, Unit: `Ohms`).
    """
    x_eq: T = """
    The equivalent inductance of External Network to consider multiple upstream networks (Symbol: `X_eq_eq`, Unit: `Ohms`).
    """

m, f, c, i = meta_from(__name__).specify(TableMeta.inherits)(_Fields).explode()

def params(t: TableMeta) -> TableParams:
    return mixin_equipment_specialisation.params(t) + TableParams.of(
        m.Column(f.r_eq, Float,
            server_default=literal(0),
            nullable=False),
        m.Column(f.x_eq, Float,
            server_default=literal(0),
            nullable=False),
    )

g = m.generate_ddl(params(m))
