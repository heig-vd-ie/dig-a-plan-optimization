"""
Possible operation type values.

Can be an aggregation (e.g. MIN, MAX, AVG, MEDIAN) or a computation (e.g. HARMONIC2, HARMONIC3).
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams


class _Fields[T](NamedTuple):
    name: T = """
    The name of the operation
    """

m, f, c, i = meta_from(__name__).specify(TableMeta.inherits)(_Fields).explode()

def params(t: TableMeta) -> TableParams:
    return TableParams.of(
        m.Column(f.name, String, 
            primary_key=True),
    )

g = m.generate_ddl(params(m))