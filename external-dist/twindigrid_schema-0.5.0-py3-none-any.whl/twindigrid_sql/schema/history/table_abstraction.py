"""
It contains the abstraction layer and inheritance.
In following figures, we present two examples. The first one is where a number of series `Branch` and `BusbarSection` aggregated to one `Branch`. The second one is where a zero length `Branch` is removed and two `BusbarSection` at both ends will be aggregated to one `BusbarSection`.

<p align="center">
<img src="/assets/schema/abstraction_terminalMapping.svg" alt="Figure with an example of a terminal mapping" width="500" />
</p>
<p align="center" style="font-size:90%"><i>
First example of abstraction.
</i></p>
---
<p align="center">
<img src="/assets/schema/abstraction_cnMapping.svg" alt="Figure with an example of a connectivity node mapping" width="500" />
</p>
<p align="center" style="font-size:90%"><i>
Second example of abstraction.
</i></p>
---
<strong>Remark:</strong> The object `Abstraction` is defined to individuate among `Equipment`, `Terminal`, `ConnectivityNode`, and `TopologicalNode` in the `physical` and `abstract` models. Note that it is possible one `Equipment` or `Terminal` is in both layers.
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams


class _Fields[T](NamedTuple):
    name: T = """
    Name of the abstraction determined by this row.
    """
    description: T = """
    The details about the current abstraction.
    """
    parent_fk: T = """
    The name of the parent abstraction. It indicates that the abstraction determined by this row inherits by default the equipment and connectivity of its parent abstraction.

    <strong>Remark:</strong> When this columns is null, the abstraction layer is a base `physical` layer.
    """

m, f, c, i = meta_from(__name__).specify(TableMeta.inherits)(_Fields).explode()

def params(t: TableMeta) -> TableParams:
    return TableParams.of(
        m.Column(f.name, String,
            primary_key=True),
        m.Column(f.description, String, 
            nullable=True),
        m.Column(f.parent_fk, String,
            ForeignKey(m.qt(f.name)))
    )

g = m.generate_ddl(params(m))
