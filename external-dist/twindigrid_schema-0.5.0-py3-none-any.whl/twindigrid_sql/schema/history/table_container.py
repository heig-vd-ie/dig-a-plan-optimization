"""
Regroup equipment installed together.
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.ddl.constraints import CheckNotNullIfEquals
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.history import table_resource
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams


class _Fields[T](NamedTuple):
    uuid: T = """
    Uuid of the container.
    """
    parent_fk: T = """
    Uuid of the parent container. If null the container has no parent.
    """

m, f, c, i = meta_from(__name__).specify(TableMeta.inherits)(_Fields).explode()

def params(t: TableMeta) -> TableParams:
    return TableParams.of(
        m.Column(f.uuid, UUID,
            ForeignKey(table_resource.m.qt(table_resource.f.uuid), ondelete='CASCADE'),
            primary_key=True),
        m.Column(f.parent_fk, UUID,
            ForeignKey(m.qt(f.uuid)),
            nullable=True),
    )

g = m.generate_ddl(params(m))
