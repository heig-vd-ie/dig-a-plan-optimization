"""
TableComment
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.ddl.constraints import CheckOnlyOneNotNull
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.history import table_heartbeat, table_measurement
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams


class _Fields[T](NamedTuple):
    double_value: T = """
    Floating point value.
    """
    int_value: T = """
    Integer value.
    """
    string_value: T = """
    String value.
    """
    measurement_fk: T = """
    The uuid of the linked measurement.
    """


class _Constraints[T](NamedTuple):
    only_one_value: T = """
    Only one value field can be not null.
    """


m, f, c, i = meta_from(__name__).specify(TableMeta.inherits)(_Fields, _Constraints).explode()

def params(t: TableMeta) -> TableParams:
    return TableParams.of(
        m.Column(f.measurement_fk, UUID,
            ForeignKey(table_measurement.m.qt(table_measurement.f.uuid))),
        m.Column(f.double_value, Float,
            nullable=True),
        m.Column(f.int_value, Integer,
            nullable=True),
        m.Column(f.string_value, String,
            nullable=True),
        m.CheckConstraint(c.only_one_value, CheckOnlyOneNotNull(f.double_value, f.int_value, f.string_value))
    )
