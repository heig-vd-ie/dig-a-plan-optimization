"""
Contains the group mapping that allow mapping of `ConnectivityNode` across abstraction.
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.history import mixin_period, table_connectivity_node, table_group_mapping
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams


class _Fields[T](NamedTuple):
    gm_fk: T = """
    The uuid of the `GroupMapping` which represents the relationship among a number of `ConnectivityNode` across abstraction.
    """
    source_cn_fk: T = """
    The uuid of the `ConnectivityNode` that is source of this group mapping.
    """
    sink_cn_fk: T = """
    The uuid of the `ConnectivityNode` that is sink of this group mapping.
    """

m, f, c, i = meta_from(__name__).specify(TableMeta.inherits)(_Fields).explode()

def params(t: TableMeta) -> TableParams:
    return TableParams.of(
        m.Column(f.gm_fk, UUID, 
            ForeignKey(table_group_mapping.m.qt(mixin_period.f.uuid)),
            primary_key=True),
        m.Column(f.source_cn_fk, UUID,
            ForeignKey(table_connectivity_node.m.qt(table_connectivity_node.f.uuid)),
            nullable=False),
        m.Column(f.sink_cn_fk, UUID,
            ForeignKey(table_connectivity_node.m.qt(table_connectivity_node.f.uuid)),
            primary_key=True),
    )

g = m.generate_ddl(params(m))