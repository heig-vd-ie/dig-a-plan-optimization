"""
Parameter events capture all changes in the parameters equipment due to aging or new calculation.
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.history import mixin_equipment_event
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams


class _Fields[T](NamedTuple):
    r: T = """Resistance (star-model) of the transformer at the lower voltage side. The attribute shall be equal or greater than zero for non-equivalent transformers (Symbol: `R_trf`, Unit: `Ohms`)."""
    r0: T = """Zero sequence series resistance (star-model) at the lower voltage side (Symbol: `R0_trf`, Unit: `Ohms`)."""
    x: T = """Positive sequence series reactance (star-model) at fundamental frequency at the lower voltage side (Symbol: `X_trf`, Unit: `Ohms`)."""
    x0: T = """Zero sequence series reactance at the lower voltage side (Symbol: `X0_trf`, Unit: `Ohms`)."""
    b: T = """Magnetizing branch susceptance (B mag) at fundamental frequency at the lower voltage side. The value can be positive or negative (Symbol: `B_trf`, Unit: `Siemens`)."""
    b0: T = """Zero sequence magnetizing branch susceptance at the lower voltage side (Symbol: `B0_trf`, Unit: `Siemens`)."""
    g: T = """Magnetizing branch conductance at the lower voltage side of transformer (Symbol: `G_trf`, Unit: `Siemens`)."""
    g0: T = """Zero sequence magnetizing branch conductance (star-model) at the lower voltage side (Symbol: `G0_trf`, Unit: `Siemens`)."""

m, f, c, i = meta_from(__name__).specify(TableMeta.inherits)(_Fields).explode()

def params(t: TableMeta, equipment: TableMeta) -> TableParams:
    return mixin_equipment_event.params(t, equipment) + TableParams.of(
        m.Column(f.r, Float,
            nullable=False),
        m.Column(f.r0, Float,
            server_default=literal(0),
            nullable=False),
        m.Column(f.x, Float,
            nullable=False),
        m.Column(f.x0, Float,
            server_default=literal(0),
            nullable=False),
        m.Column(f.b, Float,
            server_default=literal(0),
            nullable=False),
        m.Column(f.b0, Float,
            server_default=literal(0),
            nullable=False),
        m.Column(f.g, Float,
            server_default=literal(0),
            nullable=False),
        m.Column(f.g0, Float,
            server_default=literal(0),
            nullable=False),
    )
