"""
Record of connection information of `Terminal` and `ConnectivityNode` across all abstraction.

We consider an equipment as installed when at least one of its terminal is connected to another.
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.history import mixin_period, mixin_span, table_abstraction, table_connectivity_node, table_container, table_equipment, table_resource_class, table_terminal
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams
from sqlalchemy.sql import expression as expr


class _Fields[T](NamedTuple):
    eq_fk: T = """
    The uuid of the `Equipment` that its terminal is connected in this row.
    """
    side: T = """
    Side of the `Equipment` (`Terminal`) that is connected in this row. Either `t1`, `t2`, or `t`.
    """
    terminal_uuid: T = """
    The uuid of the terminal that is connected in this row. It includes the `eq_fk` and side field.

    This allows detecting duplicates using a single column.
    """
    eq_class: T = """
    It is used to determine the concrete equipment that is connected in this row; `equipmenttype` is the type of the equipment, which is one of the following values: `bess`, `branch`, `busbarSection`, `energyConsumer`, `externalNetwork`, `pv`, `switch`, `transformer`, `synchronousGenerationUnit`, `measurementDevice`.

    This information is redundant but it avoid needing to join with `equipment`.
    """
    abstraction_fk: T = """
    The name of the abstraction layer that this connectivity modifies.
    """
    cn_fk: T = """
    The uuid of the `ConnectivityNode` that the `Terminal` is connected to.
    """
    container_fk: T = """
    The uuid of the container (if it exists) in which the terminal is installed.
    """
    indirect: T = """
    Boolean indicating if a terminal is indirectly connected.

    Used when we don't know precisely how a terminal is connected to the rest of the network,
    but we know it is linked to this row's connectivity node.
    """


class _Constraints[T](NamedTuple):
    no_installation_overlap: T = """
    A terminal can be installed (date) only at a single place at a time per abstraction.
    """
    no_heartbeat_overlap: T = """
    A terminal can be installed (heartbeat) only at a single place at a time per abstraction.
    """


m, f, c, i = meta_from(__name__).specify(TableMeta.inherits)(_Fields, _Constraints).explode()

def params(t: TableMeta) -> TableParams:
    period = mixin_period
    span = mixin_span
    return span.params(t) + TableParams.of(
        m.Column(f.eq_fk, UUID,
            ForeignKey(table_equipment.m.qt(table_equipment.f.uuid)),
            nullable=False),
        m.Column(f.side, Enum(TerminalSide),
            nullable=False),
        ForeignKeyConstraint(
            [f.eq_fk, f.side],
            table_terminal.m.qts([table_terminal.f.eq_fk, table_terminal.f.side]),
        ),
        m.Column(f.terminal_uuid, UUID,
            Computed(f"uuid_generate_v5({f.eq_fk}, case when side = '{TerminalSide.T1.value}' then 1 when side = '{TerminalSide.T2.value}' then 2 when {f.side} = '{TerminalSide.T3.value}' then 3 end::text)")),
        m.Column(f.eq_class, String,
            ForeignKey(table_resource_class.m.qt(table_resource_class.f.name)),
            nullable=False),
        m.Column(f.abstraction_fk, String,
            ForeignKey(table_abstraction.m.qt(table_abstraction.f.name)),
            nullable=False),
        m.Column(f.cn_fk, UUID,
            ForeignKey(table_connectivity_node.m.qt(table_connectivity_node.f.uuid)),
            nullable=True),
        m.Column(f.container_fk, UUID,
            ForeignKey(table_container.m.qt(table_container.f.uuid)),
            nullable=True),
        m.Column(f.indirect, Boolean,
            server_default=literal(False),
            nullable=False),
        m.ExcludeConstraint(
            c.no_installation_overlap,
            (func.tstzrange(Column(span.f.start), Column(span.f.end)), '&&'),
            (f.eq_fk, '='),
            (f.side, '='),
            (f.abstraction_fk, '='),
        ),
        m.ExcludeConstraint(
            c.no_heartbeat_overlap,
            (func.tstzrange(Column(period.f.start_heartbeat), Column(period.f.end_heartbeat)), '&&'),
            (f.eq_fk, '='),
            (f.side, '='),
            (f.abstraction_fk, '='),
        ),
    )

g = m.generate_ddl(params(m))
