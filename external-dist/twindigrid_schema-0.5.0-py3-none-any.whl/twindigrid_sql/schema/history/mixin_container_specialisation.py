"""
TableComment
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.history import table_container
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams


class _Fields[T](NamedTuple):
    uuid: T = """The uuid of the specialized equipment container determined by this row."""

m, f, c, i = meta_from(__name__).specify(TableMeta.inherits)(_Fields).explode()

def params(t: TableMeta) -> TableParams:
    return TableParams.of(
        m.Column(f.uuid, UUID,
            ForeignKey(table_container.m.qt(table_container.f.uuid), ondelete='CASCADE'),
            primary_key=True),
    )
