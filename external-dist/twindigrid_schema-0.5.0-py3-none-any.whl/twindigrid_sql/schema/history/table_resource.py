"""
Resource table to allow referencing either an equipment or a container.


<details><summary>Implementation choices</summary>
- Use `start_heartbeat` and `end_heartbeat` to specify validity instead of the presence of the resource in `connectivity` table, to allow
later asset management (say that a resource is still/no longer available) even if the resource has no connection.
</details>
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.ddl.constraints import CheckNotNullIfEquals
from twindigrid_sql.entries import container_class
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.history import mixin_span, table_resource_class
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams


class _Fields[T](NamedTuple):
    uuid: T = """
    The uuid of the resource.
    """
    dso_code: T = """
    Unique code defined by the DSO (for compatibility with their other systems).
    """
    name: T = """
    Human readable name of the equipment determined by this row.
    """
    concrete_class: T = """
    It is used to determine the concrete resource;
    <details><summary>Implementation choices</summary>
    Lookup table to allow non-subclassed equipment and containers.

    E.g. a heat-pump doesn't have a specialized sub-class of equipment, but a DSO may want to store
    them anyway. So they create a row in `resource_class` for the heat pump equipment class and input
    the instances into the `resource` table with their specificity stored in the `metadata` column.
    </details>
    """
    feeder_fk: T = """
    Equipment uuid of mv feeder from hv post considering usual switch state
    """
    metadata: T = """
    JSON document containing various metadata pertaining to this resource.
    """
    owner: T = """
    The owner of the resource. Specifiy if it is a private owner, the dso or an external grid (tso)
    """

class _Constraints[T](NamedTuple):
    required_dso_code_for_client: T = """
    The dso_code is required if resource is a container.client.
    """

m, f, c, i = meta_from(__name__).specify(TableMeta.inherits)(_Fields, _Constraints).explode()

def params(t: TableMeta) -> TableParams:
    return mixin_span.params(t) + TableParams.of(
        m.Column(f.dso_code, String,
            unique=True,
            nullable=True),
        m.Column(f.concrete_class, String,
            ForeignKey(table_resource_class.m.qt(table_resource_class.f.name)),
            nullable=False),
        m.Column(f.name, String),
        m.Column(f.feeder_fk, String,
            nullable=True),
        m.Column(f.metadata, JSONB,
            nullable=True),
        m.Column(f.owner, Enum(Owner),
            nullable=True),
        m.CheckConstraint(c.required_dso_code_for_client,
            CheckNotNullIfEquals(f.dso_code, f.concrete_class, container_class.CLIENT)),
    )

g = m.generate_ddl(params(m))
