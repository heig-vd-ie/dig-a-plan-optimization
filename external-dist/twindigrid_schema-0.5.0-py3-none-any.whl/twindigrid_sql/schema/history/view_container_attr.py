"""
ViewComment
"""

from sqlalchemy import event

from twindigrid_sql.ddl.view import CreateView, View
from twindigrid_sql.dql.attr_extractor import AttrMerger, attr_extractor_from_table
from . import table_client, table_resource, table_substation
from twindigrid_sql.schema.metadata import metadata_obj
from twindigrid_sql.schema.metadata import meta_from

m = meta_from(__name__)

def based_on(meta, resource, spec_extractors):

    q = AttrMerger(
            parent_table=resource,
            pk_cols=[resource.c.uuid],
            class_col=resource.c.concrete_class,
            spec_data=spec_extractors,
        ).select()

    v = View(
        name=meta.name, 
        schema=meta.schema,
        query=q,
        comment=meta.comment,
    )

    event.listen(meta.metadata_object, 'after_create', CreateView(v, True))

    return v

spec_extractors = [
    attr_extractor_from_table(table_client.g.table),
    attr_extractor_from_table(table_substation.g.table),
]

v = based_on(m, table_resource.g.table, spec_extractors)
