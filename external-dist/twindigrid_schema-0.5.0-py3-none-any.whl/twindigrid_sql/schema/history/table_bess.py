"""
Battery energy storage systems (BESSs) components.
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.history import mixin_equipment_specialisation, table_equipment
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams


class _Fields[T](NamedTuple):
    charging_eff: T = """
    Charging efficiency in percentage (Symbol: `Eta_bess_ch`, Unit: `%`).
    """
    discharging_eff: T = """
    Discharging efficiency in percentage (Symbol: `Eta_bess_dch`, Unit: `%`).
    """
    rated_s: T = """
    maximum apparent power of BESS inverter (Symbol: `S_bess_nom`, Unit: `kVA`).
    """
    rated_e: T = """
    Nominal capacity (Symbol: `E_bess_nom`, Unit: `kW`).
    """
    min_charging_p: T = """
    Minimum charging power (Symbol: `P_bess_ch_min`, Unit: `kW`).
    """
    max_charging_p: T = """
    Maximum charging power (Symbol: `P_bess_ch_max`, Unit: `kW`).
    """
    min_discharging_p: T = """
    Minimum discharging power (Symbol: `P_bess_dch_min`, Unit: `kW`).
    """
    max_discharging_p: T = """
    Maximum discharging power (Symbol: `P_bess_dch_max`, Unit: `kW`).
    """

m, f, c, i = meta_from(__name__).specify(TableMeta.inherits)(_Fields).explode()

def params(t: TableMeta) -> TableParams:
    return mixin_equipment_specialisation.params(t) + TableParams.of(
        m.Column(f.charging_eff, Float,
            server_default=literal(1),
            nullable=True),
        m.Column(f.discharging_eff, Float,
            server_default=literal(1),
            nullable=True),
        m.Column(f.rated_s, Float,
            nullable=True),
        m.Column(f.rated_e, Float,
            nullable=True),
        m.Column(f.min_charging_p, Float,
            server_default=literal(0),
            nullable=True),
        m.Column(f.max_charging_p, Float,
            nullable=True),
        m.Column(f.min_discharging_p, Float,
            server_default=literal(0),
            nullable=True),
        m.Column(f.max_discharging_p, Float,
            nullable=True),
    )

g = m.generate_ddl(params(m))
