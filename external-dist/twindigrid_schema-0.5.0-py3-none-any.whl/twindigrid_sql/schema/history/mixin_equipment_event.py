"""
TableComment
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.history import mixin_equipment_specialisation, mixin_source_event
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams


class _Fields[T](NamedTuple):
    eq_fk: T = """
    Uuid of the specialized equipment which has this event.
    """

m, f, c, i = meta_from(__name__).specify(TableMeta.inherits)(_Fields).explode()

def params(t: TableMeta, equipment: TableMeta) -> TableParams:
    return mixin_source_event.params(t) + TableParams.of(
        m.Column(f.eq_fk, UUID,
            ForeignKey(equipment.qt(mixin_equipment_specialisation.f.uuid), ondelete='CASCADE'),
            nullable=False),
    )
