"""
A single or set of synchronous machines for converting mechanical power into alternating-current power. For example, individual machines within a set may be defined for scheduling purposes while a single control signal is derived for the set. In this case there would be a generating unit for each member of the set and an additional generation unit to the set.
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.history import mixin_equipment_specialisation, table_equipment
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams


class _Fields[T](NamedTuple):
    rated_s: T = """
    Maximum apparent power of the generation unit (Symbol: `S_dg_nom`, Unit: `kVA`).
    """
    min_operating_p: T = """
    Minimum active power of generating unit (Symbol: `P_dg_min`, Unit: `kW`).
    """
    max_operating_p: T = """
    Maximum active power of generating unit (Symbol: `P_dg_max`, Unit: `kW`).
    """
    cos_phi_limit: T = """
    Power factor limit of the generating unit (Symbol: `Pf_dg_limit`).
    """
    pv_slope: T = """
    Slope of pv installation, where 0 is horizontal slop (Symbol: `a`, Unit: `°`).
    """
    pv_orientation: T = """
    Orientation of pv installation, where 0 is sud oriented (Symbol: `theta`, Unit:  `°`).
    """
    type: T = """
    Type of the generating unit.
    """

m, f, c, i = meta_from(__name__).specify(TableMeta.inherits)(_Fields).explode()

def params(t: TableMeta) -> TableParams:
    return mixin_equipment_specialisation.params(t) + TableParams.of(
        m.Column(f.rated_s, Float,
            nullable=True),
        m.Column(f.min_operating_p, Float,
            server_default=literal(0),
            nullable=True),
        m.Column(f.max_operating_p, Float,
            nullable=True),
        m.Column(f.cos_phi_limit, Float,
            nullable=True),
        m.Column(f.pv_slope, Float,
            nullable=True),
        m.Column(f.pv_orientation, Float,
            nullable=True),
        m.Column(f.type, Enum(GeneratingUnitType),
            nullable=False),
    )

g = m.generate_ddl(params(m))
