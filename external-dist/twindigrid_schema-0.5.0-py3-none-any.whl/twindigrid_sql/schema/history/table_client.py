"""
Client container which contain equipment linked to a client.
"""

from typing import NamedTuple
from geoalchemy2 import Geography
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.ddl.constraints import CheckNotNullIfEquals
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.history import mixin_container_specialisation
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams


class _Fields[T](NamedTuple):
    remote_control: T = """
    Whever the client has equipment that is remote controllable.
    """

m, f, c, i = meta_from(__name__).specify(TableMeta.inherits)(_Fields).explode()

def params(t: TableMeta) -> TableParams:
    return mixin_container_specialisation.params(t) + TableParams.of(
        m.Column(f.remote_control, Boolean,
            server_default=literal(False),
            nullable=False),
    )

g = m.generate_ddl(params(m))
