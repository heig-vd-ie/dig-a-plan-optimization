"""
TableComment
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.history import mixin_event, table_source
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams


class _Fields[T](NamedTuple):
    source_fk: T = """
    A reference to the type of source that provides the new values, e.g. SCADA, SmartMeter, Manual, DigitalTwinAlgorithm, etc.
    """

m, f, c, i = meta_from(__name__).specify(TableMeta.inherits)(_Fields).explode()

def params(t: TableMeta) -> TableParams:
    return mixin_event.params(t) + TableParams.of(
        m.Column(f.source_fk, String,
            ForeignKey(table_source.m.qt(table_source.f.name)),
            nullable=False),
    )
