"""
TableComment
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.history import table_heartbeat
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams


class _Fields[T](NamedTuple):
    uuid: T = """UUIDv7 of the event."""
    timestamp: T = """Instant when the event happened in the real world."""
    heartbeat: T = """Heartbeat (instant) when the event was processed."""

m, f, c, i = meta_from(__name__).specify(TableMeta.inherits)(_Fields).explode()

def params(t: TableMeta) -> TableParams:
    return TableParams.of(
        m.Column(f.uuid, UUID,
            primary_key=True),
        m.Column(f.timestamp, TIMESTAMPTZ,
            nullable=False),
        m.Column(f.heartbeat, TIMESTAMPTZ,
            ForeignKey(table_heartbeat.m.qt(table_heartbeat.f.heartbeat)),
            nullable=False),
    )
