"""
Grid events capture changes in the grid model, i.e., the change in status of switches.
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.history import mixin_equipment_event, table_switch
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams


class _Fields[T](NamedTuple):
    open: T = """
    The new status of switches after the change. Only for switches that changed;
    It is `True` if the status changed to Open and `False` otherwise (Symbol: `u_sw`).
    """

m, f, c, i = meta_from(__name__).specify(TableMeta.inherits)(_Fields).explode()

def params(t: TableMeta) -> TableParams:
    parent = mixin_equipment_event
    return parent.params(m, table_switch.m) + TableParams.of(
        m.Column(f.open, Boolean,
            nullable=False),
    )

g = m.generate_ddl(params(m))
