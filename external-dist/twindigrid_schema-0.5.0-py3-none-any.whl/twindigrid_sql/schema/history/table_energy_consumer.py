"""
Generic user of energy - a point of consumption on the power system model.
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.history import mixin_equipment_specialisation, table_equipment
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams


class _Fields[T](NamedTuple):
    rated_s: T = """
    Nominal apparent power of `EnergyConsumer` (Symbol: `S_ec_nom`, Unit: `kVA`).
    """
    rated_p: T = """
    Nominal active power of `EnergyConsumer` (Symbol: `P_ec_nom`, Unit: `kW`).
    """
    profile_type: T = """
    Profile type of the `EnergyConsumer`; `profiletype` is the type of this column, which is one of the following values: `residential`, `commercial`, `industrial` and `public`.
    """
    egid: T = """
    Egid of the `EnergyConsumer` if it is a building
    """
    matched: T = """
    How of the building haw been matched to the `distribution panel`
    """

m, f, c, i = meta_from(__name__).specify(TableMeta.inherits)(_Fields).explode()

def params(t: TableMeta) -> TableParams:
    return mixin_equipment_specialisation.params(t) + TableParams.of(
        m.Column(f.rated_s, Float,
            nullable=True),
        m.Column(f.rated_p, Float,
            nullable=True),
        m.Column(f.profile_type, Enum(ProfileType),
            nullable=False),
        m.Column(f.egid, String,
            nullable=True),
        m.Column(f.matched, String,
            nullable=True)
    )

g = m.generate_ddl(params(m))
