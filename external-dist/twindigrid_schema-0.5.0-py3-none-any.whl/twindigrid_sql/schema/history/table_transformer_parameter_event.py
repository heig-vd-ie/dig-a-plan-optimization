"""
Parameter events capture all changes in the parameters equipment due to aging or new calculation.
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.history import mixin_equipment_event, mixin_parameter_event, table_terminal, table_transformer
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams

class _Fields[T](NamedTuple):
    side: T = """
    The side (transformer_end) in the transformer.
    
    All sides of the transformer must have at least one transformer_parameter_event, even
    the ones with default values.
    """


m, f, c, i = meta_from(__name__).specify(TableMeta.inherits)(_Fields).explode()

def params(t: TableMeta) -> TableParams:
    return mixin_parameter_event.params(t, table_transformer.m) + TableParams.of(
        m.Column(f.side, Enum(TerminalSide),
            primary_key=True),
        ForeignKeyConstraint(
            [mixin_equipment_event.m.f.eq_fk, f.side],
            table_terminal.m.qts([table_terminal.f.eq_fk, table_terminal.f.side]),
        ),
    )

g = m.generate_ddl(params(m))
