"""
Possible tap values for the tap of the transformer.
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.history import mixin_equipment_specialisation, table_terminal, table_transformer, table_transformer_end
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.meta import TableMeta, TableParams


class _Fields[T](NamedTuple):
    eq_fk: T = """Uuid of the transformer which has this Tap."""
    value: T = """Voltage level of tap position (Unit: `V`)."""
    side: T = """The tap side in the transformer."""

m, f, c, i = meta_from(__name__).specify(TableMeta.inherits)(_Fields).explode()

def params(t: TableMeta) -> TableParams:
    return TableParams.of(
        m.Column(f.eq_fk, UUID,
            ForeignKey(table_transformer.m.qt(mixin_equipment_specialisation.f.uuid), ondelete='CASCADE'),
            primary_key=True),
        m.Column(f.side, Enum(TerminalSide),
            primary_key=True),
        ForeignKeyConstraint(
            [f.eq_fk, f.side],
            table_transformer_end.m.qts([table_transformer_end.f.eq_fk, table_transformer_end.f.side]),
        ),
        m.Column(f.value, Float,
            primary_key=True),
    )

g = m.generate_ddl(params(m))
