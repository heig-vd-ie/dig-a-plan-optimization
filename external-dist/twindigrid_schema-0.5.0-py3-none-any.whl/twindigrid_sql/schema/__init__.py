from types import ModuleType
from twindigrid_sql.ddl.meta import SchemaMeta

from . import enum
from . import history
from . import changes
from . import snap
from . import voltage_layer

schemas: list[ModuleType] = [enum, history, changes, snap, voltage_layer]
metas = [SchemaMeta.of(s) for s in schemas]
extensions = [
    "uuid-ossp",
    "btree_gist",
    "postgis",
    "ltree",
    "pgtap",
    "pg_stat_statements",
]
