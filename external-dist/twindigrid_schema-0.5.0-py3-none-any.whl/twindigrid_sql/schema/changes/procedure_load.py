"""
ProcedureComment
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy import event
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.schema.metadata import metadata_obj
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.callable import CreateCallable, Procedure, CallableArg, TextBody
from twindigrid_sql.ddl.meta import TableMeta, TableParams
from .tables import tables

m = meta_from(__name__)

load_deps: list[Procedure] = [g.load for g in tables]

load = Procedure(
    name=f"{m.name}", 
    schema=m.schema,
    args=[
        arg_start := CallableArg(TIMESTAMPTZ, name='t_start'),
        arg_end := CallableArg(TIMESTAMPTZ, name='t_end'),
    ], 
    body=TextBody("SQL", "\n".join([
        f"""CALL {d.schema}.{d.name}({arg_start.name}, {arg_end.name});"""
        for d in load_deps    
    ])), 
)

event.listen(metadata_obj, 'after_create', CreateCallable(load, True))
