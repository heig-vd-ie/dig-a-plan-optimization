"""
ProcedureComment
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy import event
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.schema.metadata import metadata_obj
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.history import table_container
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.callable import CreateCallable, Procedure, CallableArg, SqlBody, SqlTextBody, TextBody, call
from twindigrid_sql.ddl.meta import TableMeta, TableParams
from .tables import tables

m = meta_from(__name__)

persist_deps: list[Procedure] = [g.persist for g in tables]

persist = Procedure(
    name=f"{m.name}", 
    schema=m.schema,
    comment="""
        Persist all changes in the changes schema to the main schema.
        """,
    args=[],
    # Can't use SqlBody because it generates error:
    #    (psycopg.errors.FeatureNotSupported) CALL is not yet supported in unquoted SQL function body
    body=SqlTextBody([
        call(getattr(getattr(func, d.schema), d.name)(
            # column(arg_t.name),
        ))
        for d in persist_deps    
    ]),
)

event.listen(metadata_obj, 'after_create', CreateCallable(persist, True))