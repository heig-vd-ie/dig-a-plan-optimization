"""
TableComment
"""
from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.ddl.meta_changes import ChangesTableMeta, TableParams, with_table
from twindigrid_sql.schema.changes import mixin_changed, table_equipment
from twindigrid_sql.schema.changes.validity_queries import valid_always, valid_fk, valid_period, valid_point
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.schema import history

m = meta_from(__name__).specify(ChangesTableMeta.inherits)(history.table_branch.g)

def params(t: ChangesTableMeta) -> TableParams:
    return (
        mixin_changed.params(t) 
        + with_table(t)
    )

g = m.generate_ddl(params(m), query=valid_fk(table_equipment.g))