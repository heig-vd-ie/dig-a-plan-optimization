from dataclasses import dataclass
from functools import reduce
from typing import Optional
from sqlalchemy import Column, ColumnClause, ColumnElement, FromClause, Select, Table, UnaryExpression, and_, column, desc, func, literal, null, select, tuple_

from twindigrid_sql.custom_types import TIMESTAMPTZ
from twindigrid_sql.ddl.callable import CallableArg
from twindigrid_sql.ddl.meta_changes import ChangesTableMeta, GeneratedChangesTableDDL, MainMapper
from twindigrid_sql.schema import history
from twindigrid_sql.schema.enum import Diff
from twindigrid_sql.schema.history import mixin_equipment_event, mixin_event, mixin_period, mixin_resource_event, mixin_source_event, table_source
from twindigrid_sql.schema.metadata import Enum

diff_label = "diff"

diff_null = null().cast(Enum(Diff)).label(diff_label)
diff_add = literal(Diff.CREATED).label(diff_label)
diff_remove = literal(Diff.UPDATED).label(diff_label)
diff_update = literal(Diff.DELETED).label(diff_label)

def sel_cols(changes_table: Table) -> ColumnClause:
    return map(lambda m: m.read, MainMapper.of_table(changes_table))

def valid_always(meta: ChangesTableMeta, changes_table: Table, arg_start: CallableArg, arg_end: CallableArg) -> Select:
    return select(diff_null, *sel_cols(changes_table))

def valid_period(meta: ChangesTableMeta, changes_table: Table, arg_start: CallableArg, arg_end: CallableArg) -> Select:
    """period overalps with start and end range"""
    period = mixin_period.m
    return (
        select(diff_null, *sel_cols(changes_table))
        .where(
            func.tstzrange(
                Column(period.f.start_heartbeat), 
                Column(period.f.end_heartbeat),
            ).bool_op("&&")(
                func.tstzrange(arg_start.col, arg_end.col)
            )
        )
    )

@dataclass
class SkipScan:
    # Should have an higher cardinality than the one in lateral_on
    # e.g. for tap_event: [eq_fk]
    distinct_on: ColumnElement
    # Cardinality should go from lowest to highest
    # e.g. for tap_event: [
    #   (side, SELECT e.side FROM (VALUES ('t1'), ('t2')) AS e(side)), 
    #   (source_fk, SELECT uuid FROM main.source),
    # ]
    # Calculates unique value from the skip scan table if FromClause is None
    # e.g. select distinct on (side) side FROM tap_event ORDER BY side, ts DESC
    lateral_on: list[tuple[ColumnElement, Optional[FromClause]]]
    # e.g. for tap_event: [hb DESC, ts DESC]
    order: list[UnaryExpression]

    def query(self, changes_table: Table):
        lateral_on = [
            (c, f if f is not None else select(c).distinct(c).order_by(c, *self.order).subquery())
            for c, f in self.lateral_on
        ]
        cat_queries = [
            f
            for _, f in lateral_on
        ]
        lateral_query = (
            select(*sel_cols(changes_table))
            .distinct(self.distinct_on)
            .where(*[
                c == f.c[0]
                for c, f in lateral_on
            ])
            .order_by(self.distinct_on, *self.order)
            .lateral()
        )
        return select(lateral_query).join_from(*cat_queries, lateral_query)


def valid_equipment_event(meta: ChangesTableMeta, changes_table: Table, arg_start: CallableArg, arg_end: CallableArg) -> Select:
    return valid_source_event(meta, changes_table, meta.main_ddl.table.c[mixin_equipment_event.f.eq_fk], arg_start, arg_end)

def valid_resource_event(meta: ChangesTableMeta, changes_table: Table, arg_start: CallableArg, arg_end: CallableArg) -> Select:
    return valid_source_event(meta, changes_table, meta.main_ddl.table.c[mixin_resource_event.f.res_fk], arg_start, arg_end)

def valid_source_event(meta: ChangesTableMeta, changes_table: Table, distinct_on: Column, arg_start: CallableArg, arg_end: CallableArg) -> Select:
    """latest heartbeat at or before start and heartbeat in start and end range"""
    main_table = meta.main_ddl.table
    source_table = history.table_source
    skip_scan = SkipScan(
        distinct_on=distinct_on,
        lateral_on=[
            (main_table.c[mixin_source_event.f.source_fk], select(source_table.g.table.c[source_table.f.name]).subquery()),
        ],
        order=[
            main_table.c[mixin_event.f.heartbeat].desc(),
            main_table.c[mixin_event.f.timestamp].desc(),
        ]
    )
    return (
        select(diff_null, skip_scan.query(changes_table).subquery())
        .union(valid_point(meta, changes_table, arg_start, arg_end))
    )

def valid_point(meta: ChangesTableMeta, changes_table: Table, arg_start: CallableArg, arg_end: CallableArg) -> Select:
    """heartbeat is in start and end range"""
    event = mixin_event.m
    return (
        select(diff_null, *sel_cols(changes_table))
        .where(
            Column(event.f.heartbeat).bool_op("<@")(
                func.tstzrange(arg_start.col, arg_end.col)
            )
        )
    )

def valid_fk(fk_gen: GeneratedChangesTableDDL):
    """row are valid for the time range if at least on of the related rows in another table are valid"""
    def inner(meta: ChangesTableMeta, changes_table: Table, arg_start: CallableArg, arg_end: CallableArg) -> Select:
        f = fk_gen.read.func(arg_start.col, arg_end.col)

        cur_table = meta.main_ddl.table
        other_table = fk_gen.meta.main_ddl.table
        in_clause = [
            # Other table refers to current table
            tuple_(*(
                a.column 
                for a in fk.elements
            )).in_(select(*(
                f.columns[b.key]
                for b in fk.columns
            )))
            for fk in other_table.foreign_key_constraints
            if fk.referred_table == cur_table
        ] + [
            # Current table refers to other table
            tuple_(*(
                a
                for a in fk.columns
            )).in_(select(*(
                f.columns[b.column.key]
                for b in fk.elements
            )))
            for fk in cur_table.foreign_key_constraints
            if fk.referred_table == other_table
        ]
        if len(in_clause) != 1:
            raise Exception("No or too many foreign key between the two tables")
        in_clause = in_clause[0]

        changes_table.add_is_dependent_on(fk_gen.table)

        s = (
            select(diff_null, *sel_cols(changes_table))
            # .join(f, on_clause)
            .where(in_clause)
        )
        return s
    return inner
