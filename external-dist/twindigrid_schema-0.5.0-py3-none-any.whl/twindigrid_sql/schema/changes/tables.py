
from types import ModuleType

from twindigrid_sql.ddl.meta_changes import GeneratedChangesTableDDL

# Measurement
from . import table_heartbeat \
    , table_resource \
    , table_equipment \
    , table_busbar_section \
    , table_branch \
    , table_branch_parameter_event \
    , table_geo_event \
    , table_switch \
    , table_switch_event \
    , table_transformer \
    , table_transformer_parameter_event \
    , table_transformer_end \
    , table_tap \
    , table_tap_event \
    , table_bess \
    , table_energy_consumer \
    , table_external_network \
    , table_generating_unit \
    , table_terminal \
    , table_container \
    , table_client \
    , table_substation \
    , table_base_voltage \
    , table_connectivity \
    , table_connectivity_node \
    , table_measurement \
    , table_measurement_point \
    , table_measurement_span \


table_modules: list[ModuleType] = [
    table_heartbeat,
    table_resource,
    table_equipment,
    table_terminal,
    table_busbar_section,
    table_branch,
    table_branch_parameter_event,
    table_geo_event,
    table_switch,
    table_switch_event,
    table_transformer,
    table_transformer_end,
    table_transformer_parameter_event,
    table_tap,
    table_tap_event,
    table_bess,
    table_energy_consumer,
    table_external_network,
    table_generating_unit,
    table_container,
    table_client,
    table_substation,
    table_base_voltage,
    table_connectivity_node,
    table_connectivity,
    table_measurement,
    table_measurement_point,
    table_measurement_span,
]
tables: list[GeneratedChangesTableDDL] = [m.g for m in table_modules]
