"""
ProcedureComment
"""

from typing import NamedTuple
from sqlalchemy import *
from sqlalchemy import event
from sqlalchemy.dialects.postgresql import *

from twindigrid_sql.custom_types import *
from twindigrid_sql.ddl.meta_changes import GeneratedChangesTableDDL
from twindigrid_sql.schema.metadata import metadata_obj
from twindigrid_sql.schema.enum import *
from twindigrid_sql.schema.metadata import Enum, meta_from
from twindigrid_sql.ddl.callable import CreateCallable, Procedure, CallableArg, TextBody
from .tables import table_modules

m = meta_from(__name__)

tables: list[GeneratedChangesTableDDL] = [tm.g for tm in table_modules]

clear = Procedure(
    name=f"{m.name}", 
    schema=m.schema,
    args=[], 
    body=TextBody("SQL", "\n".join([
        f"""TRUNCATE {t.meta.schema}.{t.meta.name};"""
        for t in reversed(tables)
    ])), 
)

event.listen(metadata_obj, 'after_create', CreateCallable(clear, True))
