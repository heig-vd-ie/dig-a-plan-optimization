CREATE OR REPLACE FUNCTION in_period(s TIMESTAMP, t TIMESTAMP, e TIMESTAMP) RETURNS BOOLEAN AS $$
    SELECT $1 <= $2 AND ($2 < $3 OR $3 IS NULL)
$$ LANGUAGE SQL IMMUTABLE;

CREATE OR REPLACE FUNCTION align_to_heartbeat(t TIMESTAMP) RETURNS TIMESTAMP AS $$
    SELECT time_bucket(h.freq, $1 + h.freq - INTERVAL '1 microsecond', origin => h.start_date)
    FROM main."Heartbeat" h
    ORDER BY start_date DESC
    LIMIT 1
$$ LANGUAGE SQL STABLE;
