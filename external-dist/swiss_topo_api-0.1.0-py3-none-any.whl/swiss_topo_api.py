import requests
import polars as pl

import tqdm

from typing import Optional, Union
from shapely import Geometry, Polygon


from swiss_topo_utility.constant import LAYER_DICT, STATUS_MAPPING, API_URL, FIND_API_URL
from general_function import dictionary_key_filtering
from shapely_function import partition

from swiss_topo_utility.layer_processing import process_layer, generate_dataframe_from_dicts

def get_all_layers_from_polygon(polygon: Geometry, layer_list: Optional[list[str]] = None) -> dict[str, pl.DataFrame]:
    """
    Retrieves layer data from a given polygon.

    Args:
        polygon (Geometry): The polygon to retrieve layer data from.
        layer_list (Optional[list[str]], optional): A list of layer names to filter the results. Defaults to None.

    Returns:
        dict[str, pl.DataFrame]: A dictionary containing the layer names as keys and the corresponding layer data as values.
    """
    if not isinstance(polygon, Polygon): 
        raise ValueError("Error: Not a valid polygon")
    if polygon.is_empty:
        raise ValueError("Error: Empty polygon")
    results_dict: dict[str, pl.DataFrame] = {}
    layer_dict =  dictionary_key_filtering(LAYER_DICT, layer_list) if layer_list else LAYER_DICT
    for layer_name in layer_dict.keys():
        results: pl.DataFrame = get_one_layer_from_polygon(
            layer_name=layer_name, polygon=polygon)
        results_dict = process_layer(
            layer_name=layer_name, results=results, results_dict=results_dict, polygon=polygon) # type: ignore
    return results_dict
        
def get_one_layer_from_polygon(layer_name: str, polygon: Polygon) -> pl.DataFrame:
    """
    Retrieves layer data from an envelope list based on the given layer name and geometry.

    Args:
        layer_name (str): The name of the layer to retrieve data from.
        geometry (Polygon): The geometry of the envelope list.

    Returns:
        pl.DataFrame: A Pandas DataFrame containing the retrieved layer data.
    """

    if layer_name not in LAYER_DICT.keys():
        raise NameError(f"Error {layer_name} is not a treated layer")
    if layer_name in ["roof_pv_potential", "wall_pv_potential"]:
        delta = 150
    elif layer_name in ["regbl"]:
        delta = 300
    else:
        delta = 1000
    result_df, result_list = recursive_function(
        layer_name = layer_name, result_list=[], result_df=pl.DataFrame(), polygon=polygon, delta=delta
    )
    if result_list:
        return generate_dataframe_from_dicts(data_dicts=result_list, data_df=result_df)
    else:
        return result_df



def recursive_function(
        layer_name: str, result_list: list[dict], result_df: pl.DataFrame, polygon: Polygon, 
        delta: float, with_tqdm: bool = True
    ) -> tuple[pl.DataFrame, list[dict]]:
    """
    Recursively downloads entries from a specified layer within a given polygon.
    Args:
        layer_name (str): The name of the layer to download entries from.
        result_list (list[dict]): The list to store the downloaded entries.
        result_df (pl.DataFrame): The DataFrame to store the downloaded entries.
        polygon (Polygon): The polygon to partition and download entries from.
        delta (float): The delta value used for partitioning the polygon.
        with_tqdm (bool, optional): Whether to display a progress bar. Defaults to True.
    Returns:
        tuple[pl.DataFrame, list[dict]]: A tuple containing the updated DataFrame and list of downloaded entries.
    """
    layer = LAYER_DICT[layer_name]
    desc = "Download entries from {} layer".format(layer_name)

    polygon_list = partition(polygon, delta=delta)  # type: ignore
    if not polygon_list:
        polygon_list = [polygon]

    pbar = tqdm.tqdm(polygon_list, ncols=100, desc=desc) if with_tqdm else polygon_list
    
    for small_polygon in pbar:
        geometry_str = ",".join(map(str, small_polygon.bounds)) # type: ignore
        params = {
            "geometryType": "esriGeometryEnvelope", "geometry": geometry_str,
            "tolerance":"0", "layers": "all:" + layer,
            "geometryFormat":"geojson", "returnGeometry": "True","lang": "fr", "sr": "2056",
        }
        response = requests.get(API_URL, params=params)
        if response.status_code == 200:
            new_results = response.json()["results"]
            if new_results:
                result_list.extend(new_results)
                if len(new_results) >= 70:
                    result_df, result_list = recursive_function(
                        layer_name = layer_name, result_list=result_list, result_df=result_df, polygon=
                        small_polygon, delta=delta/4, with_tqdm=False
                    )
        else:
            raise  ValueError("Error: " + STATUS_MAPPING[response.status_code])    
    if len(result_list) > 2000:
        result_df = generate_dataframe_from_dicts(data_dicts=result_list, data_df=result_df)
        result_list = []
    return result_df, result_list


def get_layer_from_egid_list(egid_list: Union[list[int], int], layer: str) -> pl.DataFrame:

    if isinstance(egid_list, int):
        egid_list = [egid_list]
    results: list = []
    for egid in tqdm.tqdm(egid_list):
        params = {
            "layer": layer, "searchField" : "egid","searchText": egid,
            "geometryFormat":"geojson", "returnGeometry": "True"  
        }
        response = requests.get(FIND_API_URL, params=params)
        results.extend(response.json()["results"])

    result_df = generate_dataframe_from_dicts(data_dicts=results, data_df = pl.DataFrame())
    
    return result_df 

