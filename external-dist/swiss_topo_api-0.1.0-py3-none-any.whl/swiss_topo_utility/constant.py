from importlib import metadata


STATUS_MAPPING = {
    200:'Success!',
    400:'Wrong geometry',
    404:'Resource not found.',
    500:'Server error.',
    401:'Unauthorized. Authentication required.',
}

LAYER_DICT = {
    "electrical_power_plant": "ch.bfe.elektrizitaetsproduktionsanlagen",
    "regbl": "ch.bfs.gebaeude_wohnungs_register",
    "roof_pv_potential": "ch.bfe.solarenergie-eignung-daecher",
    "wall_pv_potential": "ch.bfe.solarenergie-eignung-fassaden",
    "electrical_installation": "ch.bfe.elektrische-anlagen_ueber_36", 
    "road": "ch.swisstopo.swisstlm3d-strassen",
    "electrical_power_plant": "ch.bfe.elektrizitaetsproduktionsanlagen",
    "citizen": "ch.bfs.volkszaehlung-bevoelkerungsstatistik_einwohner",
    "non_industrial_heat_demand": "ch.bfe.fernwaerme-nachfrage_wohn_dienstleistungsgebaeude",
    "industrial_heat_demand": "ch.bfe.fernwaerme-nachfrage_industrie",
    "ev_power_requirement": "ch.bfe.ladebedarfswelt-strombedarf", 
    "ev_plug_in": "ch.bfe.ladebedarfswelt-fahrzeuge",
    "ev_planned": "ch.bfe.ladebedarfswelt-ladepunkte_geplant",
    "ev_flexible": "ch.bfe.ladebedarfswelt-ladepunkte_flexibel", 
    "ev_convenient": "ch.bfe.ladebedarfswelt-ladepunkte_bequem",   
    "ev_home_planned": "ch.bfe.ladebedarfswelt-heimladeverfuegbarkeit_geplant",  
    "ev_home_flexible": "ch.bfe.ladebedarfswelt-heimladeverfuegbarkeit_flexibel",   
    "ev_home_convenient": "ch.bfe.ladebedarfswelt-heimladeverfuegbarkeit_bequem"             
}
API_URL = "https://api3.geo.admin.ch/rest/services/api/MapServer/identify?"
FIND_API_URL = "https://api3.geo.admin.ch/rest/services/api/MapServer/find?"
SWISS_SRID = "2056"
GPS_SRID = "4326"
METADATA_PATH = "swiss_topo_data" 
