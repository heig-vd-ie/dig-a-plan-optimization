import os
import polars as pl
from polars import col as c

from typing import Optional

from shapely import from_wkt, make_valid, intersects, Polygon
from shapely.geometry import shape

from swiss_topo_utility.constant import METADATA_PATH

from networkx_function import generate_and_connect_segment_from_linestring_list
from general_function import pl_to_dict, dictionary_key_filtering
from shapely_function import remove_z_coordinates
from polars_shapely_function import geojson_to_wkt_col, wkt_to_shape_col


def process_layer(
    layer_name: str,
    results: pl.DataFrame,
    results_dict: dict[str, pl.DataFrame],
    polygon: Polygon,
) -> dict[str, pl.DataFrame]:
    """
    Processes a layer based on its name and updates the results dictionary.

    Args:
        layer_name (str): The name of the layer to process.
        results (pl.DataFrame): The DataFrame containing the results to process.
        results_dict (dict[str, pl.DataFrame]): The dictionary to update with processed results.
        polygon (Polygon): The polygon to use for spatial filtering.

    Returns:
        dict[str, pl.DataFrame]: The updated results dictionary.
    """
    if results.is_empty():
        return results_dict

    if layer_name == "citizen":
        results_dict[layer_name] = process_citizen_table(data=results)
    elif layer_name == "regbl":
        results_dict[layer_name] = process_regbl_table(data=results)
    elif layer_name == "road":
        results_dict[layer_name] = process_road_table(data=results)
    elif layer_name in [
        "electrical_power_plant",
        "non_industrial_heat_demand",
        "industrial_heat_demand",
    ]:
        results_dict[layer_name] = process_other_table(data=results)
    elif layer_name in ["electrical_installation"]:
        results_dict["hv_substation"], results_dict["hv_line"] = (
            process_electrical_installation(data=results)
        )
    elif layer_name == "roof_pv_potential":
        results_dict[layer_name] = process_roof_pv_potential_table(data=results)
    elif layer_name == "wall_pv_potential":
        results_dict[layer_name] = process_wall_pv_potential_table(data=results)
    else:
        results_dict[layer_name] = results

    if layer_name == "electrical_installation":
        results_dict["hv_substation"] = results_dict["hv_substation"].filter(
            c("geometry").map_elements(
                lambda x: intersects(from_wkt(x), polygon), return_dtype=pl.Int32
            )
            == 1  # type: ignore
        )
        results_dict["hv_line"] = results_dict["hv_line"].filter(
            c("geometry").map_elements(
                lambda x: intersects(from_wkt(x), polygon), return_dtype=pl.Int32
            )
            == 1  # type: ignore
        )
    elif layer_name != "road":
        results_dict[layer_name] = results_dict[layer_name].filter(
            c("geometry").map_elements(
                lambda x: intersects(from_wkt(x), polygon), return_dtype=pl.Int32
            )
            == 1  # type: ignore
        )
    return results_dict


def process_citizen_table(data: pl.DataFrame) -> pl.DataFrame:
    """
    Processes the citizen table data.

    Args:
        data (pl.DataFrame): The DataFrame containing the citizen data.

    Returns:
        pl.DataFrame: The processed citizen data.
    """
    if data.is_empty():
        return data
    geometry_mapping: dict[str, str] = pl_to_dict(
        data.filter(c("label").is_first_distinct())[["label", "geometry"]]
    )
    data = (
        data.filter(c("id").is_first_distinct())
        .sort("i_year")
        .pivot(index="label", columns="i_year", values="number")
    )  # type: ignore
    return data.with_columns(
        c("label")
        .replace(geometry_mapping, return_dtype=pl.Utf8, default=None)
        .alias("geometry"),
        pl.coalesce(list(reversed(data.drop("label").columns))).alias("last_entry"),
    )


def process_regbl_table(data: pl.DataFrame) -> pl.DataFrame:
    """
    Processes the RegBL table data.

    Args:
        data (pl.DataFrame): The DataFrame containing the RegBL data.

    Returns:
        pl.DataFrame: The processed RegBL data.
    """
    if data.is_empty():
        return data

    metadata_file_name: str = os.path.join(
        os.path.dirname(__file__), METADATA_PATH, "RegBL_columns.csv"
    )
    code_def_file_name: str = os.path.join(
        os.path.dirname(__file__), METADATA_PATH, "RegBL_code_mapping.csv"
    )

    column_mapping: dict[str, str] = pl_to_dict(
        pl.read_csv(metadata_file_name)[["old_name", "new_name"]]
    )
    code_mapping: dict = pl_to_dict(
        pl.read_csv(code_def_file_name)[["code", "description"]]
    )

    column_name = [
        "building_status",
        "building_cath",
        "building_class",
        "heat_1",
        "heat_source_1",
        "heat_2",
        "heat_source_2",
        "heatwater_1",
        "heatwater_source_1",
        "heatwater_2",
        "heatwater_source_2",
    ]
    column_mapping: dict[str, str] = dictionary_key_filtering(
        column_mapping, data.columns
    )
    return (
        data.filter(c("featureId").is_first_distinct())
        .rename(column_mapping)[list(column_mapping.values())]
        .with_columns(
            c(col_name).replace(code_mapping, default=None, return_dtype=pl.Utf8)
            for col_name in column_name
        )
        .filter(c("egid").is_first_distinct())
        # .filter((~c("building_class").is_null()) | (c("building_cath") != "no_residential"))\
        # .filter(~c("building_class").is_in(["other", "storage", "parking"]))
    )


def process_roof_pv_potential_table(data: pl.DataFrame) -> pl.DataFrame:
    """
    Processes the roof PV potential table data.

    Args:
        data (pl.DataFrame): The DataFrame containing the roof PV potential data.

    Returns:
        pl.DataFrame: The processed roof PV potential data.
    """
    if data.is_empty():
        return data
    metadata_file_name: str = os.path.join(
        os.path.dirname(__file__), METADATA_PATH, "pv_potential_metadata.csv"
    )
    column_mapping: dict[str, str] = pl_to_dict(
        pl.read_csv(metadata_file_name)[["old_name", "new_name"]]
    )
    column_mapping: dict[str, str] = dictionary_key_filtering(
        column_mapping, data.columns
    )
    return (
        data.filter(c("featureId").is_first_distinct())
        .rename(column_mapping)[list(column_mapping.values())]
        .with_columns(
            c("geometry").map_elements(
                lambda x: make_valid(list(from_wkt(x).geoms)[0]).wkt,
                return_dtype=pl.Utf8,
            )
        )
        .drop_nulls("egid")
    )


def process_wall_pv_potential_table(data: pl.DataFrame) -> pl.DataFrame:
    """
    Processes the wall PV potential table data.

    Args:
        data (pl.DataFrame): The DataFrame containing the wall PV potential data.

    Returns:
        pl.DataFrame: The processed wall PV potential data.
    """
    if data.is_empty():
        return data
    metadata_file_name: str = os.path.join(
        os.path.dirname(__file__), METADATA_PATH, "pv_potential_metadata.csv"
    )
    column_mapping: dict[str, str] = pl_to_dict(
        pl.read_csv(metadata_file_name)[["old_name", "new_name"]]
    )
    column_mapping: dict[str, str] = dictionary_key_filtering(
        column_mapping, data.columns
    )

    return (
        data.filter(c("featureId").is_first_distinct())
        .rename(column_mapping)[list(column_mapping.values())]
        .drop_nulls("egid")
    )


def process_electrical_installation(
    data: pl.DataFrame,
) -> tuple[pl.DataFrame, pl.DataFrame]:
    """
    Processes the electrical installation data.

    Args:
        data (pl.DataFrame): The DataFrame containing the electrical installation data.

    Returns:
        tuple[pl.DataFrame, pl.DataFrame]: A tuple containing the processed HV substation and HV line data.
    """
    if data.is_empty():
        return (pl.DataFrame(), pl.DataFrame())
    metadata_file_name: str = os.path.join(
        os.path.dirname(__file__), METADATA_PATH, "electrical_installation.csv"
    )

    column_mapping: dict = pl_to_dict(
        pl.read_csv(metadata_file_name)[["old_name", "new_name"]]
    )
    column_mapping = dict(
        [(key, value) for key, value in column_mapping.items() if key in data.columns]
    )

    data = data.filter(c("featureId").is_first_distinct()).rename(column_mapping)[
        list(column_mapping.values())
    ]
    hv_substation = (
        data.drop_nulls("station_type")
        if "station_type" in data.columns
        else pl.DataFrame()
    )
    hv_line = (
        data.drop_nulls("line_type") if "line_type" in data.columns else pl.DataFrame()
    )

    return (hv_substation, hv_line)


def process_road_table(data: pl.DataFrame) -> pl.DataFrame:
    """
    Processes the road table data.

    Args:
        data (pl.DataFrame): The DataFrame containing the road data.

    Returns:
        pl.DataFrame: The processed road data.
    """
    if data.is_empty():
        return data
    metadata_file_name: str = os.path.join(
        os.path.dirname(__file__), METADATA_PATH, "road_metadata.csv"
    )
    column_mapping: dict[str, str] = pl_to_dict(
        pl.read_csv(metadata_file_name)[["old_name", "new_name"]]
    )
    column_mapping: dict[str, str] = dictionary_key_filtering(
        column_mapping, data.columns
    )
    road_list = (
        data.filter(c("featureId").is_first_distinct())
        .rename(column_mapping)[list(column_mapping.values())]
        .with_columns(
            c("geometry")
            .pipe(wkt_to_shape_col)
            .map_elements(
                lambda x: remove_z_coordinates(x.geoms[0]), return_dtype=pl.Object
            )
        )
    )["geometry"].to_list()
    connected_road_list = generate_and_connect_segment_from_linestring_list(road_list)
    return (
        pl.DataFrame({"geometry": map(lambda x: x.wkt, connected_road_list)})
        .with_row_index(name="branch_id")
        .with_columns(
            c("branch_id").cast(pl.Utf8),
        )
    )


def process_other_table(data: pl.DataFrame) -> pl.DataFrame:
    """
    Processes other table data.

    Args:
        data (pl.DataFrame): The DataFrame containing the other data.

    Returns:
        pl.DataFrame: The processed other data.
    """
    if data.is_empty():
        return data
    columns: list[str] = [
        "geometry",
        "needhome",
        "needservice",
        "needtotal",
        "service",
        "noga",
        "percentgas",
        "percentoil",
        "percentpump",
        "percentremoteheat",
        "address",
        "canton",
        "beginning_of_operation",
        "initial_power",
        "total_power",
        "main_category_en",
        "sub_category_en",
        "plant_type_en",
        "detail_date",
        "detail_power",
        "detail_inclination",
        "detail_plant_type_en",
        "detail_orientation_en",
    ]
    columns = [key for key in columns if key in data.columns]
    return data.filter(c("featureId").is_first_distinct())[columns]


def process_ev_table(data: Optional[pl.DataFrame]) -> Optional[pl.DataFrame]:
    """
    Processes the EV table data.

    Args:
        data (Optional[pl.DataFrame]): The DataFrame containing the EV data.

    Returns:
        Optional[pl.DataFrame]: The processed EV data or None if the input data is None.
    """
    if data is None:
        return None
    metadata_file_name: str = os.path.join(
        os.path.dirname(__file__), METADATA_PATH, "ev_requirement.csv"
    )
    column_mapping: dict = pl_to_dict(
        pl.read_csv(metadata_file_name)[["old_name", "new_name"]]
    )
    column_mapping = dict(
        [(key, value) for key, value in column_mapping.items() if key in data.columns]
    )
    return data.filter(c("featureId").is_first_distinct()).rename(column_mapping)[
        list(column_mapping.values())
    ]


def generate_dataframe_from_dicts(
    data_dicts: list[dict], data_df: pl.DataFrame
) -> pl.DataFrame:
    """
    Generates a Polars DataFrame from a list of dictionaries.

    Args:
        data_dicts (list[dict]): A list of dictionaries containing the data.
        data_df (pl.DataFrame): The initial DataFrame to concatenate the generated DataFrame with.

    Returns:
        pl.DataFrame: The concatenated DataFrame.

    Raises:
        Exception: If an error occurs during the generation of the DataFrame.
    """

    result_list = [
        {
            "featureId": x["featureId"],
            "id": x["id"],
            "geometry": shape(x["geometry"]).wkt,
        }
        | x["properties"]
        for x in data_dicts
        if not str(x["featureId"]).startswith("-")
    ]

    actual_data_df = pl.from_dicts(result_list, infer_schema_length=1000, strict=False)

    return pl.concat([data_df, actual_data_df], how="diagonal")
